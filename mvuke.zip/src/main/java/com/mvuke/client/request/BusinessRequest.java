/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvuke.client.request;

import javax.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author user
 */
@Data
public class BusinessRequest {

    @JsonProperty
    private String uniqueRef ;
    @JsonProperty(required = true)
    private String username ;
    @JsonProperty(required = true)
    private String password ;
    @JsonProperty(required = true)
    private String DebitAccountId ;
    @JsonProperty(required = true)
    private String CreditAccountId ;
    @JsonProperty
    private String date ;
    @JsonProperty(required = true)
    private String Ref ;
    @JsonProperty(required = true)
    private String amount ;
    @JsonProperty
    private String Narration ;
}

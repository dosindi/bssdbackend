/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvuke.client.request;

import lombok.Data;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author user
 *
 * "UniqueRef": "142562627373", "username": "12345", "password": "cGFzc3dvcmQ=",
 * "DebitAccountId": "1130441910755", "CreditAccountId": "1160161910755",
 * "BillerID": "20", "ServiceID": "50", "date": "2021-11-13 12:50:20", "Ref":
 * "FT13223670", "amount": "1000.00", "Narration": "RKL-FEES"
 */
@Data
public class CoreRequest {

    @JsonProperty
    private String UniqueRef;
    @JsonProperty
    private String username;
    @JsonProperty
    private String password;
    @JsonProperty
    private String DebitAccountId;
    @JsonProperty
    private String CreditAccountId;
    @JsonProperty
    private String BillerID;
    @JsonProperty
    private String ServiceID;
    @JsonProperty
    private String date;
    @JsonProperty
    private String Ref;
    @JsonProperty
    private String amount;
    @JsonProperty
    private String Narration;

}

package com.mvuke.client.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.Api;
import com.mvuke.client.request.BusinessRequest;
import com.mvuke.client.request.CoreRequest;
import com.mvuke.client.response.BusinessFailureResponse;
import com.mvuke.client.response.BusinessResponse;
import com.mvuke.client.response.CoreResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.databind.SerializationFeature;

@RestController
@RequestMapping("v1/api/customer")
@Api(value = "Notification API", description = "Operations pertaining to connection to core banking and Business Client")
public class CustomerController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomerController.class);

    /*
        @Description: Test Request to Core banking system    
     */
    @CrossOrigin(origins = "*")
    @PostMapping("/to-core")
    public @ResponseBody
    ResponseEntity<Object> requestToCore(@RequestBody CoreRequest coreRequest) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        LOGGER.info("request to core " + mapper.writeValueAsString(coreRequest));
        String result = null;

        //TODO add authentication
        TypeReference<CoreResponse> typeReference = new TypeReference<CoreResponse>() {
        };
        InputStream in = null;

        in = TypeReference.class.getResourceAsStream("/mock-response-to-core.json");

        try {
            mapper = new ObjectMapper();
            CoreResponse core = mapper.readValue(in, typeReference);
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
            result = mapper.writeValueAsString(core);

            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (IOException ex) {
            LOGGER.error(ex.toString());
            return new ResponseEntity<>(ex.toString(), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    /*
        @Description: Test Request to Business Client
     */
    @CrossOrigin(origins = "*")
    @PostMapping("to-business")
    public @ResponseBody
    ResponseEntity<Object> requestToBusiness(@RequestBody BusinessRequest businessRequest) throws JsonProcessingException {
        String result = "";
        //TODO add authentication
        ObjectMapper mapper = new ObjectMapper();
        LOGGER.info("request from business " + mapper.writeValueAsString(businessRequest));

        TypeReference<BusinessResponse> typeReference = new TypeReference<BusinessResponse>() {
        };
        InputStream in = null;
        in = TypeReference.class.getResourceAsStream("/mock-response-from-business.json");
        BusinessResponse response = null;

        try {
            mapper = new ObjectMapper();
            response = mapper.readValue(in, typeReference);
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
            result = mapper.writeValueAsString(response);
            return new ResponseEntity<>(result, HttpStatus.OK);

        } catch (IOException ex) {
            LOGGER.error(ex.toString());

            BusinessFailureResponse br = new BusinessFailureResponse();
            br.setUniqueRef(businessRequest.getUniqueRef());
            br.setResponseCode("01");
            br.setResponseDesription("System Error");
            br.setDate(new Date());

            mapper = new ObjectMapper();
            String json = mapper.writeValueAsString(br);
            return new ResponseEntity<>(json, HttpStatus.OK);
//            return new ResponseEntity<>(ex.toString(), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}

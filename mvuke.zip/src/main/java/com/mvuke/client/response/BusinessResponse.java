/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvuke.client.response;

import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 *
 * @author user
 */
@Data
public class BusinessResponse {

    @JsonProperty("uniqueRef")
    private String UniqueRef;
    @JsonProperty
    private String responseCode;
    @JsonProperty
    private String responseDesription;
  
}

package com.mvuke.client;

import com.mvuke.client.controller.CustomerController;
import com.mvuke.client.request.CoreRequest;
import com.mvuke.client.request.BusinessRequest;
import java.io.InputStream;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@WebMvcTest(CustomerController.class)
class MvukeCustomerIntegrationTests {

    @Autowired
    MockMvc mockMvc;

    private final String BASE_URL = "http://localhost:8080/v1/api/customer";

    @Test
    public void testToBiz() throws Exception {

        String url = BASE_URL + "/to-business";

        TypeReference<BusinessRequest> typeReference = new TypeReference<BusinessRequest>() {
        };
        InputStream in = null;
        in = TypeReference.class.getResourceAsStream("/mock-request-to-business.json");

        ObjectMapper mapper = new ObjectMapper();
        BusinessRequest core = mapper.readValue(in, typeReference);

        this.mockMvc.perform(
                post(url).contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(core)))
                .andExpect(status().isOk())
                .andExpect(content().json("{\n"
                        + "    \"uniqueRef\": \" FT13223670\",\n"
                        + "    \"responseCode\": \"00\",\n"
                        + "    \"responseDesription\": \"Success\"\n"
                        + "}"));
    }

    @Test
    public void testToCore() throws Exception {

        String url = BASE_URL + "/to-core";

        TypeReference<CoreRequest> typeReference = new TypeReference<CoreRequest>() {
        };
        InputStream in = null;
        in = TypeReference.class.getResourceAsStream("/mock-request-to-core.json");

        ObjectMapper mapper = new ObjectMapper();
        CoreRequest core = mapper.readValue(in, typeReference);

        this.mockMvc.perform(
                post(url).contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(core)))
                .andExpect(status().isOk())
                .andExpect(content().json("{\n"
                        + "    \"UniqueRef\": \"142562627373\",\n"
                        + "    \"responseCode\": \"00\",\n"
                        + "    \"responseDesription\": \"Success\"\n"
                        + "}"));
    }

}

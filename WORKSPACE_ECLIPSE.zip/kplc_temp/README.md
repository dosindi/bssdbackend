# KPLC Interface

## Configs

u.NICBANK
p.test123!
Consumer Key : H6eaih7dnJyADD4acoGnVXp5dzAa
Consumer Secret : tnUPduirE4a5XN8_0fLf11Jp0Pwa

### SAMPLE
initial config
key : aVU9QTX+PM9Nmp690uI8SRt8u1NuEHYE7mJNK5jCgcY=
secret: nYeVgcfLoVZ1Rt42Df8p6VpBaROptX0bZKtbGooKCMc=





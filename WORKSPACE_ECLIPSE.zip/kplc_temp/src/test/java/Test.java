
import com.ncba.kplc.utils.AESencrp;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Duncan.Nyakundi
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        String msg = ",@id::@id/payment.ref.no::payment.ref.no/bank.code::bank.code/ac.number::ac.number/id.number::id.number/coll.type::coll.type/request.time::request.time/txn.reference::txn.reference/payment.method::payment.method/REGION::REGION,\"PRN211937SS96                      \"	\"NSSF5377661477                     \"	\"                                   \"	\"                                   \"	\"                                   \"	\"NSSF                               \"	\"2109220612                         \"	\"                   \"	\"          \"	\"KAMPALA                       \"";
//
//        String[] split = msg.split("\"");
//
//        for (int x = 0; x < split.length; x++) {
//            System.out.println("---"+split[x]);

        int[] A = {1, 2, 3, 4}; //5
//        int[] A = {-1,-2,-3};//1
//       int[] A = {1,1,2,3,4,6}; //5
        int s = solution(A);
        System.out.println("sol: " + s);

        try {
//            String url = AESencrp.decrypt("jYCYJ8HplVeX+yHAOPOuy1UqDPE2ep/LXZf5lafsx16/KyLgRp0BVw/F5wKoQPxunnqp+x+JFG+yRI29Zg1zvAJB1wYrJBHyseyqpfpQw/0=");
//            String user = AESencrp.decrypt("Wz8gvD7s9Skl8un0iNCmZg==");
//            String pass = AESencrp.decrypt("qCu+KP7wmTd31VcBrPjBsg==");
//            System.out.println(" " + url + " ||" + user + " ||" + pass);

            String url1 = AESencrp.encrypt("jdbc:mysql://127.0.0.1:3307/interfaces_schema?zeroDateTimeBehavior=convertToNull");
            String user1 = AESencrp.encrypt("interfaceuser");
            String pass1 = AESencrp.encrypt("password");
            String p = AESencrp.encrypt("test123!");
            String key = AESencrp.encrypt("H6eaih7dnJyADD4acoGnVXp5dzAa");
            String secret = AESencrp.encrypt("tnUPduirE4a5XN8_0fLf11Jp0Pwa");
            
            String key1 = AESencrp.decrypt("BfBI9XD8IWnxWFmchAElkw==");
            String secret1 = AESencrp.decrypt("nEeDojpAa03sO/EN3MF73Q==");
            
            System.out.println( url1 + " ||" + user1 + " ||" + pass1+"||p:"+p+"||key:"+key+"||secret:"+secret);
            
            System.out.println("-------------------------------------------------");
            System.out.println("key: "+key1+"||"+secret1);
                    

        } catch (IOException e) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, e);
        } catch (Exception ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static int solution(int[] A) {
        int result = 0;
        int temp = 0;
        for (int x = 1; x < 100000 && temp != 0; x++) {

        }
        for (int x : A) {
            if (x > 1 && x < 100000) {
                result = x;
            }
        }
        if (result == 0) {
            result = 1;
        }

        return result;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
//import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author root
 */
@Entity
@Table(name = "kplc_token", catalog = "interfaces_schema", schema = "")
//@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "KplcToken.findAll", query = "SELECT k FROM KplcToken k"),
    @NamedQuery(name = "KplcToken.findById", query = "SELECT k FROM KplcToken k WHERE k.id = :id"),
    @NamedQuery(name = "KplcToken.findByTimestamp", query = "SELECT k FROM KplcToken k WHERE k.timestamp = :timestamp"),
    @NamedQuery(name = "KplcToken.findByToken", query = "SELECT k FROM KplcToken k WHERE k.token = :token"),
    @NamedQuery(name = "KplcToken.findByLastFetchTime", query = "SELECT k FROM KplcToken k WHERE k.lastFetchTime = :lastFetchTime"),
    @NamedQuery(name = "KplcToken.findByExpiryTime", query = "SELECT k FROM KplcToken k WHERE k.expiryTime = :expiryTime")})
public class KplcToken implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "timestamp")
    @Temporal(TemporalType.TIMESTAMP)
    private Date timestamp;
    @Basic(optional = false)
    @Column(name = "token")
    private String token;
    @Column(name = "last_fetch_time")
    private String lastFetchTime;
    @Column(name = "expiryTime")
    private Integer expiryTime;

    public KplcToken() {
    }

    public KplcToken(Integer id) {
        this.id = id;
    }

    public KplcToken(Integer id, Date timestamp, String token) {
        this.id = id;
        this.timestamp = timestamp;
        this.token = token;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getLastFetchTime() {
        return lastFetchTime;
    }

    public void setLastFetchTime(String lastFetchTime) {
        this.lastFetchTime = lastFetchTime;
    }

    public Integer getExpiryTime() {
        return expiryTime;
    }

    public void setExpiryTime(Integer expiryTime) {
        this.expiryTime = expiryTime;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof KplcToken)) {
            return false;
        }
        KplcToken other = (KplcToken) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.nic.kplc.entities.KplcToken[ id=" + id + " ]";
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc.model;

import org.springframework.data.jpa.repository.JpaRepository;
import springfox.documentation.annotations.ApiIgnore;

/**
 *
 * @author Duncan.Nyakundi
 */
@ApiIgnore
public interface KplcTokenRepository extends JpaRepository<KplcToken,Integer> {
    
    
}

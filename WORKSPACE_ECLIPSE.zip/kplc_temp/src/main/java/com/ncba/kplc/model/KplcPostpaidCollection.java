/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author D N.
 */
@Entity
@Table(name = "kplc_postpaid_collection", catalog = "interfaces_schema", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "KplcPostpaidCollection.findAll", query = "SELECT k FROM KplcPostpaidCollection k"),
    @NamedQuery(name = "KplcPostpaidCollection.findByTimeStamp", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.timeStamp = :timeStamp"),
    @NamedQuery(name = "KplcPostpaidCollection.findById", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.id = :id"),
    @NamedQuery(name = "KplcPostpaidCollection.findByName", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.name = :name"),
    @NamedQuery(name = "KplcPostpaidCollection.findByMessage", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.message = :message"),
    @NamedQuery(name = "KplcPostpaidCollection.findByDateReceived", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.dateReceived = :dateReceived"),
    @NamedQuery(name = "KplcPostpaidCollection.findByKplcAccount", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.kplcAccount = :kplcAccount"),
    @NamedQuery(name = "KplcPostpaidCollection.findByKplcTxnId", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.kplcTxnId = :kplcTxnId"),
    @NamedQuery(name = "KplcPostpaidCollection.findByAmount", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.amount = :amount"),
    @NamedQuery(name = "KplcPostpaidCollection.findByStatus", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.status = :status"),
    @NamedQuery(name = "KplcPostpaidCollection.findByPaymentRef", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.paymentRef = :paymentRef"),
    @NamedQuery(name = "KplcPostpaidCollection.findByInputter", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.inputter = :inputter"),
    @NamedQuery(name = "KplcPostpaidCollection.findByAuthoriser", query = "SELECT k FROM KplcPostpaidCollection k WHERE k.authoriser = :authoriser")})
public class KplcPostpaidCollection implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "TimeStamp")
    @Temporal(TemporalType.TIMESTAMP)
    private Date timeStamp;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Column(name = "message")
    private String message;
    @Column(name = "date_received")
    private String dateReceived;
    @Basic(optional = false)
    @Column(name = "kplc_account")
    private String kplcAccount;
    @Basic(optional = false)
    @Column(name = "kplc_txn_id")
    private String kplcTxnId;
    @Basic(optional = false)
    @Column(name = "amount")
    private String amount;
    @Column(name = "status")
    private String status;
    @Basic(optional = false)
    @Column(name = "payment_ref")
    private String paymentRef;
    @Column(name = "inputter")
    private String inputter;
    @Column(name = "authoriser")
    private String authoriser;

    public KplcPostpaidCollection() {
    }

    public KplcPostpaidCollection(Integer id) {
        this.id = id;
    }

    public KplcPostpaidCollection(Integer id, Date timeStamp, String name, String kplcAccount, String kplcTxnId, String amount, String paymentRef) {
        this.id = id;
        this.timeStamp = timeStamp;
        this.name = name;
        this.kplcAccount = kplcAccount;
        this.kplcTxnId = kplcTxnId;
        this.amount = amount;
        this.paymentRef = paymentRef;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDateReceived() {
        return dateReceived;
    }

    public void setDateReceived(String dateReceived) {
        this.dateReceived = dateReceived;
    }

    public String getKplcAccount() {
        return kplcAccount;
    }

    public void setKplcAccount(String kplcAccount) {
        this.kplcAccount = kplcAccount;
    }

    public String getKplcTxnId() {
        return kplcTxnId;
    }

    public void setKplcTxnId(String kplcTxnId) {
        this.kplcTxnId = kplcTxnId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPaymentRef() {
        return paymentRef;
    }

    public void setPaymentRef(String paymentRef) {
        this.paymentRef = paymentRef;
    }

    public String getInputter() {
        return inputter;
    }

    public void setInputter(String inputter) {
        this.inputter = inputter;
    }

    public String getAuthoriser() {
        return authoriser;
    }

    public void setAuthoriser(String authoriser) {
        this.authoriser = authoriser;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof KplcPostpaidCollection)) {
            return false;
        }
        KplcPostpaidCollection other = (KplcPostpaidCollection) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.nic.kplc.entities.KplcPostpaidCollection[ id=" + id + " ]";
    }
    
}

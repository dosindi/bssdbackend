/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author root
 */
@Entity
@Table(name = "interface_param", catalog = "interfaces_schema", schema = "")
//@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "InterfaceParam.findAll", query = "SELECT i FROM InterfaceParam i"),
    @NamedQuery(name = "InterfaceParam.findById", query = "SELECT i FROM InterfaceParam i WHERE i.id = :id"),
    @NamedQuery(name = "InterfaceParam.findByTimestamp", query = "SELECT i FROM InterfaceParam i WHERE i.timestamp = :timestamp"),
    @NamedQuery(name = "InterfaceParam.findByParamName", query = "SELECT i FROM InterfaceParam i WHERE i.paramName = :paramName"),
    @NamedQuery(name = "InterfaceParam.findByAllowedIp", query = "SELECT i FROM InterfaceParam i WHERE i.allowedIp = :allowedIp"),
    @NamedQuery(name = "InterfaceParam.findByInterfaceUser", query = "SELECT i FROM InterfaceParam i WHERE i.interfaceUser = :interfaceUser"),
    @NamedQuery(name = "InterfaceParam.findByInterfacePassword", query = "SELECT i FROM InterfaceParam i WHERE i.interfacePassword = :interfacePassword"),
    @NamedQuery(name = "InterfaceParam.findByInterfacePort", query = "SELECT i FROM InterfaceParam i WHERE i.interfacePort = :interfacePort"),
    @NamedQuery(name = "InterfaceParam.findByIsoXmlFile", query = "SELECT i FROM InterfaceParam i WHERE i.isoXmlFile = :isoXmlFile"),
    @NamedQuery(name = "InterfaceParam.findByT24Ip", query = "SELECT i FROM InterfaceParam i WHERE i.t24Ip = :t24Ip"),
    @NamedQuery(name = "InterfaceParam.findByT24Port", query = "SELECT i FROM InterfaceParam i WHERE i.t24Port = :t24Port"),
    @NamedQuery(name = "InterfaceParam.findByT24Subroutine", query = "SELECT i FROM InterfaceParam i WHERE i.t24Subroutine = :t24Subroutine"),
    @NamedQuery(name = "InterfaceParam.findByT24Version", query = "SELECT i FROM InterfaceParam i WHERE i.t24Version = :t24Version"),
    @NamedQuery(name = "InterfaceParam.findByExtIp", query = "SELECT i FROM InterfaceParam i WHERE i.extIp = :extIp"),
    @NamedQuery(name = "InterfaceParam.findByExtPort", query = "SELECT i FROM InterfaceParam i WHERE i.extPort = :extPort"),
    @NamedQuery(name = "InterfaceParam.findByExtUser", query = "SELECT i FROM InterfaceParam i WHERE i.extUser = :extUser"),
    @NamedQuery(name = "InterfaceParam.findByExtPassword", query = "SELECT i FROM InterfaceParam i WHERE i.extPassword = :extPassword"),
    @NamedQuery(name = "InterfaceParam.findByMsgSource", query = "SELECT i FROM InterfaceParam i WHERE i.msgSource = :msgSource"),
    @NamedQuery(name = "InterfaceParam.findByMsgDestination", query = "SELECT i FROM InterfaceParam i WHERE i.msgDestination = :msgDestination"),
    @NamedQuery(name = "InterfaceParam.findByMsgError", query = "SELECT i FROM InterfaceParam i WHERE i.msgError = :msgError")})
public class InterfaceParam implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "timestamp")
    @Temporal(TemporalType.TIMESTAMP)
    private Date timestamp;
    @Basic(optional = false)
    @Column(name = "param_name")
    private String paramName;
    @Column(name = "allowed_ip")
    private String allowedIp;
    @Column(name = "interface_user")
    private String interfaceUser;
    @Column(name = "interface_password")
    private String interfacePassword;
    @Column(name = "interface_port")
    private String interfacePort;
    @Column(name = "iso_xml_file")
    private String isoXmlFile;
    @Column(name = "t24_ip")
    private String t24Ip;
    @Column(name = "t24_port")
    private String t24Port;
    @Column(name = "t24_subroutine")
    private String t24Subroutine;
    @Column(name = "t24_version")
    private String t24Version;
    @Column(name = "ext_ip")
    private String extIp;
    @Column(name = "ext_port")
    private String extPort;
    @Column(name = "ext_user")
    private String extUser;
    @Column(name = "ext_password")
    private String extPassword;
    @Column(name = "msg_source")
    private String msgSource;
    @Column(name = "msg_destination")
    private String msgDestination;
    @Column(name = "msg_error")
    private String msgError;

    public InterfaceParam() {
    }

    public InterfaceParam(Integer id) {
        this.id = id;
    }

    public InterfaceParam(Integer id, Date timestamp, String paramName) {
        this.id = id;
        this.timestamp = timestamp;
        this.paramName = paramName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getParamName() {
        return paramName;
    }

    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    public String getAllowedIp() {
        return allowedIp;
    }

    public void setAllowedIp(String allowedIp) {
        this.allowedIp = allowedIp;
    }

    public String getInterfaceUser() {
        return interfaceUser;
    }

    public void setInterfaceUser(String interfaceUser) {
        this.interfaceUser = interfaceUser;
    }

    public String getInterfacePassword() {
        return interfacePassword;
    }

    public void setInterfacePassword(String interfacePassword) {
        this.interfacePassword = interfacePassword;
    }

    public String getInterfacePort() {
        return interfacePort;
    }

    public void setInterfacePort(String interfacePort) {
        this.interfacePort = interfacePort;
    }

    public String getIsoXmlFile() {
        return isoXmlFile;
    }

    public void setIsoXmlFile(String isoXmlFile) {
        this.isoXmlFile = isoXmlFile;
    }

    public String getT24Ip() {
        return t24Ip;
    }

    public void setT24Ip(String t24Ip) {
        this.t24Ip = t24Ip;
    }

    public String getT24Port() {
        return t24Port;
    }

    public void setT24Port(String t24Port) {
        this.t24Port = t24Port;
    }

    public String getT24Subroutine() {
        return t24Subroutine;
    }

    public void setT24Subroutine(String t24Subroutine) {
        this.t24Subroutine = t24Subroutine;
    }

    public String getT24Version() {
        return t24Version;
    }

    public void setT24Version(String t24Version) {
        this.t24Version = t24Version;
    }

    public String getExtIp() {
        return extIp;
    }

    public void setExtIp(String extIp) {
        this.extIp = extIp;
    }

    public String getExtPort() {
        return extPort;
    }

    public void setExtPort(String extPort) {
        this.extPort = extPort;
    }

    public String getExtUser() {
        return extUser;
    }

    public void setExtUser(String extUser) {
        this.extUser = extUser;
    }

    public String getExtPassword() {
        return extPassword;
    }

    public void setExtPassword(String extPassword) {
        this.extPassword = extPassword;
    }

    public String getMsgSource() {
        return msgSource;
    }

    public void setMsgSource(String msgSource) {
        this.msgSource = msgSource;
    }

    public String getMsgDestination() {
        return msgDestination;
    }

    public void setMsgDestination(String msgDestination) {
        this.msgDestination = msgDestination;
    }

    public String getMsgError() {
        return msgError;
    }

    public void setMsgError(String msgError) {
        this.msgError = msgError;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof InterfaceParam)) {
            return false;
        }
        InterfaceParam other = (InterfaceParam) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.nic.kplc.entities.InterfaceParam[ id=" + id + " ]";
    }
    
}

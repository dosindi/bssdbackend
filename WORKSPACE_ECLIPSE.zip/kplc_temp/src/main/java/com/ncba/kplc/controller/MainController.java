/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc.controller;

import com.ncba.kplc.request.NotificationRequest;
import com.ncba.kplc.request.ValidationRequest;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author Duncan.Nyakundi
 * @description
 *
 * 1. Validation Requests 2. Payment Notification Requests 3. OFS queue spooling
 * 4. Token update
 *
 */
@RestController
public class MainController {

    public static Logger log = Logger.getLogger(MainController.class.getName());

    @Autowired
    public MainService mainService;

    @Value("${T24.server.port}")
    public int port;

    @Value("${T24.server.ip}")
    public String host;

    Socket socket = null;
    String fields = "";
    String message = "";
    String function = "";
    String recordId = "";

    @Value("${T24.credential}")
    public String credential;

    String application = "";

    byte[] bytes = null;

    @Value("${kplc.endpoint}")
    public String endpoint;

    @Value("${kplc.apikey}")
    public String apikey;

    @Value("${kplc.privatekey}")
    public String privatekey;

    @GetMapping("/api/poolOFS")
    public String getOfs() {

//        getENQUIRY();
        // bytes = BuildOFS();
        bytes = LazyOFS(); // executes ofs string

        long startTime = System.nanoTime();

        String resp = processOFS(bytes);

        long estimatedTime = System.nanoTime() - startTime;

        log.info("Lapse Time: " + (estimatedTime / 1000000) + " ms");

        sortDictionary(resp);

        return resp;
    }

    private byte[] LazyOFS() {

        byte[] bytes = null;
//        message = "ENQUIRY.SELECT,,INPUTT/Forester*123/KE0010001,E.FCDB.COLL.PMT.1,RESULT:EQ=VALID,ICON.STATUS:EQ=QUEUED,COLL.TYPE:EQ=KPLC";
//        message = "ENQUIRY.SELECT,," + credential + ",CBA.COLLECTIONS.REQUEST";
//        message = "ENQUIRY.SELECT,,INPUTT/Forester*123/KE0010001,E.FCDB.COLL.PMT.3,RESULT:EQ=VALID,ICON.STATUS:EQ=QUEUED,COLL.TYPE:EQ=KPLC";
//        message = "H.CBA.COLL.RESP,INPUT/I/PROCESS,ICON.COLL.USER/Kenya123/UG0010001,NSSF9228786605,RESULT::=INVALID,REMARKS::=307 Incorrect signature.,ICON.STATUS::=PROCESSED,COLL.TYPE::=NSSF";

//        message = "FUNDS.TRANSFER,CBA.FCDB.INP.INTN.TXNS/I/PROCESS,mahitae/Kenya123/KE0010001,,ORD.CUS.ADDRESS=470025,ORDERING.CUST=470025,DEBIT.ACCT.NO=4700250023,DEBIT.CURRENCY=USD,CREDIT.AMOUNT=100,CREDIT.CURRENCY=USD,BEN.ACCT.NO=AE690260001025406080702,BEN.CUSTOMER:1=GURTAM DMCC,BEN.CUSTOMER:2=177 UAE,BEN.CUSTOMER:3=,SWIFT.CODE=NBDUAEAD,UPLOAD.LOCAL.6=BUNEYAS DEIRA,COMMISSION.TYPE=FCDBOTIN,BEN.OUR.CHARGES=OUR,REF.TXN.ID=200824139631500,FX.REFERENCE=,INTMD.BANK.CODE=,FCDB.TXN.CODE=ITR,PURPOSE.CODE=,ACCT.WITH.BANK=SW-NBDUAEAD,ACC.WITH.BK.BIC=NBDUAEAD,PAYMENT.DETAILS=CATERING";
        message="FUNDS.TRANSFER,FCDB.CBA.CORP.INP.RTGS/I/PROCESS,FCDBUSER01/Forester*123/KE0010001,/204274829637807,ORDERING.CUST=776662,DEBIT.ACCT.NO=7766620014,DEBIT.CURRENCY=KES,CREDIT.AMOUNT=100,ACC.WITH.BK.BIC=BARCKENX,UPLOAD.LOCAL.6=03090,BEN.ACCT.NO=545664,BEN.CUSTOMER:1=3457,BEN.CUSTOMER:2=3457 Fedha Nairobi,BEN.CUSTOMER:3=3457 Fedha Nairobi,CREDIT.CURRENCY=KES,PURPOSE.CODE=,FX.REFERENCE=,COMMISSION.TYPE=FCDBOTGS,REF.TXN.ID=204274829637807,PAYMENT.DETAILS=TRIAL,FX.REFERENCE=,BEN.OUR.CHARGES=SHA,FCDB.TXN.CODE=RTGS,ACCT.WITH.BANK=SW-BARCKENX";
        log.info(host + ":" + port + " - " + message);
        bytes = message.getBytes();

        return bytes;
    }

    private String processOFS(byte[] bytes) {
        socket = new Socket();
        DataInputStream dIn = null;
        DataOutputStream dOut = null;

        try {
            socket.connect(new InetSocketAddress(host, port), 1000000);

            dOut = new DataOutputStream(socket.getOutputStream());
            dIn = new DataInputStream(socket.getInputStream());

            dOut.writeInt(bytes.length); // write length of the message
            dOut.write(bytes); // write the message

            int length = dIn.readInt(); // read length of incoming message
            if (length > 0) {
                bytes = new byte[length];
                dIn.readFully(bytes, 0, bytes.length); // read the message

                message = new String(bytes);
                log.info(host + ":" + port + " - " + message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                dIn.close();
                dOut.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return message;
    }

    private Dictionary<Integer, String> sortDictionary(String resp) {

        Dictionary<Integer, String> tbl = new Hashtable<>();
        if (resp.startsWith(",@ID::@ID,")) {
            resp = resp.replaceFirst(",@ID::@ID,", "");
            log.info(" ----" + resp);
            if (resp.contains(",") || !resp.contains("no records")) {
                String[] rows = resp.split(",");
                log.info("rows:" + rows.length);
                int k = 1;
                for (String row : rows) {
//                    log.info("--" + row);
                    String[] cols = row.split("	");
//                    KplcPostpaidCollection v = new KplcPostpaidCollection();
                    String v = cols[6].replace("\"", "").trim();
                    log.info(">>" + cols[0].replace("\"", "").trim() + "||" + cols[1].replace("\"", "").trim() + "||" + cols[2].replace("\"", "").trim() + "||" + cols[3].replace("\"", "").trim() + "||"
                            + cols[4].replace("\"", "").trim() + "||" + cols[5].replace("\"", "").trim() + "||" + cols[6].replace("\"", "").trim() + "||" + cols[7].replace("\"", "").trim() + "||" + cols[8].replace("\"", "").trim() + "||" + cols[9].replace("\"", "").trim()
                            + "||" + cols[10].replace("\"", "").trim() + "||" + cols[11].replace("\"", "").trim() + "||" + cols[12].replace("\"", "").trim() + "||" + cols[13].replace("\"", "").trim() + "||"
                            + cols[14].replace("\"", "").trim());
//                    for (String col : cols) {
//                        String temp = col.trim();
//                        log.info("temp:"+temp);
////                        if (temp != null) {
//                            if (temp.startsWith("\"FT") || temp.startsWith("\"TT")) {
////                                v.setPaymentRef(temp);
//                                v = temp.replace("\"", "").trim();
//                            }
////                        }
//                    }
                    tbl.put(k, v);
                    k++;
                }
            } else {
                log.info("no record to process");
            }
        }

        log.info(">" + tbl);

        return tbl;

    }

    /*
     * Validation Request
     */
    @PostMapping("/api/validation")
    public @ResponseBody
    ResponseEntity<Object> getValidation(@RequestBody ValidationRequest request) throws Exception {

        String result = "";
        if (request != null) {
            result = mainService.getValidation(request.getAccount());
        }
        return new ResponseEntity(result, HttpStatus.OK);
    }

    /*
     * Post Payment Notification Request
     */
    @PostMapping("/api/paymentNotification")
    public @ResponseBody
    ResponseEntity<Object> postPayment(@RequestBody NotificationRequest request) {

        String result = "";
        if (request != null) {
            try {
                result = mainService.postPayment(request);
                log.info("result: " + result);
            } catch (Exception ex) {

                log.info("exception: " + ex);
                return new ResponseEntity(ex, HttpStatus.BAD_GATEWAY);
            }
        }
        return new ResponseEntity(result, HttpStatus.OK);
    }
}

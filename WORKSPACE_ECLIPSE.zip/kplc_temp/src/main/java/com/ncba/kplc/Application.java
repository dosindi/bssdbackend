package com.ncba.kplc;

import com.ncba.kplc.controller.MainService;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@EnableScheduling
@SpringBootApplication
public class Application {

    @Autowired
    public MainService service;

    @Value("${T24.credential}")
    public String credential;

    @Value("${MSG.NO.RECORD}")
    public String NO_RECORD;

    @Value("${SAMPLE.TQUEUED}")
    public String TQUEUED;

    @Value("${TQUEUED.POSITION}")
    public int POS;

    @Value("${T24.user}")
    public String tuser;

    public static final Logger log = Logger.getLogger(Application.class.getName());

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

//    @Scheduled(fixedDelay = 10000)
//    @Scheduled(cron = "10 * * * * ?")
    public void pollCore() {
        /*
            Returns 1 queued transaction:
            ENQUIRY.SELECT,,INPUTT/Forester*123/KE0010001,E.FCDB.COLL.PMT.1,RESULT:EQ=VALID,ICON.STATUS:EQ=QUEUED,COLL.TYPE:EQ=KPLC

            Returns 3 queued transaction:
            ENQUIRY.SELECT,,INPUTT/Forester*123/KE0010001,E.FCDB.COLL.PMT.3,RESULT:EQ=VALID,ICON.STATUS:EQ=QUEUED,COLL.TYPE:EQ=KPLC

            Returns 5 queued transaction:
            ENQUIRY.SELECT,,INPUTT/Forester*123/KE0010001,E.FCDB.COLL.PMT.5,RESULT:EQ=VALID,ICON.STATUS:EQ=QUEUED,COLL.TYPE:EQ=KPLC 

            You can update ICON.STATUS of the queued item to PROCESSED using the existing version. We are using table H.CBA.COLL.RESP
        */

//        String pollQueued = "ENQUIRY.SELECT,," + credential + ",CBA.COLLECTIONS.REQUEST";
        String pollQueued = "ENQUIRY.SELECT,,INPUTT/" + credential + ",E.FCDB.COLL.PMT.3,RESULT:EQ=VALID,ICON.STATUS:EQ=QUEUED,COLL.TYPE:EQ=KPLC";
        String msg = service.mainPoll(pollQueued);
//        String msg = TQUEUED;
        log.log(Level.INFO, "core response: {0}", msg);
        if (msg.contains(NO_RECORD)) {
            log.info("Skip NO_RECORD");
        } else {
            String splitter = getSplitter(msg);
//            GetTransactionResponse response = service.getTransactionRequest(splitter);

//            String logResponse = service.toXmlString(GetTransactionResponse.class, response);
//            log.log(Level.INFO, "logResponse: {0}", logResponse);
//            switch (response.getErrorCode()) {
//                case 200:
//                    buildValidOFS(response);
//                    break;
//                default:
//                    buildInvalidOFS(response);
//            }
        }
    }

    private String getSplitter(String msg) {
        String[] split = msg.split("\"");
        String val = "";
        if (split[POS].trim() != null) {
            val = split[POS].trim();
        }
        return val;
    }

    private void buildValidOFS() {
//        log.log(Level.INFO, "VALID ofs: {0}", response.getErrorMessage());
//        String iResponse = "H.CBA.COLL.RESP,INPUT/I/PROCESS," + tuser
//                + "/UG0010001,RESULT::=VALID"
//                + ",REMARKS::=" + response.getErrorCode()
//                + ",CORP.NO::=" + response.getEmployerNo()
//                + ",CORP.NAME::=" + response.getEmployer()
//                + ",ADVICE.DATE::=" + response.getUplDatetime()
//                + ",BILLED.AMOUNT::=" + response.getTotal()
//                + ",TOTAL.PAYMENT.AMT::=" + response.getTotal()
//                + ",CURRENCY::=UGX"
//                + ",ICON.STATUS::=PROCESSED"
//                + ",COLL.TYPE::=NSSF"
//                + ",EMAIL.ADDRESS::=none"
//                + ",PAYMENT.METHOD::=" + response.getPaymentMethod()
//                + ",PAYMENT.REF.NO::=" + response.getReference()
//                + ",PAYMENT.PERIOD::=" + response.getPeriod();
//        log.log(Level.INFO, "post iResponse:{0}", iResponse);
//        String r = service.mainPoll(iResponse);
//        log.log(Level.INFO, "tResponse{0}", r);

    }

    private void buildInvalidOFS() {
//        log.log(Level.INFO, "INVALID ofs: {0}", response.getErrorMessage());
//        String iResponse = "H.CBA.COLL.RESP,INPUT/I/PROCESS," + tuser
//                + "/UG0010001,"
//                + response.getReference()
//                + ",RESULT::=INVALID,REMARKS::=" + response.getErrorCode() + " " + response.getErrorMessage()
//                + ",ICON.STATUS::=PROCESSED,COLL.TYPE::=NSSF";
//        log.log(Level.INFO, "post iResponse:{0}", iResponse);
//        String r = service.mainPoll(iResponse);
//        log.log(Level.INFO, "tResponse{0}", r);
    }

}

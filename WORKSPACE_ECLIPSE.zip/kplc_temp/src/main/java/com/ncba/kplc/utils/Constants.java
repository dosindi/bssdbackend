/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc.utils;

/**
 *
 * @author Duncan.Nyakundi
 */
public class Constants {
	public static final String INPUT_VALIDATION_ERROR_MESSAGE = "Input Validation Error. Please check the input";
	public static final String INVALID_ENTITY_ID = "Product ID is invalid. Please enter valid Product ID";	
	public static final String INTERNAL_SERVER_ERROR_MESSAGE = "Internal Server Error. Please try again later";
	public static final String SERVICE_NULL_RESPONSE = "Null response from Service";

}

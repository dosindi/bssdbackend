/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc.controller.advisor;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 *
 * @author Duncan.Nyakundi
 */
@ControllerAdvice
public class DefaultExceptionHandler {

    public static Logger log = Logger.getLogger(DefaultExceptionHandler.class);

//    @ExceptionHandler
//    public ResponseEntity<EntityErrorResponse> handleException(EntityIdInvalidException exception) {
//        EntityErrorResponse productErrorResponse = new EntityErrorResponse();
//
//        productErrorResponse.setStatus(HttpStatus.NOT_FOUND.value());
//        productErrorResponse.setMessage(exception.getMessage());
//        productErrorResponse.setTimeStamp(System.currentTimeMillis());
//
//        log.error(exception.getMessage());
//
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(productErrorResponse);
//    }
}

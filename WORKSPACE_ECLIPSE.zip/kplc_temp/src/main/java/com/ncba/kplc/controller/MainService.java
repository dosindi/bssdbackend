/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc.controller;

import com.ncba.kplc.model.InterfaceParam;
import com.ncba.kplc.model.InterfaceParamRepository;
import com.ncba.kplc.model.KplcToken;
import com.ncba.kplc.model.KplcTokenRepository;
import com.ncba.kplc.request.NotificationRequest;
import com.ncba.kplc.utils.AESencrp;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.json.JSONObject;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.HttpResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
//import org.wso2.carbon.automation.test.utils.http.HttpResponse;
//import org.wso2.carbon.automation.test.utils.http.client.HttpRequestUtil;

/**
 *
 * @author Duncan.Nyakundi
 *
 */
@Service
public class MainService {

    public static Logger log = Logger.getLogger(MainService.class.getName());
    private static String CONSUMER_KEY;
    private static String CONSUMER_SECRET;
    private static String KPLC_TOKEN_URL;
    private static String TOKEN_PASSWORD;
    private static String TOKEN_SCOPE;
    private static String TOKEN_USER;

    @Value("${T24.server.port}")
    public int port;

    @Value("${T24.server.ip}")
    public String host;

    Socket socket = null;
    String fields = "";
    String message = "";
    String function = "";
    String recordId = "";
    String application = "";

    byte[] bytes = null;

    @Value("${kplc.endpoint}")
    public String endpoint;

    @Value("${kplc.apikey}")
    public String apikey;

    @Value("${kplc.privatekey}")
    public String privatekey;

    @Autowired
    KplcTokenRepository kplcTokenRepository;

    @Autowired
    InterfaceParamRepository interfaceParamRepository;

    private String PAYMENT_CENTER_CODE;
    private int PORT;
    private String ISO_XML_FILE;
    private String VALIDATION;
    private String VALIDATION_SOAPACTION;
    private String PAYMENT;

    private String PAYMENT_SOAPACTION;
    private String ALLOWED_IP;
    private String AUTHHEADER;

    public String mainPoll(String message) {

        bytes = LazyOFS(message); // executes ofs string

        long startTime = System.nanoTime();

        String resp = processOFS(bytes);

        long estimatedTime = System.nanoTime() - startTime;

        log.info("Lapse Time: " + (estimatedTime / 1000000) + " ms");

        return resp;
    }

    private byte[] LazyOFS(String message) {

        byte[] bytes = null;

//        message = "ENQUIRY.SELECT,,UPGRADE.1/Kenya123,CBA.COLLECTIONS.REQUEST";
//        message = "H.CBA.COLL.RESP,INPUT/I/PROCESS,ICON.COLL.USER/Kenya123/UG0010001,NSSF9228786605,RESULT::=INVALID,REMARKS::=307 Incorrect signature.,ICON.STATUS::=PROCESSED,COLL.TYPE::=NSSF";
//        System.out.println(host + ":" + port + " - " + message);
        bytes = message.getBytes();

        return bytes;
    }

    private String processOFS(byte[] bytes) {
        socket = new Socket();
        DataInputStream dIn = null;
        DataOutputStream dOut = null;

        try {
            socket.connect(new InetSocketAddress(host, port), 1000000);

            dOut = new DataOutputStream(socket.getOutputStream());
            dIn = new DataInputStream(socket.getInputStream());

            dOut.writeInt(bytes.length); // write length of the message
            dOut.write(bytes); // write the message

            int length = dIn.readInt(); // read length of incoming message
            if (length > 0) {
                bytes = new byte[length];
                dIn.readFully(bytes, 0, bytes.length); // read the message

                message = new String(bytes);
                log.info(host + ":" + port + " - " + message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                dIn.close();
                dOut.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return message;
    }

    /*
        Util methods
     */
    public String getSignature(String num) {

        String res = DigestUtils.sha1Hex(apikey.concat(num).concat(privatekey));

        return res;

    }

    public String toXmlStringWithoutRoot(Class cl, Object ob, String qName) throws PropertyException, JAXBException {
        StringWriter sw = new StringWriter();

        JAXBContext context = JAXBContext.newInstance(cl);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        JAXBElement jx = new JAXBElement(new QName(qName), cl, ob);
        marshaller.marshal(jx, sw);

        return sw.toString();

    }

    public String toXmlString(Class cl, Object ob) {

        JAXBContext context;
        StringWriter sw = new StringWriter();
        try {
            context = JAXBContext.newInstance(cl);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(ob, sw);
        } catch (JAXBException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return sw.toString();
    }

    public String getToken() throws Exception {

        setConfig();

        Optional<KplcToken> tks = kplcTokenRepository.findById(1);
        KplcToken tk = tks.get();
        String token = "";
        loadConfig();
        log.info("inside fetch token");
        try {

            URL tokenEndpointURL;
            JSONObject accessTokenRequest, tokenData = null;
            Map<String, String> authenticationRequestHeaders = new HashMap<String, String>();
            String basicAuthHeader = CONSUMER_KEY + ":" + CONSUMER_SECRET;
            String encodedBasicAuthHeader = DatatypeConverter.printBase64Binary(basicAuthHeader.getBytes("UTF-8"));
            authenticationRequestHeaders.put("Authorization", "Basic " + encodedBasicAuthHeader);

            tokenEndpointURL = new URL(KPLC_TOKEN_URL);
            String requestGrantType = "grant_type=password&username=" + TOKEN_USER + "&password=" + TOKEN_PASSWORD + "&scope=" + TOKEN_SCOPE;

            log.info("requestGrant:" + requestGrantType);

            String resp = callEndpoint(tokenEndpointURL, requestGrantType);
//            HttpResponse resp = HttpRequestUtil.doPost(tokenEndpointURL, requestGrantType, authenticationRequestHeaders);
            log.info("response::" + resp);
            accessTokenRequest = new JSONObject(resp);
            log.info("accessTokenRequest:" + accessTokenRequest);
            if (!accessTokenRequest.toString().isEmpty()) {
                String dataNodeInformation = accessTokenRequest.getString("data");
                log.info(dataNodeInformation);
                tokenData = new JSONObject(dataNodeInformation);
                token = tokenData.getString("access_token");
                String scope = tokenData.getString("scope");
                String token_type = tokenData.getString("token_type");
                int expires_in = tokenData.getInt("expires_in");
                String refresh_token = tokenData.getString("refresh_token");

                Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                Instant instant = timestamp.toInstant();
                long currentTime = instant.toEpochMilli();

                tk.setExpiryTime(expires_in);
                tk.setToken(token);
                tk.setLastFetchTime(String.valueOf(currentTime));

                KplcToken updateToken = kplcTokenRepository.save(tk);

                if (updateToken != null) {
                    log.info("Database update successful for token at " + timestamp);
                } else {
                    log.info("Database update failed for token at " + timestamp);
                }
            } else {
                log.info("get token response : empty ");
                token = "";
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(MainService.class.getName()).log(Level.SEVERE, null, ex);
            log.error("Get Token error: " + ex.getMessage());
            token = "";
        }
        return token;
    }

    public void setConfig() throws Exception {

        Optional<InterfaceParam> entities = interfaceParamRepository.findByParamName("kplc");
        InterfaceParam entity = entities.get();
        if (entity != null) {

            KPLC_TOKEN_URL = entity.getMsgSource();
            PAYMENT_CENTER_CODE = AESencrp.decrypt(entity.getT24Subroutine());
            PORT = Integer.parseInt(entity.getInterfacePort());
            ISO_XML_FILE = entity.getIsoXmlFile();
            VALIDATION = entity.getT24Ip().trim();
            VALIDATION_SOAPACTION = entity.getT24Port().trim();
            PAYMENT = entity.getExtIp().trim();
            PAYMENT_SOAPACTION = entity.getExtPort().trim();
            ALLOWED_IP = entity.getAllowedIp().trim();
            TOKEN_USER = AESencrp.decrypt(entity.getInterfaceUser());//"NICBANK";//
            TOKEN_PASSWORD = AESencrp.decrypt(entity.getInterfacePassword());// "test123!";//
            CONSUMER_KEY = AESencrp.decrypt(entity.getExtUser());//"H6eaih7dnJyADD4acoGnVXp5dzAa";//
            CONSUMER_SECRET = AESencrp.decrypt(entity.getExtPassword());//"tnUPduirE4a5XN8_0fLf11Jp0Pwa";//
            TOKEN_SCOPE = AESencrp.decrypt(entity.getT24Version());

            log.info(entity.getParamName().toUpperCase() + " parameters retrieved successfully ");
            log.info("Param Port Number: " + PORT);
            log.info("Param VALIDATION URL: " + VALIDATION);
            log.info("Param VALIDATION SOAP URL: " + VALIDATION_SOAPACTION);
            log.info("Param PAYMENT URL: " + PAYMENT);
            log.info("Param PAYMENT SOAP URL: " + PAYMENT_SOAPACTION);
            log.info("Param TOKEN URL: " + KPLC_TOKEN_URL);
            log.info("Param XML: " + ISO_XML_FILE);
            log.info("Allowed IP: " + ALLOWED_IP);

            String basicAuthHeader = CONSUMER_KEY + ":" + CONSUMER_SECRET;
            log.info("key:secret " + basicAuthHeader);
            AUTHHEADER = DatatypeConverter.printBase64Binary(basicAuthHeader.getBytes("UTF-8"));
        }

    }

    public void loadConfig() throws NoSuchAlgorithmException, KeyManagementException {

        TrustManager[] trustAllCerts = new TrustManager[]{
            new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }

                @Override
                public void checkClientTrusted(
                        java.security.cert.X509Certificate[] certificates, String authType) {
                }

                @Override
                public void checkServerTrusted(
                        java.security.cert.X509Certificate[] certificates, String authType) {
                }
            }
        };
//        connectionFactory.setKeyAndTrustManagers(null, trustAllCerts, new SecureRandom());

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());

        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

//        System.setProperty("https.proxyHost", proxy_ip);
//        System.setProperty("https.proxyPort", proxy_port);
        System.setProperty("https.proxyHost", "10.1.0.1");
        System.setProperty("https.proxyPort", "8383");
    }

    public String callEndpoint(URL url, String input) throws Exception {

        String result = "";
        loadConfig();
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Authorization", AUTHHEADER);
//        con.setRequestProperty("Content-Type", "application/json");
//        con.setRequestProperty("Accept", "application/json");
        con.setConnectTimeout(60000);
        con.setReadTimeout(60000);
        con.setDoOutput(true);
        try (OutputStream os = con.getOutputStream()) {
            os.write(input.getBytes());
            os.flush();
        } catch (UnknownHostException e) {
            log.info(e);
            con.disconnect();
        }
        int responseCode = con.getResponseCode();
        log.info("Response Code :: " + responseCode);
        if (responseCode == HttpURLConnection.HTTP_OK) {
            StringBuilder response;
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                response = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
            }
            result = response.toString();
            org.codehaus.jettison.json.JSONObject jsonObject = new org.codehaus.jettison.json.JSONObject(response.toString());
            log.info("Response from KPLC: " + response.toString());

            String responseMessage = jsonObject.getString("responseMessage");

            result = responseCode + "|" + responseMessage;

        } else {
            StringBuilder response;
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getErrorStream()))) {
                String inputLine;
                response = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
            }
            org.codehaus.jettison.json.JSONObject jsonObject = new org.codehaus.jettison.json.JSONObject(response.toString());
            log.info("Response from KPLC: " + response.toString());

            String errorMsg = jsonObject.getString("Message");
            result = responseCode + "|Error Message" + errorMsg;
            log.error("Error Response :: " + response.toString());

        }

        return result;
    }

    public String getValidation(String account) throws Exception {
        String result = "";
        String token = getToken();
        if (!token.trim().isEmpty()) {

            try {
                loadConfig();
                URL url = new URL(VALIDATION);
                URLConnection connection = url.openConnection();
                HttpURLConnection httpConn = (HttpURLConnection) connection;
                ByteArrayOutputStream bout = new ByteArrayOutputStream();

                String xmlInput = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:inc=\"http://incms.indra.es/IncmsAccount/\">\n"
                        + "   <soapenv:Header/>\n"
                        + "   <soapenv:Body>\n"
                        + "      <inc:AccountBalance>\n"
                        + "         <Account>" + account + "</Account>\n"
                        + "      </inc:AccountBalance>\n"
                        + "   </soapenv:Body>\n"
                        + "</soapenv:Envelope>";

                log.info(account + "  Validation request: " + xmlInput);
                byte[] buffer = new byte[xmlInput.length()];
                buffer = xmlInput.getBytes();
                bout.write(buffer);
                byte[] b = bout.toByteArray();

// Set the appropriate HTTP parameters.
                httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
                httpConn.setRequestProperty("Content-Type", "text/xml;charset=utf-8");
                httpConn.setRequestProperty("SOAPAction", VALIDATION_SOAPACTION);
                httpConn.setRequestProperty("Authorization", "Bearer " + token);
                httpConn.setRequestMethod("POST");
                httpConn.setDoOutput(true);
                httpConn.setDoInput(true);

                //send request
                DataOutputStream wr = new DataOutputStream(httpConn.getOutputStream());
                wr.writeBytes(xmlInput);
                wr.flush();
                wr.close();

                //get response
                BufferedReader in = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                log.info(account + " Validation response: " + response.toString());

                if (!response.toString().isEmpty()) {
                    try {
                        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();//
                        Document doc = dBuilder.parse(new ByteArrayInputStream(response.toString().getBytes("UTF-8")));
                        doc.getDocumentElement().normalize();
                        String respCode = doc.getElementsByTagName("ns1:code").item(0).getTextContent();
                        String message = doc.getElementsByTagName("ns1:message").item(0).getTextContent();
                        if (respCode.equals("0")) {
                            String name = doc.getElementsByTagName("ns1:fullName").item(0).getTextContent();
                            String balance = doc.getElementsByTagName("ns1:balance").item(0).getTextContent();
                            String due_date = doc.getElementsByTagName("ns1:dueDate").item(0).getTextContent();
                            String lastAmount = doc.getElementsByTagName("ns1:lastAmount").item(0).getTextContent();
                            String acctref = doc.getElementsByTagName("ns1:accountReference").item(0).getTextContent();

                            result = "00^SUCCESS|" + account + "^" + name + "^" + balance + "^" + due_date;
                        } else {
                            result = "01^" + message;

                        }
                    } catch (Exception ex) {
                        log.error(" Webservice validation error: " + ex.getMessage());
                        result = "01^Validation for account " + account + " Failed ";
                        ex.printStackTrace();
                    }
                }
            } catch (Exception ex) {
                log.error(" Webservice validation error: " + ex.getMessage());
                ex.printStackTrace();
                result = "01^Validation for account " + account + " Failed";
            }
        } else {
            log.error(" Token missing ");
            result = "01^Token missing " + account;
        }
        return result;
    }

    public String postPayment(NotificationRequest n) throws Exception {

        String result = "";
        String token = getToken();
        if (!token.trim().isEmpty()) {
            //Code to make a webservice HTTP request
            try {
                loadConfig();
                URL url = new URL(PAYMENT);
                URLConnection connection = url.openConnection();
                HttpURLConnection httpConn = (HttpURLConnection) connection;
                ByteArrayOutputStream bout = new ByteArrayOutputStream();

                String xmlInput = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:inc=\"http://incms.indra.es/IncmsPayment/\">\n"
                        + "   <soapenv:Header/>\n"
                        + "   <soapenv:Body>\n"
                        + "      <inc:PaymentRegister>\n"
                        + "         <PaymentCenterCode>" + PAYMENT_CENTER_CODE + "</PaymentCenterCode>\n"
                        + "         <PaymentSubAgencyCode>" + n.getPaymentSubAgencyCode() + "</PaymentSubAgencyCode>\n"
                        + "         <ReferenceNumber>" + n.getAccount() + "</ReferenceNumber>\n"
                        + "         <PaymentDate>" + n.getPaymentDate() + "</PaymentDate>\n"
                        + "         <PaymentAmount>" + n.getPaymentAmount() + "</PaymentAmount>\n"
                        + "         <CheckNumber>" + n.getCheckNumber() + "</CheckNumber>\n"
                        + "         <AuxData>" + n.getT24_reference() + "</AuxData>\n"
                        + "         <PaymentEmail>" + n.getEmail() + "</PaymentEmail>\n"
                        + "         <RecordType>" + n.getRecordType() + "</RecordType>\n"
                        + "         <ExternalData>" + n.getExternalData() + "</ExternalData>\n"
                        + "         <ListData>\n"
                        + "            <Data>\n"
                        + "               <Code>" + n.getCode() + "</Code>\n"
                        + "               <Value>" + n.getValue() + "</Value>\n"
                        + "            </Data>\n"
                        + "         </ListData>\n"
                        + "      </inc:PaymentRegister>\n"
                        + "   </soapenv:Body>\n"
                        + "</soapenv:Envelope>";
                log.info(n.getAccount() + " t24 reference " + n.getT24_reference() + " payment request: " + xmlInput);

                byte[] buffer = new byte[xmlInput.length()];
                buffer = xmlInput.getBytes();
                bout.write(buffer);
                byte[] b = bout.toByteArray();

// Set the appropriate HTTP parameters.
                httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
                httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
                httpConn.setRequestProperty("SOAPAction", PAYMENT_SOAPACTION);
                httpConn.setRequestProperty("Authorization", "Bearer " + token);
                httpConn.setRequestMethod("POST");
                httpConn.setDoOutput(true);
                httpConn.setDoInput(true);

                //send request
                DataOutputStream wr = new DataOutputStream(httpConn.getOutputStream());
                wr.writeBytes(xmlInput);
                wr.flush();
                wr.close();

                //get response
                BufferedReader in = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                log.info(n.getAccount() + " t24 reference " + n.getT24_reference() + " payment response: " + response.toString());

                if (!response.toString().isEmpty()) {
                    try {
                        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();//
                        Document doc = dBuilder.parse(new ByteArrayInputStream(response.toString().getBytes("UTF-8")));
                        doc.getDocumentElement().normalize();
                        String respCode = doc.getElementsByTagName("ns1:code").item(0).getTextContent();
                        String message = doc.getElementsByTagName("ns1:message").item(0).getTextContent();
                        String desc = doc.getElementsByTagName("ns1:description").item(0).getTextContent();
                        if (respCode.equals("0")) {
                            String txn_id = doc.getElementsByTagName("ns1:transactionId").item(0).getTextContent();
                            String system = doc.getElementsByTagName("ns1:system").item(0).getTextContent();
                            result = "00^" + desc + "^" + txn_id + "^" + system + "^" + message;
                        } else {

                            result = "01^" + desc + "^" + respCode + "^" + message;
                            if (desc.contains("Duplicated")) {
                                String txn_id = doc.getElementsByTagName("ns1:transactionId").item(0).getTextContent();
                                String system = doc.getElementsByTagName("ns1:system").item(0).getTextContent();
                                result = "00^" + desc + "^" + txn_id + "^" + system + "^" + message;
                            }

                        }
                    } catch (Exception ex) {
                        log.error("Webservice error While parsing the response XML: " + ex.getMessage());
                        result = "01^Error posting payment FT reference: " + n.getT24_reference();
                        ex.printStackTrace();
                    }
                }
            } catch (Exception ex) {
                log.error("Webservice payment error: " + ex.getMessage());
                result = "01^Error posting payment FT reference: " + n.getT24_reference();
                if (ex.getMessage().contains("401 for")) {
                    result = "00^Token has expired log for retry^" + n.getT24_reference();
                }

                ex.printStackTrace();
            }
        } else {
            log.error("Token missing ");
            result = "01^Token missing " + n.getAccount();
        }
        return result;

    }
}

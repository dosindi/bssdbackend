/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc;

import com.ncba.kplc.model.InterfaceParam;
import com.ncba.kplc.model.InterfaceParamRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 *
 * @author Duncan.Nyakundi
 */
@Configuration
public class WSConfig {

    @Bean
    public Docket api() {

        return new Docket(DocumentationType.OAS_30)
                .select()
                .apis(RequestHandlerSelectors.basePackage("org.springframework.boot").negate())
                .apis(RequestHandlerSelectors.basePackage("com.ncba.kplc.model").negate())
                //                .apis(RequestHandlerSelectors.any())
                .paths(PathSelectors.ant("/interfaceParams").negate())
                .build();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.kplc.utils;

import com.ncba.kplc.controller.MainController;
import java.io.StringWriter;
import java.util.logging.Level;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.namespace.QName;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 *
 * @author Duncan.Nyakundi
 * 
 */
@Component
public class Utils {
    
        
    @Value("${kplc.endpoint}")
    public String endpoint;
    
    @Value("${kplc.apikey}")
    public String apikey;
    
    @Value("${kplc.privatekey}")
    public String privatekey;

    public String getSignature(String num) {

        String res = DigestUtils.sha1Hex(apikey.concat(num).concat(privatekey));

        return res;

    }

    public String toXmlStringWithoutRoot(Class cl, Object ob, String qName) throws PropertyException, JAXBException {
        StringWriter sw = new StringWriter();

        JAXBContext context = JAXBContext.newInstance(cl);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        JAXBElement jx = new JAXBElement(new QName(qName), cl, ob);
        marshaller.marshal(jx, sw);

        return sw.toString();

    }

    public String toXmlString(Class cl, Object ob) {

        JAXBContext context;
        StringWriter sw = new StringWriter();
        try {
            context = JAXBContext.newInstance(cl);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(ob, sw);
        } catch (JAXBException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return sw.toString();
    }
}

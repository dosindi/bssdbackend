/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.utils;

/**
 *
 * @author Duncan.Nyakundi
 */
//import org.dmg.pmml.FieldName;
//import org.dmg.pmml.PMML;
//import org.jpmml.evaluator.FieldValue;
//import org.jpmml.evaluator.ModelEvaluator;
//import org.jpmml.evaluator.ModelEvaluatorFactory;
//import org.jpmml.manager.PMMLManager;
//import org.jpmml.model.filters.ImportFilter;
//import org.jpmml.model.JAXBUtil;
import com.ncba.scoring.controller.MainController;
import io.micrometer.core.instrument.util.StringUtils;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import lombok.Data;
import org.springframework.stereotype.Component;
import org.json.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *
 * @author Duncan.Nyakundi
 */
@Component
public class Utilz {

    public void loadConfig() throws NoSuchAlgorithmException, KeyManagementException {

        TrustManager[] trustAllCerts = new TrustManager[]{
            new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                @Override
                public void checkClientTrusted(
                        java.security.cert.X509Certificate[] certificates, String authType) {
                }

                @Override
                public void checkServerTrusted(
                        java.security.cert.X509Certificate[] certificates, String authType) {
                }
            }
        };
//        connectionFactory.setKeyAndTrustManagers(null, trustAllCerts, new SecureRandom());

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());

        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

    }

    public LocalHost getClientIp() throws UnknownHostException {

        LocalHost local = new LocalHost();

        String host = InetAddress.getLocalHost().getHostAddress();
        String hostName = InetAddress.getLocalHost().getHostName();

        local.setHostIP(host);
        local.setHostName(hostName);
        return local;
    }

    @Data
    public class LocalHost {

        String hostIP;
        String hostName;
    }

    public String xmlToJson(String xml, String key1, String key2) {

        String jsonString = "";
        try {
            JSONObject json = XML.toJSONObject(xml).getJSONObject(key1).getJSONObject(key2).getJSONObject("Result");
            jsonString = json.toString(4);
            System.out.println(jsonString);

        } catch (JSONException e) {
            System.out.println(e.toString());
        }

        return jsonString;

    }

    public String toXmlStringWithoutRoot(Class cl, Object ob, String qName) throws PropertyException, JAXBException {
        StringWriter sw = new StringWriter();

        JAXBContext context = JAXBContext.newInstance(cl);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        JAXBElement jx = new JAXBElement(new QName(qName), cl, ob);
        marshaller.marshal(jx, sw);

        return sw.toString();

    }

    public void enableProxy() {

        System.out.println("---------------------------skipping-----------------------------------------");
        System.setProperty("https.proxyHost", "10.1.0.1");
        System.setProperty("https.proxyPort", "8383");

        TrustManager[] trustManager = new TrustManager[]{new X509TrustManager() {
            @Override
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            @Override
            public void checkClientTrusted(X509Certificate[] certs, String authType) {

            }

            @Override
            public void checkServerTrusted(X509Certificate[] certs, String authType) {

            }
        }
        };
        SSLContext sc = null;
        try {
            sc = SSLContext.getInstance("SSL");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        try {
            sc.init(null, trustManager, new java.security.SecureRandom());
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        // Create all-trusting host name verifier
        HostnameVerifier validHosts = new HostnameVerifier() {
            @Override
            public boolean verify(String arg0, SSLSession arg1) {
                return true;
            }
        };

        javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(validHosts);

    }

    public String toXmlString(Class cl, Object ob) {

        JAXBContext context;
        StringWriter sw = new StringWriter();
        try {
            context = JAXBContext.newInstance(cl);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(ob, sw);
        } catch (JAXBException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return sw.toString();
    }

    public String format2XML(String unformattedXml) {
        String string = "-";
        if (StringUtils.isNotEmpty(unformattedXml)) {
            Document document = parseXmlFile(unformattedXml);

            try {
                Transformer transformer = TransformerFactory.newInstance().newTransformer();
                transformer.setOutputProperty(OutputKeys.METHOD, "xml");
                transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

                Writer out = new StringWriter();
                transformer.transform(new DOMSource(document), new StreamResult(out));
                string = out.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return string;
    }

    private Document parseXmlFile(String in) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(in));
            return db.parse(is);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void pmmlLoader() throws FileNotFoundException, IOException {

        String modelFile = "dynamic-model.pmml.xml";

        Resource resource = new ClassPathResource(modelFile);
        InputStream inputStream = new FileInputStream(resource.getFile());

    }

//    private Map<Field, ?> score(ModelEvaluator<?> evaluator, Map<String, Object> input) {
//
//        Map<Field, FieldValue> arguments = new LinkedHashMap<Field, FieldValue>();
//        List<InputField> activeFields = evaluator.getActiveFields();
//        for (InputField activeField : activeFields) {
//
//            Object rawValue = input.get(activeField.getName());
//
//            FieldValue activeValue = evaluator.prepare(activeField, rawValue);
//
//            arguments.put(activeField, activeValue);
//        }
//
//        return evaluator.evaluate(arguments);
//    }
}

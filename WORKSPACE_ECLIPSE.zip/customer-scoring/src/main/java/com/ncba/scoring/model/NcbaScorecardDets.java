/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Data;

/**
 *
 * @author Duncan.Nyakundi
 */
@Entity
@Table(name = "NCBA_SCORECARD_DETS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "NcbaScorecardDets.findAll", query = "SELECT n FROM NcbaScorecardDets n")
    , @NamedQuery(name = "NcbaScorecardDets.findByRecid", query = "SELECT n FROM NcbaScorecardDets n WHERE n.recid = :recid")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustDate", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custDate = :custDate")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustomerName", query = "SELECT n FROM NcbaScorecardDets n WHERE n.customerName = :customerName")
    , @NamedQuery(name = "NcbaScorecardDets.findByDrturnover", query = "SELECT n FROM NcbaScorecardDets n WHERE n.drturnover = :drturnover")
    , @NamedQuery(name = "NcbaScorecardDets.findBySavacctdepcnt", query = "SELECT n FROM NcbaScorecardDets n WHERE n.savacctdepcnt = :savacctdepcnt")
    , @NamedQuery(name = "NcbaScorecardDets.findByTotalassets", query = "SELECT n FROM NcbaScorecardDets n WHERE n.totalassets = :totalassets")
    , @NamedQuery(name = "NcbaScorecardDets.findByAge", query = "SELECT n FROM NcbaScorecardDets n WHERE n.age = :age")
    , @NamedQuery(name = "NcbaScorecardDets.findByGender", query = "SELECT n FROM NcbaScorecardDets n WHERE n.gender = :gender")
    , @NamedQuery(name = "NcbaScorecardDets.findByTenurerel", query = "SELECT n FROM NcbaScorecardDets n WHERE n.tenurerel = :tenurerel")
    , @NamedQuery(name = "NcbaScorecardDets.findByEmpstrength", query = "SELECT n FROM NcbaScorecardDets n WHERE n.empstrength = :empstrength")
    , @NamedQuery(name = "NcbaScorecardDets.findByNationalId", query = "SELECT n FROM NcbaScorecardDets n WHERE n.nationalId = :nationalId")
    , @NamedQuery(name = "NcbaScorecardDets.findByServiceNo", query = "SELECT n FROM NcbaScorecardDets n WHERE n.serviceNo = :serviceNo")
    , @NamedQuery(name = "NcbaScorecardDets.findByPassportNo", query = "SELECT n FROM NcbaScorecardDets n WHERE n.passportNo = :passportNo")
    , @NamedQuery(name = "NcbaScorecardDets.findByAlienId", query = "SELECT n FROM NcbaScorecardDets n WHERE n.alienId = :alienId")
    , @NamedQuery(name = "NcbaScorecardDets.findByCompanyReg", query = "SELECT n FROM NcbaScorecardDets n WHERE n.companyReg = :companyReg")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanDate", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanDate = :custLoanDate")
    , @NamedQuery(name = "NcbaScorecardDets.findByReportDate", query = "SELECT n FROM NcbaScorecardDets n WHERE n.reportDate = :reportDate")
    , @NamedQuery(name = "NcbaScorecardDets.findByExtractionDate", query = "SELECT n FROM NcbaScorecardDets n WHERE n.extractionDate = :extractionDate")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanCount", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanCount = :custLoanCount")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanProds1", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanProds1 = :custLoanProds1")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanProds2", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanProds2 = :custLoanProds2")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanProds3", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanProds3 = :custLoanProds3")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanProds4", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanProds4 = :custLoanProds4")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanProds5", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanProds5 = :custLoanProds5")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanProds6", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanProds6 = :custLoanProds6")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanProds7", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanProds7 = :custLoanProds7")
    , @NamedQuery(name = "NcbaScorecardDets.findByCustLoanProds8", query = "SELECT n FROM NcbaScorecardDets n WHERE n.custLoanProds8 = :custLoanProds8")})
@Data
public class NcbaScorecardDets implements Serializable {

    @Size(max = 4000)
    @Column(name = "CUST_DATE")
    private String custDate;
    @Size(max = 4000)
    @Column(name = "CUSTOMER_NUMBER")
    private String customerNumber;
    @Size(max = 4000)
    @Column(name = "CUSTOMER_NAME")
    private String customerName;
    @Size(max = 4000)
    @Column(name = "DRTURNOVER")
    private String drturnover;
    @Size(max = 4000)
    @Column(name = "SAVACCTDEPCNT")
    private String savacctdepcnt;
    @Size(max = 4000)
    @Column(name = "TOTALASSETS")
    private String totalassets;
    @Size(max = 4000)
    @Column(name = "AGE")
    private String age;
    @Size(max = 4000)
    @Column(name = "GENDER")
    private String gender;
    @Size(max = 4000)
    @Column(name = "TENUREREL")
    private String tenurerel;
    @Size(max = 4000)
    @Column(name = "EMPSTRENGTH")
    private String empstrength;
    @Size(max = 4000)
    @Column(name = "NATIONAL_ID")
    private String nationalId;
    @Size(max = 4000)
    @Column(name = "SERVICE_NO")
    private String serviceNo;
    @Size(max = 4000)
    @Column(name = "PASSPORT_NO")
    private String passportNo;
    @Size(max = 4000)
    @Column(name = "ALIEN_ID")
    private String alienId;
    @Size(max = 4000)
    @Column(name = "COMPANY_REG")
    private String companyReg;
    @Size(max = 4000)
    @Column(name = "CUST_LOAN_DATE")
    private String custLoanDate;
    @Size(max = 4000)
    @Column(name = "REPORT_DATE")
    private String reportDate;
    @Size(max = 255)
    @Column(name = "EXTRACTION_DATE")
    private String extractionDate;
    @Size(max = 255)
    @Column(name = "CUST_LOAN_COUNT")
    private String custLoanCount;
    @Size(max = 255)
    @Column(name = "CUST_LOAN_PRODS_1")
    private String custLoanProds1;
    @Size(max = 255)
    @Column(name = "CUST_LOAN_PRODS_2")
    private String custLoanProds2;
    @Size(max = 255)
    @Column(name = "CUST_LOAN_PRODS_3")
    private String custLoanProds3;
    @Size(max = 255)
    @Column(name = "CUST_LOAN_PRODS_4")
    private String custLoanProds4;
    @Size(max = 255)
    @Column(name = "CUST_LOAN_PRODS_5")
    private String custLoanProds5;
    @Size(max = 255)
    @Column(name = "CUST_LOAN_PRODS_6")
    private String custLoanProds6;
    @Size(max = 255)
    @Column(name = "CUST_LOAN_PRODS_7")
    private String custLoanProds7;
    @Size(max = 255)
    @Column(name = "CUST_LOAN_PRODS_8")
    private String custLoanProds8;
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "RECID")
    private String recid;

    public NcbaScorecardDets() {
    }

    public NcbaScorecardDets(String recid) {
        this.recid = recid;
    }

    public String getRecid() {
        return recid;
    }

    public void setRecid(String recid) {
        this.recid = recid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (recid != null ? recid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NcbaScorecardDets)) {
            return false;
        }
        NcbaScorecardDets other = (NcbaScorecardDets) object;
        if ((this.recid == null && other.recid != null) || (this.recid != null && !this.recid.equals(other.recid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "{"
                + "\"custDate\":\"" + getCustDate()+"\","
                + "\"customerNumber\":\"" + getCustomerNumber()+"\","
                + "\"customerName\":\"" + getCustomerName()+"\","
                + "\"drturnover\":\"" + getDrturnover()+"\","
                + "\"savacctdepcnt\":\"" + getSavacctdepcnt()+"\","
                + "\"totalassets\":\"" + getTotalassets()+"\","
                + "\"age\":\"" + getAge()+"\","
                + "\"gender\":\"" + getGender()+"\","
                + "\"tenurerel\":\"" + getTenurerel()+"\","
                + "\"empstrength\":\"" + getEmpstrength()+"\","
                + "\"nationalId\":\"" + getNationalId()+"\","
                + "\"serviceNo\":\"" + getServiceNo()+"\","
                + "\"passportNo\":\"" + getPassportNo()+"\","
                + "\"alienId\":\"" + getAlienId()+"\","
                + "\"companyReg\":\"" + getCompanyReg()+"\","
                + "\"custLoanDate\":\"" + getCustLoanDate()+"\","
                + "\"reportDate\":\"" + getReportDate()+"\","
                + "\"extractionDate\":\"" + getExtractionDate()+"\","
                + "\"custLoanCount\":\"" + getCustLoanCount()+"\","
                + "\"custLoanProds1\":\"" + getCustLoanProds1()+"\","
                + "\"custLoanProds2\":\"" + getCustLoanProds2()+"\","
                + "\"custLoanProds3\":\"" + getCustLoanProds3()+"\","
                + "\"custLoanProds4\":\"" + getCustLoanProds4()+"\","
                + "\"custLoanProds5\":\"" + getCustLoanProds5()+"\","
                + "\"custLoanProds6\":\"" + getCustLoanProds6()+"\","
                + "\"custLoanProds7\":\"" + getCustLoanProds7()+"\","
                + "\"custLoanProds8\":\"" + getCustLoanProds8()+"\","
                + "\"recid\":\"" + getRecid()+"\""
                + "}";
    }

}

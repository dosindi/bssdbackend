
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for summaryPortfolioAnalysis complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="summaryPortfolioAnalysis"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="enquiriesLast30Days" type="{http://ws.crbws.transunion.ke.co/}countSector145" minOccurs="0"/&gt;
 *         &lt;element name="lastLendingScore" type="{http://ws.crbws.transunion.ke.co/}positiveCreditScoreGrade" minOccurs="0"/&gt;
 *         &lt;element name="openNPA" type="{http://ws.crbws.transunion.ke.co/}countSector145" minOccurs="0"/&gt;
 *         &lt;element name="openPA" type="{http://ws.crbws.transunion.ke.co/}countSector145" minOccurs="0"/&gt;
 *         &lt;element name="openPAWithDefaultHistory" type="{http://ws.crbws.transunion.ke.co/}countSector145" minOccurs="0"/&gt;
 *         &lt;element name="shareOfWallet" type="{http://ws.crbws.transunion.ke.co/}walletRepresentation" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "summaryPortfolioAnalysis", propOrder = {
    "enquiriesLast30Days",
    "lastLendingScore",
    "openNPA",
    "openPA",
    "openPAWithDefaultHistory",
    "shareOfWallet"
})
public class SummaryPortfolioAnalysis {

    protected CountSector145 enquiriesLast30Days;
    protected PositiveCreditScoreGrade lastLendingScore;
    protected CountSector145 openNPA;
    protected CountSector145 openPA;
    protected CountSector145 openPAWithDefaultHistory;
    protected WalletRepresentation shareOfWallet;

    /**
     * Gets the value of the enquiriesLast30Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector145 }
     *     
     */
    public CountSector145 getEnquiriesLast30Days() {
        return enquiriesLast30Days;
    }

    /**
     * Sets the value of the enquiriesLast30Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector145 }
     *     
     */
    public void setEnquiriesLast30Days(CountSector145 value) {
        this.enquiriesLast30Days = value;
    }

    /**
     * Gets the value of the lastLendingScore property.
     * 
     * @return
     *     possible object is
     *     {@link PositiveCreditScoreGrade }
     *     
     */
    public PositiveCreditScoreGrade getLastLendingScore() {
        return lastLendingScore;
    }

    /**
     * Sets the value of the lastLendingScore property.
     * 
     * @param value
     *     allowed object is
     *     {@link PositiveCreditScoreGrade }
     *     
     */
    public void setLastLendingScore(PositiveCreditScoreGrade value) {
        this.lastLendingScore = value;
    }

    /**
     * Gets the value of the openNPA property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector145 }
     *     
     */
    public CountSector145 getOpenNPA() {
        return openNPA;
    }

    /**
     * Sets the value of the openNPA property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector145 }
     *     
     */
    public void setOpenNPA(CountSector145 value) {
        this.openNPA = value;
    }

    /**
     * Gets the value of the openPA property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector145 }
     *     
     */
    public CountSector145 getOpenPA() {
        return openPA;
    }

    /**
     * Sets the value of the openPA property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector145 }
     *     
     */
    public void setOpenPA(CountSector145 value) {
        this.openPA = value;
    }

    /**
     * Gets the value of the openPAWithDefaultHistory property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector145 }
     *     
     */
    public CountSector145 getOpenPAWithDefaultHistory() {
        return openPAWithDefaultHistory;
    }

    /**
     * Sets the value of the openPAWithDefaultHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector145 }
     *     
     */
    public void setOpenPAWithDefaultHistory(CountSector145 value) {
        this.openPAWithDefaultHistory = value;
    }

    /**
     * Gets the value of the shareOfWallet property.
     * 
     * @return
     *     possible object is
     *     {@link WalletRepresentation }
     *     
     */
    public WalletRepresentation getShareOfWallet() {
        return shareOfWallet;
    }

    /**
     * Sets the value of the shareOfWallet property.
     * 
     * @param value
     *     allowed object is
     *     {@link WalletRepresentation }
     *     
     */
    public void setShareOfWallet(WalletRepresentation value) {
        this.shareOfWallet = value;
    }

}

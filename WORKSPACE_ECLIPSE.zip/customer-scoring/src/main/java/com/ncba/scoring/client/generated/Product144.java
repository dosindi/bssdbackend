
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for product144 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="product144"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountList" type="{http://ws.crbws.transunion.ke.co/}genericAccount144" minOccurs="0"/&gt;
 *         &lt;element name="genericScoreOutput" type="{http://ws.crbws.transunion.ke.co/}scoreOutput144" minOccurs="0"/&gt;
 *         &lt;element name="header" type="{http://ws.crbws.transunion.ke.co/}header" minOccurs="0"/&gt;
 *         &lt;element name="mobileAccountlist" type="{http://ws.crbws.transunion.ke.co/}mobileAccount144" minOccurs="0"/&gt;
 *         &lt;element name="mobileScoreOutput" type="{http://ws.crbws.transunion.ke.co/}mobileScoreOutput144" minOccurs="0"/&gt;
 *         &lt;element name="personalProfile" type="{http://ws.crbws.transunion.ke.co/}personalProfile144" minOccurs="0"/&gt;
 *         &lt;element name="phoneList" type="{http://ws.crbws.transunion.ke.co/}phone144" minOccurs="0"/&gt;
 *         &lt;element name="responseCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "product144", propOrder = {
    "accountList",
    "genericScoreOutput",
    "header",
    "mobileAccountlist",
    "mobileScoreOutput",
    "personalProfile",
    "phoneList",
    "responseCode"
})
public class Product144 {

    protected GenericAccount144 accountList;
    protected ScoreOutput144 genericScoreOutput;
    protected Header header;
    protected MobileAccount144 mobileAccountlist;
    protected MobileScoreOutput144 mobileScoreOutput;
    protected PersonalProfile144 personalProfile;
    protected Phone144 phoneList;
    protected Integer responseCode;

    /**
     * Gets the value of the accountList property.
     * 
     * @return
     *     possible object is
     *     {@link GenericAccount144 }
     *     
     */
    public GenericAccount144 getAccountList() {
        return accountList;
    }

    /**
     * Sets the value of the accountList property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericAccount144 }
     *     
     */
    public void setAccountList(GenericAccount144 value) {
        this.accountList = value;
    }

    /**
     * Gets the value of the genericScoreOutput property.
     * 
     * @return
     *     possible object is
     *     {@link ScoreOutput144 }
     *     
     */
    public ScoreOutput144 getGenericScoreOutput() {
        return genericScoreOutput;
    }

    /**
     * Sets the value of the genericScoreOutput property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScoreOutput144 }
     *     
     */
    public void setGenericScoreOutput(ScoreOutput144 value) {
        this.genericScoreOutput = value;
    }

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link Header }
     *     
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link Header }
     *     
     */
    public void setHeader(Header value) {
        this.header = value;
    }

    /**
     * Gets the value of the mobileAccountlist property.
     * 
     * @return
     *     possible object is
     *     {@link MobileAccount144 }
     *     
     */
    public MobileAccount144 getMobileAccountlist() {
        return mobileAccountlist;
    }

    /**
     * Sets the value of the mobileAccountlist property.
     * 
     * @param value
     *     allowed object is
     *     {@link MobileAccount144 }
     *     
     */
    public void setMobileAccountlist(MobileAccount144 value) {
        this.mobileAccountlist = value;
    }

    /**
     * Gets the value of the mobileScoreOutput property.
     * 
     * @return
     *     possible object is
     *     {@link MobileScoreOutput144 }
     *     
     */
    public MobileScoreOutput144 getMobileScoreOutput() {
        return mobileScoreOutput;
    }

    /**
     * Sets the value of the mobileScoreOutput property.
     * 
     * @param value
     *     allowed object is
     *     {@link MobileScoreOutput144 }
     *     
     */
    public void setMobileScoreOutput(MobileScoreOutput144 value) {
        this.mobileScoreOutput = value;
    }

    /**
     * Gets the value of the personalProfile property.
     * 
     * @return
     *     possible object is
     *     {@link PersonalProfile144 }
     *     
     */
    public PersonalProfile144 getPersonalProfile() {
        return personalProfile;
    }

    /**
     * Sets the value of the personalProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonalProfile144 }
     *     
     */
    public void setPersonalProfile(PersonalProfile144 value) {
        this.personalProfile = value;
    }

    /**
     * Gets the value of the phoneList property.
     * 
     * @return
     *     possible object is
     *     {@link Phone144 }
     *     
     */
    public Phone144 getPhoneList() {
        return phoneList;
    }

    /**
     * Sets the value of the phoneList property.
     * 
     * @param value
     *     allowed object is
     *     {@link Phone144 }
     *     
     */
    public void setPhoneList(Phone144 value) {
        this.phoneList = value;
    }

    /**
     * Gets the value of the responseCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getResponseCode() {
        return responseCode;
    }

    /**
     * Sets the value of the responseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setResponseCode(Integer value) {
        this.responseCode = value;
    }

}

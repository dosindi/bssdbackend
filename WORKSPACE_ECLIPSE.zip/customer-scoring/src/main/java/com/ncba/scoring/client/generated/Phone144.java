
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for phone144 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="phone144"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="numberOfPhoneContacts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "phone144", propOrder = {
    "numberOfPhoneContacts"
})
public class Phone144 {

    protected int numberOfPhoneContacts;

    /**
     * Gets the value of the numberOfPhoneContacts property.
     * 
     */
    public int getNumberOfPhoneContacts() {
        return numberOfPhoneContacts;
    }

    /**
     * Sets the value of the numberOfPhoneContacts property.
     * 
     */
    public void setNumberOfPhoneContacts(int value) {
        this.numberOfPhoneContacts = value;
    }

}

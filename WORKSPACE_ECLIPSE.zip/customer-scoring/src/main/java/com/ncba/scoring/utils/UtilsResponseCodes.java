/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.utils;

import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import lombok.*;
/**
 *
 * @author Duncan.Nyakundi
 */
@Component

@ConfigurationProperties(prefix="codes")
public class UtilsResponseCodes {
 
    @Getter
    @Setter
    private Map<Integer,String> response_codes;
    
    
    
}


package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for mobileAccount144 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="mobileAccount144"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="mobileCurrentArrears" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="mobileCurrentBalance" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="mobileLastPaymentDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="mobilePrincipalAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="mobileSubscriberBalanceAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="mobileSubscriberPrincipalAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="numberOfMobileAccounts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="numberOfMobileClosedAccounts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="numberOfMobileNonPerformingAccounts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="numberOfMobileOpenAccounts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="numberOfMobilePerformingAccounts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mobileAccount144", propOrder = {
    "mobileCurrentArrears",
    "mobileCurrentBalance",
    "mobileLastPaymentDate",
    "mobilePrincipalAmount",
    "mobileSubscriberBalanceAmount",
    "mobileSubscriberPrincipalAmount",
    "numberOfMobileAccounts",
    "numberOfMobileClosedAccounts",
    "numberOfMobileNonPerformingAccounts",
    "numberOfMobileOpenAccounts",
    "numberOfMobilePerformingAccounts"
})
public class MobileAccount144 {

    protected int mobileCurrentArrears;
    protected Double mobileCurrentBalance;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar mobileLastPaymentDate;
    protected Double mobilePrincipalAmount;
    protected Double mobileSubscriberBalanceAmount;
    protected Double mobileSubscriberPrincipalAmount;
    protected int numberOfMobileAccounts;
    protected int numberOfMobileClosedAccounts;
    protected int numberOfMobileNonPerformingAccounts;
    protected int numberOfMobileOpenAccounts;
    protected int numberOfMobilePerformingAccounts;

    /**
     * Gets the value of the mobileCurrentArrears property.
     * 
     */
    public int getMobileCurrentArrears() {
        return mobileCurrentArrears;
    }

    /**
     * Sets the value of the mobileCurrentArrears property.
     * 
     */
    public void setMobileCurrentArrears(int value) {
        this.mobileCurrentArrears = value;
    }

    /**
     * Gets the value of the mobileCurrentBalance property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMobileCurrentBalance() {
        return mobileCurrentBalance;
    }

    /**
     * Sets the value of the mobileCurrentBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMobileCurrentBalance(Double value) {
        this.mobileCurrentBalance = value;
    }

    /**
     * Gets the value of the mobileLastPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMobileLastPaymentDate() {
        return mobileLastPaymentDate;
    }

    /**
     * Sets the value of the mobileLastPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMobileLastPaymentDate(XMLGregorianCalendar value) {
        this.mobileLastPaymentDate = value;
    }

    /**
     * Gets the value of the mobilePrincipalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMobilePrincipalAmount() {
        return mobilePrincipalAmount;
    }

    /**
     * Sets the value of the mobilePrincipalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMobilePrincipalAmount(Double value) {
        this.mobilePrincipalAmount = value;
    }

    /**
     * Gets the value of the mobileSubscriberBalanceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMobileSubscriberBalanceAmount() {
        return mobileSubscriberBalanceAmount;
    }

    /**
     * Sets the value of the mobileSubscriberBalanceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMobileSubscriberBalanceAmount(Double value) {
        this.mobileSubscriberBalanceAmount = value;
    }

    /**
     * Gets the value of the mobileSubscriberPrincipalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMobileSubscriberPrincipalAmount() {
        return mobileSubscriberPrincipalAmount;
    }

    /**
     * Sets the value of the mobileSubscriberPrincipalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMobileSubscriberPrincipalAmount(Double value) {
        this.mobileSubscriberPrincipalAmount = value;
    }

    /**
     * Gets the value of the numberOfMobileAccounts property.
     * 
     */
    public int getNumberOfMobileAccounts() {
        return numberOfMobileAccounts;
    }

    /**
     * Sets the value of the numberOfMobileAccounts property.
     * 
     */
    public void setNumberOfMobileAccounts(int value) {
        this.numberOfMobileAccounts = value;
    }

    /**
     * Gets the value of the numberOfMobileClosedAccounts property.
     * 
     */
    public int getNumberOfMobileClosedAccounts() {
        return numberOfMobileClosedAccounts;
    }

    /**
     * Sets the value of the numberOfMobileClosedAccounts property.
     * 
     */
    public void setNumberOfMobileClosedAccounts(int value) {
        this.numberOfMobileClosedAccounts = value;
    }

    /**
     * Gets the value of the numberOfMobileNonPerformingAccounts property.
     * 
     */
    public int getNumberOfMobileNonPerformingAccounts() {
        return numberOfMobileNonPerformingAccounts;
    }

    /**
     * Sets the value of the numberOfMobileNonPerformingAccounts property.
     * 
     */
    public void setNumberOfMobileNonPerformingAccounts(int value) {
        this.numberOfMobileNonPerformingAccounts = value;
    }

    /**
     * Gets the value of the numberOfMobileOpenAccounts property.
     * 
     */
    public int getNumberOfMobileOpenAccounts() {
        return numberOfMobileOpenAccounts;
    }

    /**
     * Sets the value of the numberOfMobileOpenAccounts property.
     * 
     */
    public void setNumberOfMobileOpenAccounts(int value) {
        this.numberOfMobileOpenAccounts = value;
    }

    /**
     * Gets the value of the numberOfMobilePerformingAccounts property.
     * 
     */
    public int getNumberOfMobilePerformingAccounts() {
        return numberOfMobilePerformingAccounts;
    }

    /**
     * Sets the value of the numberOfMobilePerformingAccounts property.
     * 
     */
    public void setNumberOfMobilePerformingAccounts(int value) {
        this.numberOfMobilePerformingAccounts = value;
    }

}

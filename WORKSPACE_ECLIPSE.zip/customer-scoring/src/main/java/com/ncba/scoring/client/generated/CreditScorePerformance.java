
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for creditScorePerformance complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="creditScorePerformance"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="averageScoreLast12Months" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="averageScoreLast24Months" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="averageScoreLast3Months" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="averageScoreLast6Months" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="grade" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="positiveScore" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="probability" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "creditScorePerformance", propOrder = {
    "averageScoreLast12Months",
    "averageScoreLast24Months",
    "averageScoreLast3Months",
    "averageScoreLast6Months",
    "grade",
    "positiveScore",
    "probability"
})
public class CreditScorePerformance {

    protected Integer averageScoreLast12Months;
    protected Integer averageScoreLast24Months;
    protected Integer averageScoreLast3Months;
    protected Integer averageScoreLast6Months;
    protected String grade;
    protected Integer positiveScore;
    protected Integer probability;

    /**
     * Gets the value of the averageScoreLast12Months property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAverageScoreLast12Months() {
        return averageScoreLast12Months;
    }

    /**
     * Sets the value of the averageScoreLast12Months property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAverageScoreLast12Months(Integer value) {
        this.averageScoreLast12Months = value;
    }

    /**
     * Gets the value of the averageScoreLast24Months property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAverageScoreLast24Months() {
        return averageScoreLast24Months;
    }

    /**
     * Sets the value of the averageScoreLast24Months property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAverageScoreLast24Months(Integer value) {
        this.averageScoreLast24Months = value;
    }

    /**
     * Gets the value of the averageScoreLast3Months property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAverageScoreLast3Months() {
        return averageScoreLast3Months;
    }

    /**
     * Sets the value of the averageScoreLast3Months property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAverageScoreLast3Months(Integer value) {
        this.averageScoreLast3Months = value;
    }

    /**
     * Gets the value of the averageScoreLast6Months property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAverageScoreLast6Months() {
        return averageScoreLast6Months;
    }

    /**
     * Sets the value of the averageScoreLast6Months property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAverageScoreLast6Months(Integer value) {
        this.averageScoreLast6Months = value;
    }

    /**
     * Gets the value of the grade property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGrade() {
        return grade;
    }

    /**
     * Sets the value of the grade property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGrade(String value) {
        this.grade = value;
    }

    /**
     * Gets the value of the positiveScore property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPositiveScore() {
        return positiveScore;
    }

    /**
     * Sets the value of the positiveScore property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPositiveScore(Integer value) {
        this.positiveScore = value;
    }

    /**
     * Gets the value of the probability property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getProbability() {
        return probability;
    }

    /**
     * Sets the value of the probability property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setProbability(Integer value) {
        this.probability = value;
    }

}

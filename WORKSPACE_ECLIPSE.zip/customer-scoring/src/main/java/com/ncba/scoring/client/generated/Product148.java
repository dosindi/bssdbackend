
package com.ncba.scoring.client.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for product148 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="product148"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountList" type="{http://ws.crbws.transunion.ke.co/}account148" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="header" type="{http://ws.crbws.transunion.ke.co/}header148" minOccurs="0"/&gt;
 *         &lt;element name="mobileLoanTransactions" type="{http://ws.crbws.transunion.ke.co/}mobileLoanTransactions148" minOccurs="0"/&gt;
 *         &lt;element name="nonMobileLoanTransactions" type="{http://ws.crbws.transunion.ke.co/}nonMobileLoanTransactions148" minOccurs="0"/&gt;
 *         &lt;element name="personalProfile" type="{http://ws.crbws.transunion.ke.co/}personalProfile148" minOccurs="0"/&gt;
 *         &lt;element name="phoneList" type="{http://ws.crbws.transunion.ke.co/}phone" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="responseCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="scoreOutput" type="{http://ws.crbws.transunion.ke.co/}scoreOutput148" minOccurs="0"/&gt;
 *         &lt;element name="summaryOfAccounts" type="{http://ws.crbws.transunion.ke.co/}summary148" minOccurs="0"/&gt;
 *         &lt;element name="summaryOfArrears" type="{http://ws.crbws.transunion.ke.co/}summaryArrears148" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "product148", propOrder = {
    "accountList",
    "header",
    "mobileLoanTransactions",
    "nonMobileLoanTransactions",
    "personalProfile",
    "phoneList",
    "responseCode",
    "scoreOutput",
    "summaryOfAccounts",
    "summaryOfArrears"
})
public class Product148 {

    @XmlElement(nillable = true)
    protected List<Account148> accountList;
    protected Header148 header;
    protected MobileLoanTransactions148 mobileLoanTransactions;
    protected NonMobileLoanTransactions148 nonMobileLoanTransactions;
    protected PersonalProfile148 personalProfile;
    @XmlElement(nillable = true)
    protected List<Phone> phoneList;
    protected Integer responseCode;
    protected ScoreOutput148 scoreOutput;
    protected Summary148 summaryOfAccounts;
    protected SummaryArrears148 summaryOfArrears;

    /**
     * Gets the value of the accountList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accountList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccountList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Account148 }
     * 
     * 
     */
    public List<Account148> getAccountList() {
        if (accountList == null) {
            accountList = new ArrayList<Account148>();
        }
        return this.accountList;
    }

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link Header148 }
     *     
     */
    public Header148 getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link Header148 }
     *     
     */
    public void setHeader(Header148 value) {
        this.header = value;
    }

    /**
     * Gets the value of the mobileLoanTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link MobileLoanTransactions148 }
     *     
     */
    public MobileLoanTransactions148 getMobileLoanTransactions() {
        return mobileLoanTransactions;
    }

    /**
     * Sets the value of the mobileLoanTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link MobileLoanTransactions148 }
     *     
     */
    public void setMobileLoanTransactions(MobileLoanTransactions148 value) {
        this.mobileLoanTransactions = value;
    }

    /**
     * Gets the value of the nonMobileLoanTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link NonMobileLoanTransactions148 }
     *     
     */
    public NonMobileLoanTransactions148 getNonMobileLoanTransactions() {
        return nonMobileLoanTransactions;
    }

    /**
     * Sets the value of the nonMobileLoanTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link NonMobileLoanTransactions148 }
     *     
     */
    public void setNonMobileLoanTransactions(NonMobileLoanTransactions148 value) {
        this.nonMobileLoanTransactions = value;
    }

    /**
     * Gets the value of the personalProfile property.
     * 
     * @return
     *     possible object is
     *     {@link PersonalProfile148 }
     *     
     */
    public PersonalProfile148 getPersonalProfile() {
        return personalProfile;
    }

    /**
     * Sets the value of the personalProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonalProfile148 }
     *     
     */
    public void setPersonalProfile(PersonalProfile148 value) {
        this.personalProfile = value;
    }

    /**
     * Gets the value of the phoneList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the phoneList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhoneList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Phone }
     * 
     * 
     */
    public List<Phone> getPhoneList() {
        if (phoneList == null) {
            phoneList = new ArrayList<Phone>();
        }
        return this.phoneList;
    }

    /**
     * Gets the value of the responseCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getResponseCode() {
        return responseCode;
    }

    /**
     * Sets the value of the responseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setResponseCode(Integer value) {
        this.responseCode = value;
    }

    /**
     * Gets the value of the scoreOutput property.
     * 
     * @return
     *     possible object is
     *     {@link ScoreOutput148 }
     *     
     */
    public ScoreOutput148 getScoreOutput() {
        return scoreOutput;
    }

    /**
     * Sets the value of the scoreOutput property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScoreOutput148 }
     *     
     */
    public void setScoreOutput(ScoreOutput148 value) {
        this.scoreOutput = value;
    }

    /**
     * Gets the value of the summaryOfAccounts property.
     * 
     * @return
     *     possible object is
     *     {@link Summary148 }
     *     
     */
    public Summary148 getSummaryOfAccounts() {
        return summaryOfAccounts;
    }

    /**
     * Sets the value of the summaryOfAccounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link Summary148 }
     *     
     */
    public void setSummaryOfAccounts(Summary148 value) {
        this.summaryOfAccounts = value;
    }

    /**
     * Gets the value of the summaryOfArrears property.
     * 
     * @return
     *     possible object is
     *     {@link SummaryArrears148 }
     *     
     */
    public SummaryArrears148 getSummaryOfArrears() {
        return summaryOfArrears;
    }

    /**
     * Sets the value of the summaryOfArrears property.
     * 
     * @param value
     *     allowed object is
     *     {@link SummaryArrears148 }
     *     
     */
    public void setSummaryOfArrears(SummaryArrears148 value) {
        this.summaryOfArrears = value;
    }

}

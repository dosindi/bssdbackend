/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.request;

import lombok.Data;

/**
 *
 * @author Duncan.Nyakundi
 */
@Data
public class Product144Request {

    private String name1;
    private String name2;
    private String nationalID;
    private int reportSector;
    private int reportReason=2;

}

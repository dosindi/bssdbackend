/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author Duncan.Nyakundi
 */

public interface NcbaScorecardDetsRepository extends JpaRepository<NcbaScorecardDets, String> {

    public NcbaScorecardDets findByNationalId(@Param("nationalId") String nationalId);

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.controller;


import java.io.File;

import java.io.IOException;
import java.io.StringWriter;
import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.net.*;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.NumberFormat;
import java.util.UUID;
import java.util.logging.Level;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.namespace.QName;
import org.apache.http.HttpEntity;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.apache.http.HttpEntity;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.ws.client.core.WebServiceTemplate;

/**
 *
 * @author Duncan.Nyakundi
 */
@RestController
public class MainController {

    public static Logger log = Logger.getLogger(MainController.class.getName());

    @Autowired
    private WebServiceTemplate webServiceTemplate;

    @Value("${user}")
    private String user;
    
    @Value("${pwd}")
    private String pwd;
    
    @Value("${domain}")
    private String domain;
    
    private String WS_URL="";
    
    public String toXmlStringWithoutRoot(Class cl, Object ob, String qName) throws PropertyException, JAXBException {
        StringWriter sw = new StringWriter();

        JAXBContext context = JAXBContext.newInstance(cl);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        JAXBElement jx = new JAXBElement(new QName(qName), cl, ob);
        marshaller.marshal(jx, sw);

        return sw.toString();

    }

    public String toXmlString(Class cl, Object ob) {

        JAXBContext context;
        StringWriter sw = new StringWriter();
        try {
            context = JAXBContext.newInstance(cl);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(ob, sw);
        } catch (JAXBException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return sw.toString();
    }

    public void configInfo() {

//        log.info("config: ".concat(domain.concat("\\").concat(primeuser).concat("||".concat(primepwd))));
//        NtlmAuthenticator auth = new NtlmAuthenticator(domain.concat("\\").concat(primeuser), primepwd);
//        Authenticator.setDefault(auth);
        Authenticator.setDefault(
                new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(domain.concat("\\").concat(user), pwd.toCharArray());
            }
        });
    }

    public String invokeNTLM() {

        String bodyAsString = ""; //Provide Input SOAP Message

        CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(AuthScope.ANY, new NTCredentials(user, pwd, null, domain));

        HttpClient client = HttpClientBuilder.create().setDefaultCredentialsProvider(credsProvider).build();

        HttpPost post = new HttpPost(WS_URL); //Provide Request URL

        try {

            StringEntity input = new StringEntity(bodyAsString);
            input.setContentType("text/xml; charset=utf-8");
            post.setEntity(input);

            post.setHeader("Content-type", "text/xml; charset=utf-8");
//            post.setHeader("SOAPAction", ""); //Provide Soap action

            org.apache.http.HttpResponse response = client.execute(post);

            HttpEntity responseEntity = response.getEntity();

            if (responseEntity != null) {

                return EntityUtils.toString(responseEntity);

            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public String getUUID() {

        return UUID.randomUUID().toString();
    }

    @GetMapping("/api/specs")
    public String getSpecs() {

        NumberFormat nf = NumberFormat.getNumberInstance();
        String specs = " ";
        for (Path root : FileSystems.getDefault().getRootDirectories()) {

            specs =specs+root + ": ";
            try {
                java.nio.file.FileStore store = Files.getFileStore(root);
                specs =specs+ "available=" + nf.format(store.getUsableSpace()/1000000000)
                        + "GB, total=" + nf.format(store.getTotalSpace()/1000000000)+"GB ";
            } catch (IOException e) {
                System.out.println("error querying space: " + e.toString());
            }
        }
        
        long free = new File("/").getFreeSpace();
        long usable = new File("/").getUsableSpace();
        long total = new File("/").getTotalSpace();
//        specs = "free: " + free / 1000000000 + "GB usable: " + usable / 1000000000 + "GB total: " + total / 1000000000 + " GB";
        return specs;
    }
}

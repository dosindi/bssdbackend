
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for nonMobileLoanTransactions148 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="nonMobileLoanTransactions148"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="lastNonMobileLoanPaymentAmount" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="maxNonMobileLoanPaymentsLast30Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="maxNonMobileLoanPaymentsLast60Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="maxNonMobileLoanPaymentsLast90Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="numberOfNonMobileLoanPaymentsLast30Days" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="numberOfNonMobileLoanPaymentsLast60Days" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="numberOfNonMobileLoanPaymentsLast90Days" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="timeSinceLastMobileLoanPaymentDate" type="{http://ws.crbws.transunion.ke.co/}countSectorDays" minOccurs="0"/&gt;
 *         &lt;element name="timeSinceLastNonMobileLoanPaymentDate" type="{http://ws.crbws.transunion.ke.co/}countSectorDays" minOccurs="0"/&gt;
 *         &lt;element name="totalNonMobileLoanPaymentsLast30Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="totalNonMobileLoanPaymentsLast60Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="totalNonMobileLoanPaymentsLast90Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "nonMobileLoanTransactions148", propOrder = {
    "lastNonMobileLoanPaymentAmount",
    "maxNonMobileLoanPaymentsLast30Days",
    "maxNonMobileLoanPaymentsLast60Days",
    "maxNonMobileLoanPaymentsLast90Days",
    "numberOfNonMobileLoanPaymentsLast30Days",
    "numberOfNonMobileLoanPaymentsLast60Days",
    "numberOfNonMobileLoanPaymentsLast90Days",
    "timeSinceLastMobileLoanPaymentDate",
    "timeSinceLastNonMobileLoanPaymentDate",
    "totalNonMobileLoanPaymentsLast30Days",
    "totalNonMobileLoanPaymentsLast60Days",
    "totalNonMobileLoanPaymentsLast90Days"
})
public class NonMobileLoanTransactions148 {

    protected CountSectorDouble lastNonMobileLoanPaymentAmount;
    protected CountSectorDouble maxNonMobileLoanPaymentsLast30Days;
    protected CountSectorDouble maxNonMobileLoanPaymentsLast60Days;
    protected CountSectorDouble maxNonMobileLoanPaymentsLast90Days;
    protected CountSector numberOfNonMobileLoanPaymentsLast30Days;
    protected CountSector numberOfNonMobileLoanPaymentsLast60Days;
    protected CountSector numberOfNonMobileLoanPaymentsLast90Days;
    protected CountSectorDays timeSinceLastMobileLoanPaymentDate;
    protected CountSectorDays timeSinceLastNonMobileLoanPaymentDate;
    protected CountSectorDouble totalNonMobileLoanPaymentsLast30Days;
    protected CountSectorDouble totalNonMobileLoanPaymentsLast60Days;
    protected CountSectorDouble totalNonMobileLoanPaymentsLast90Days;

    /**
     * Gets the value of the lastNonMobileLoanPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getLastNonMobileLoanPaymentAmount() {
        return lastNonMobileLoanPaymentAmount;
    }

    /**
     * Sets the value of the lastNonMobileLoanPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setLastNonMobileLoanPaymentAmount(CountSectorDouble value) {
        this.lastNonMobileLoanPaymentAmount = value;
    }

    /**
     * Gets the value of the maxNonMobileLoanPaymentsLast30Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getMaxNonMobileLoanPaymentsLast30Days() {
        return maxNonMobileLoanPaymentsLast30Days;
    }

    /**
     * Sets the value of the maxNonMobileLoanPaymentsLast30Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setMaxNonMobileLoanPaymentsLast30Days(CountSectorDouble value) {
        this.maxNonMobileLoanPaymentsLast30Days = value;
    }

    /**
     * Gets the value of the maxNonMobileLoanPaymentsLast60Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getMaxNonMobileLoanPaymentsLast60Days() {
        return maxNonMobileLoanPaymentsLast60Days;
    }

    /**
     * Sets the value of the maxNonMobileLoanPaymentsLast60Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setMaxNonMobileLoanPaymentsLast60Days(CountSectorDouble value) {
        this.maxNonMobileLoanPaymentsLast60Days = value;
    }

    /**
     * Gets the value of the maxNonMobileLoanPaymentsLast90Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getMaxNonMobileLoanPaymentsLast90Days() {
        return maxNonMobileLoanPaymentsLast90Days;
    }

    /**
     * Sets the value of the maxNonMobileLoanPaymentsLast90Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setMaxNonMobileLoanPaymentsLast90Days(CountSectorDouble value) {
        this.maxNonMobileLoanPaymentsLast90Days = value;
    }

    /**
     * Gets the value of the numberOfNonMobileLoanPaymentsLast30Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNumberOfNonMobileLoanPaymentsLast30Days() {
        return numberOfNonMobileLoanPaymentsLast30Days;
    }

    /**
     * Sets the value of the numberOfNonMobileLoanPaymentsLast30Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNumberOfNonMobileLoanPaymentsLast30Days(CountSector value) {
        this.numberOfNonMobileLoanPaymentsLast30Days = value;
    }

    /**
     * Gets the value of the numberOfNonMobileLoanPaymentsLast60Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNumberOfNonMobileLoanPaymentsLast60Days() {
        return numberOfNonMobileLoanPaymentsLast60Days;
    }

    /**
     * Sets the value of the numberOfNonMobileLoanPaymentsLast60Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNumberOfNonMobileLoanPaymentsLast60Days(CountSector value) {
        this.numberOfNonMobileLoanPaymentsLast60Days = value;
    }

    /**
     * Gets the value of the numberOfNonMobileLoanPaymentsLast90Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNumberOfNonMobileLoanPaymentsLast90Days() {
        return numberOfNonMobileLoanPaymentsLast90Days;
    }

    /**
     * Sets the value of the numberOfNonMobileLoanPaymentsLast90Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNumberOfNonMobileLoanPaymentsLast90Days(CountSector value) {
        this.numberOfNonMobileLoanPaymentsLast90Days = value;
    }

    /**
     * Gets the value of the timeSinceLastMobileLoanPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDays }
     *     
     */
    public CountSectorDays getTimeSinceLastMobileLoanPaymentDate() {
        return timeSinceLastMobileLoanPaymentDate;
    }

    /**
     * Sets the value of the timeSinceLastMobileLoanPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDays }
     *     
     */
    public void setTimeSinceLastMobileLoanPaymentDate(CountSectorDays value) {
        this.timeSinceLastMobileLoanPaymentDate = value;
    }

    /**
     * Gets the value of the timeSinceLastNonMobileLoanPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDays }
     *     
     */
    public CountSectorDays getTimeSinceLastNonMobileLoanPaymentDate() {
        return timeSinceLastNonMobileLoanPaymentDate;
    }

    /**
     * Sets the value of the timeSinceLastNonMobileLoanPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDays }
     *     
     */
    public void setTimeSinceLastNonMobileLoanPaymentDate(CountSectorDays value) {
        this.timeSinceLastNonMobileLoanPaymentDate = value;
    }

    /**
     * Gets the value of the totalNonMobileLoanPaymentsLast30Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getTotalNonMobileLoanPaymentsLast30Days() {
        return totalNonMobileLoanPaymentsLast30Days;
    }

    /**
     * Sets the value of the totalNonMobileLoanPaymentsLast30Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setTotalNonMobileLoanPaymentsLast30Days(CountSectorDouble value) {
        this.totalNonMobileLoanPaymentsLast30Days = value;
    }

    /**
     * Gets the value of the totalNonMobileLoanPaymentsLast60Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getTotalNonMobileLoanPaymentsLast60Days() {
        return totalNonMobileLoanPaymentsLast60Days;
    }

    /**
     * Sets the value of the totalNonMobileLoanPaymentsLast60Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setTotalNonMobileLoanPaymentsLast60Days(CountSectorDouble value) {
        this.totalNonMobileLoanPaymentsLast60Days = value;
    }

    /**
     * Gets the value of the totalNonMobileLoanPaymentsLast90Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getTotalNonMobileLoanPaymentsLast90Days() {
        return totalNonMobileLoanPaymentsLast90Days;
    }

    /**
     * Sets the value of the totalNonMobileLoanPaymentsLast90Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setTotalNonMobileLoanPaymentsLast90Days(CountSectorDouble value) {
        this.totalNonMobileLoanPaymentsLast90Days = value;
    }

}

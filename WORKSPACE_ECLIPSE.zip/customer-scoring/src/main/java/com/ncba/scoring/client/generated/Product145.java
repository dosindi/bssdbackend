
package com.ncba.scoring.client.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for product145 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="product145"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="averageScore" type="{http://ws.crbws.transunion.ke.co/}creditScorePerformance" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="closedAccounts" type="{http://ws.crbws.transunion.ke.co/}pastCreditRepayments" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="collateralList" type="{http://ws.crbws.transunion.ke.co/}collateralList145" minOccurs="0"/&gt;
 *         &lt;element name="creditActivityClassification" type="{http://ws.crbws.transunion.ke.co/}creditActivityClassification" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="creditScoreHistory" type="{http://ws.crbws.transunion.ke.co/}creditScoreTrend" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="header" type="{http://ws.crbws.transunion.ke.co/}header" minOccurs="0"/&gt;
 *         &lt;element name="openAccounts" type="{http://ws.crbws.transunion.ke.co/}currentOutstandingLoans" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="personalProfile" type="{http://ws.crbws.transunion.ke.co/}personalProfile145" minOccurs="0"/&gt;
 *         &lt;element name="phone" type="{http://ws.crbws.transunion.ke.co/}phone" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="responseCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="scoreOutput" type="{http://ws.crbws.transunion.ke.co/}scoreOutput145" minOccurs="0"/&gt;
 *         &lt;element name="summaryPortfolioAnalysis" type="{http://ws.crbws.transunion.ke.co/}summaryPortfolioAnalysis" minOccurs="0"/&gt;
 *         &lt;element name="summationOfOpenTotalValue" type="{http://ws.crbws.transunion.ke.co/}creditRepaymentTrend" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="twelveMonthsEnquiryHistory" type="{http://ws.crbws.transunion.ke.co/}twelveMonthsEnquiryHistory" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="worstDaysInArrears" type="{http://ws.crbws.transunion.ke.co/}repaymentPatterns" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "product145", propOrder = {
    "averageScore",
    "closedAccounts",
    "collateralList",
    "creditActivityClassification",
    "creditScoreHistory",
    "header",
    "openAccounts",
    "personalProfile",
    "phone",
    "responseCode",
    "scoreOutput",
    "summaryPortfolioAnalysis",
    "summationOfOpenTotalValue",
    "twelveMonthsEnquiryHistory",
    "worstDaysInArrears"
})
public class Product145 {

    @XmlElement(nillable = true)
    protected List<CreditScorePerformance> averageScore;
    @XmlElement(nillable = true)
    protected List<PastCreditRepayments> closedAccounts;
    protected CollateralList145 collateralList;
    @XmlElement(nillable = true)
    protected List<CreditActivityClassification> creditActivityClassification;
    @XmlElement(nillable = true)
    protected List<CreditScoreTrend> creditScoreHistory;
    protected Header header;
    @XmlElement(nillable = true)
    protected List<CurrentOutstandingLoans> openAccounts;
    protected PersonalProfile145 personalProfile;
    @XmlElement(nillable = true)
    protected List<Phone> phone;
    protected Integer responseCode;
    protected ScoreOutput145 scoreOutput;
    protected SummaryPortfolioAnalysis summaryPortfolioAnalysis;
    @XmlElement(nillable = true)
    protected List<CreditRepaymentTrend> summationOfOpenTotalValue;
    @XmlElement(nillable = true)
    protected List<TwelveMonthsEnquiryHistory> twelveMonthsEnquiryHistory;
    @XmlElement(nillable = true)
    protected List<RepaymentPatterns> worstDaysInArrears;

    /**
     * Gets the value of the averageScore property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the averageScore property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAverageScore().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditScorePerformance }
     * 
     * 
     */
    public List<CreditScorePerformance> getAverageScore() {
        if (averageScore == null) {
            averageScore = new ArrayList<CreditScorePerformance>();
        }
        return this.averageScore;
    }

    /**
     * Gets the value of the closedAccounts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the closedAccounts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClosedAccounts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PastCreditRepayments }
     * 
     * 
     */
    public List<PastCreditRepayments> getClosedAccounts() {
        if (closedAccounts == null) {
            closedAccounts = new ArrayList<PastCreditRepayments>();
        }
        return this.closedAccounts;
    }

    /**
     * Gets the value of the collateralList property.
     * 
     * @return
     *     possible object is
     *     {@link CollateralList145 }
     *     
     */
    public CollateralList145 getCollateralList() {
        return collateralList;
    }

    /**
     * Sets the value of the collateralList property.
     * 
     * @param value
     *     allowed object is
     *     {@link CollateralList145 }
     *     
     */
    public void setCollateralList(CollateralList145 value) {
        this.collateralList = value;
    }

    /**
     * Gets the value of the creditActivityClassification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditActivityClassification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditActivityClassification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditActivityClassification }
     * 
     * 
     */
    public List<CreditActivityClassification> getCreditActivityClassification() {
        if (creditActivityClassification == null) {
            creditActivityClassification = new ArrayList<CreditActivityClassification>();
        }
        return this.creditActivityClassification;
    }

    /**
     * Gets the value of the creditScoreHistory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditScoreHistory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditScoreHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditScoreTrend }
     * 
     * 
     */
    public List<CreditScoreTrend> getCreditScoreHistory() {
        if (creditScoreHistory == null) {
            creditScoreHistory = new ArrayList<CreditScoreTrend>();
        }
        return this.creditScoreHistory;
    }

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link Header }
     *     
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link Header }
     *     
     */
    public void setHeader(Header value) {
        this.header = value;
    }

    /**
     * Gets the value of the openAccounts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the openAccounts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOpenAccounts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrentOutstandingLoans }
     * 
     * 
     */
    public List<CurrentOutstandingLoans> getOpenAccounts() {
        if (openAccounts == null) {
            openAccounts = new ArrayList<CurrentOutstandingLoans>();
        }
        return this.openAccounts;
    }

    /**
     * Gets the value of the personalProfile property.
     * 
     * @return
     *     possible object is
     *     {@link PersonalProfile145 }
     *     
     */
    public PersonalProfile145 getPersonalProfile() {
        return personalProfile;
    }

    /**
     * Sets the value of the personalProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonalProfile145 }
     *     
     */
    public void setPersonalProfile(PersonalProfile145 value) {
        this.personalProfile = value;
    }

    /**
     * Gets the value of the phone property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the phone property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhone().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Phone }
     * 
     * 
     */
    public List<Phone> getPhone() {
        if (phone == null) {
            phone = new ArrayList<Phone>();
        }
        return this.phone;
    }

    /**
     * Gets the value of the responseCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getResponseCode() {
        return responseCode;
    }

    /**
     * Sets the value of the responseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setResponseCode(Integer value) {
        this.responseCode = value;
    }

    /**
     * Gets the value of the scoreOutput property.
     * 
     * @return
     *     possible object is
     *     {@link ScoreOutput145 }
     *     
     */
    public ScoreOutput145 getScoreOutput() {
        return scoreOutput;
    }

    /**
     * Sets the value of the scoreOutput property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScoreOutput145 }
     *     
     */
    public void setScoreOutput(ScoreOutput145 value) {
        this.scoreOutput = value;
    }

    /**
     * Gets the value of the summaryPortfolioAnalysis property.
     * 
     * @return
     *     possible object is
     *     {@link SummaryPortfolioAnalysis }
     *     
     */
    public SummaryPortfolioAnalysis getSummaryPortfolioAnalysis() {
        return summaryPortfolioAnalysis;
    }

    /**
     * Sets the value of the summaryPortfolioAnalysis property.
     * 
     * @param value
     *     allowed object is
     *     {@link SummaryPortfolioAnalysis }
     *     
     */
    public void setSummaryPortfolioAnalysis(SummaryPortfolioAnalysis value) {
        this.summaryPortfolioAnalysis = value;
    }

    /**
     * Gets the value of the summationOfOpenTotalValue property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the summationOfOpenTotalValue property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSummationOfOpenTotalValue().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditRepaymentTrend }
     * 
     * 
     */
    public List<CreditRepaymentTrend> getSummationOfOpenTotalValue() {
        if (summationOfOpenTotalValue == null) {
            summationOfOpenTotalValue = new ArrayList<CreditRepaymentTrend>();
        }
        return this.summationOfOpenTotalValue;
    }

    /**
     * Gets the value of the twelveMonthsEnquiryHistory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the twelveMonthsEnquiryHistory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTwelveMonthsEnquiryHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TwelveMonthsEnquiryHistory }
     * 
     * 
     */
    public List<TwelveMonthsEnquiryHistory> getTwelveMonthsEnquiryHistory() {
        if (twelveMonthsEnquiryHistory == null) {
            twelveMonthsEnquiryHistory = new ArrayList<TwelveMonthsEnquiryHistory>();
        }
        return this.twelveMonthsEnquiryHistory;
    }

    /**
     * Gets the value of the worstDaysInArrears property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the worstDaysInArrears property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWorstDaysInArrears().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RepaymentPatterns }
     * 
     * 
     */
    public List<RepaymentPatterns> getWorstDaysInArrears() {
        if (worstDaysInArrears == null) {
            worstDaysInArrears = new ArrayList<RepaymentPatterns>();
        }
        return this.worstDaysInArrears;
    }

}


package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for countSectorDays complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="countSectorDays"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="mySector" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="otherSectors" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "countSectorDays", propOrder = {
    "mySector",
    "otherSectors"
})
public class CountSectorDays {

    protected long mySector;
    protected long otherSectors;

    /**
     * Gets the value of the mySector property.
     * 
     */
    public long getMySector() {
        return mySector;
    }

    /**
     * Sets the value of the mySector property.
     * 
     */
    public void setMySector(long value) {
        this.mySector = value;
    }

    /**
     * Gets the value of the otherSectors property.
     * 
     */
    public long getOtherSectors() {
        return otherSectors;
    }

    /**
     * Sets the value of the otherSectors property.
     * 
     */
    public void setOtherSectors(long value) {
        this.otherSectors = value;
    }

}

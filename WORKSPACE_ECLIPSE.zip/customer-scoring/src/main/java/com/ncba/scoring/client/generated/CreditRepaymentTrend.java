
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for creditRepaymentTrend complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="creditRepaymentTrend"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="currency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="highestOpenTotalValueLast12Months" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="highestOpenTotalValueLast24Months" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="openTotalValue" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="scheduledAmountTotalValue" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "creditRepaymentTrend", propOrder = {
    "currency",
    "highestOpenTotalValueLast12Months",
    "highestOpenTotalValueLast24Months",
    "openTotalValue",
    "scheduledAmountTotalValue"
})
public class CreditRepaymentTrend {

    protected String currency;
    protected Double highestOpenTotalValueLast12Months;
    protected Double highestOpenTotalValueLast24Months;
    protected Double openTotalValue;
    protected Double scheduledAmountTotalValue;

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
     * Gets the value of the highestOpenTotalValueLast12Months property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getHighestOpenTotalValueLast12Months() {
        return highestOpenTotalValueLast12Months;
    }

    /**
     * Sets the value of the highestOpenTotalValueLast12Months property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setHighestOpenTotalValueLast12Months(Double value) {
        this.highestOpenTotalValueLast12Months = value;
    }

    /**
     * Gets the value of the highestOpenTotalValueLast24Months property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getHighestOpenTotalValueLast24Months() {
        return highestOpenTotalValueLast24Months;
    }

    /**
     * Sets the value of the highestOpenTotalValueLast24Months property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setHighestOpenTotalValueLast24Months(Double value) {
        this.highestOpenTotalValueLast24Months = value;
    }

    /**
     * Gets the value of the openTotalValue property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getOpenTotalValue() {
        return openTotalValue;
    }

    /**
     * Sets the value of the openTotalValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setOpenTotalValue(Double value) {
        this.openTotalValue = value;
    }

    /**
     * Gets the value of the scheduledAmountTotalValue property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getScheduledAmountTotalValue() {
        return scheduledAmountTotalValue;
    }

    /**
     * Sets the value of the scheduledAmountTotalValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setScheduledAmountTotalValue(Double value) {
        this.scheduledAmountTotalValue = value;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.controller;

import com.sun.xml.messaging.saaj.util.Base64;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.ncba.scoring.client.generated.CreditBal;
import com.ncba.scoring.client.generated.ControllerKenyaImplService;
import com.ncba.scoring.client.generated.ServerInfo;
import com.ncba.scoring.model.NcbaScorecardDets;
import com.ncba.scoring.model.NcbaScorecardDetsRepository;
import com.ncba.scoring.request.CreditBalRequest;
import com.ncba.scoring.request.IBPSRequest;
import com.ncba.scoring.request.Product144Request;
import com.ncba.scoring.utils.UtilsResponseCodes;
import com.ncba.scoring.utils.Utilz;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author Duncan.Nyakundi
 */
@RestController
@RequestMapping("api/v1/")
@Api(value = "crb-interface", description = "Operations pertaining to TransUnion Integration")
@Timed("crb")
public class TransUnionController {

    public static Logger log = LoggerFactory.getLogger(TransUnionController.class);

    RestTemplate restTemplate;
    
    @Autowired
    private UtilsResponseCodes utilsResponseCodes;

    @Value("${crb.base_url}")
    private String BASE_URL;

    @Value("${crb.username}")
    private String crb_username;

    @Value("${crb.password}")
    private String crb_password;

    @Value("${msg.username}")
    private String msg_username;
    @Value("${msg.password}")
    private String msg_password;
    @Value("${msg.code}")
    private String msg_code;
    @Value("${msg.infinityCode}")
    private String msg_infinityCode;
   

    @Autowired
    private Utilz utils;

    @Autowired
    private NcbaScorecardDetsRepository ncbaScorecardDetsRepository;

    @PostMapping("request-crb")
    public ResponseEntity<Object> getCRB(@RequestBody @Validated Product144Request request) throws JsonProcessingException, IOException, ProtocolException, NoSuchAlgorithmException, KeyManagementException {
        String result = "";

        String input = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
                + "    <Body>\n"
                + "        <getProduct144 xmlns=\"http://ws.crbws.transunion.ke.co/\">\n"
                + "            <username xmlns=\"\">" + msg_username + "</username>\n"
                + "            <password xmlns=\"\">" + msg_password + "</password>\n"
                + "            <code xmlns=\"\">" + msg_code + "</code>\n"
                + "            <infinityCode xmlns=\"\">" + msg_infinityCode + "</infinityCode>\n"
                + "            <name1 xmlns=\"\">" + request.getName1() + "</name1>\n"
                + "            <name2 xmlns=\"\">" + request.getName2() + "</name2>\n"
                + "            <name3 xmlns=\"\">[string?]</name3>\n"
                + "            <name4 xmlns=\"\">[string?]</name4>\n"
                + "            <nationalID xmlns=\"\">" + request.getNationalID() + "</nationalID>\n"
                + "            <passportNo xmlns=\"\">[string?]</passportNo>\n"
                + "            <serviceID xmlns=\"\">[string?]</serviceID>\n"
                + "            <alienID xmlns=\"\">[string?]</alienID>\n"
                + "            <taxID xmlns=\"\">[string?]</taxID>\n"
                + "            <dateOfBirth xmlns=\"\">[dateTime?]</dateOfBirth>\n"
                + "            <postalBoxNo xmlns=\"\">[string?]</postalBoxNo>\n"
                + "            <postalTown xmlns=\"\">[string?]</postalTown>\n"
                + "            <postalCountry xmlns=\"\">[string?]</postalCountry>\n"
                + "            <telephoneWork xmlns=\"\">[string?]</telephoneWork>\n"
                + "            <telephoneHome xmlns=\"\">[string?]</telephoneHome>\n"
                + "            <telephoneMobile xmlns=\"\">[string?]</telephoneMobile>\n"
                + "            <physicalAddress xmlns=\"\">[string?]</physicalAddress>\n"
                + "            <physicalTown xmlns=\"\">[string?]</physicalTown>\n"
                + "            <physicalCountry xmlns=\"\">[string?]</physicalCountry>\n"
                + "            <reportSector xmlns=\"\">" + request.getReportSector() + "</reportSector>\n"
                + "            <reportReason xmlns=\"\">" + request.getReportReason() + "</reportReason>\n"
                + "        </getProduct144>\n"
                + "    </Body>\n"
                + "</Envelope>";

        log.info("request:" + input);
//        result = "<?xml version='1.0' encoding='UTF-8'?><S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\"><SOAP-ENV:Header/><S:Body><ns2:getProduct144Response xmlns:ns2=\"http://ws.crbws.transunion.ke.co/\"><return><accountList><accountDispute>0</accountDispute><accountType><accountType>LOAN ACCOUNT</accountType><numberOfAccounts>1</numberOfAccounts></accountType><arrears0Days>1</arrears0Days><arrears30Days>0</arrears30Days><arrears60Days>0</arrears60Days><arrears90Days>0</arrears90Days><arrearsGt90Days>0</arrearsGt90Days><closedAccounts>0</closedAccounts><currency>KES</currency><currentBalance>100000.0</currentBalance><currentInArrears>0</currentInArrears><fraudCount>0</fraudCount><maxArrears>0.0</maxArrears><nonPerformingAccounts>0</nonPerformingAccounts><numberOfAccounts>1</numberOfAccounts><openAccount>0</openAccount><pastDueAmount>0.0</pastDueAmount><performingAccounts>1</performingAccounts><principalAmount>500000.0</principalAmount><scheduledPaymentAmount>0.0</scheduledPaymentAmount><subscriberBalanceAmount>0.0</subscriberBalanceAmount><subscriberPrincipalAmount>0.0</subscriberPrincipalAmount></accountList><genericScoreOutput><grade>GG</grade><positiveScore>602</positiveScore><probability>19.61</probability></genericScoreOutput><header><crbName>Credit Reference Bureau Africa Limited T/A TransUnion</crbName><pdfId>42640976-d704d20d-5f88-48a2-bffe-4257554823e7</pdfId><productDisplayName>Consumer Product with Generic and Mobile Score</productDisplayName><reportDate>2022-02-11T16:32:48-05:00</reportDate><reportType>PERSONAL_REPORT</reportType><requestNo>42640976</requestNo><requester>NCBA</requester></header><mobileAccountlist><mobileCurrentArrears>0</mobileCurrentArrears><mobileCurrentBalance>0.0</mobileCurrentBalance><mobilePrincipalAmount>0.0</mobilePrincipalAmount><mobileSubscriberBalanceAmount>0.0</mobileSubscriberBalanceAmount><mobileSubscriberPrincipalAmount>0.0</mobileSubscriberPrincipalAmount><numberOfMobileAccounts>0</numberOfMobileAccounts><numberOfMobileClosedAccounts>0</numberOfMobileClosedAccounts><numberOfMobileNonPerformingAccounts>0</numberOfMobileNonPerformingAccounts><numberOfMobileOpenAccounts>0</numberOfMobileOpenAccounts><numberOfMobilePerformingAccounts>0</numberOfMobilePerformingAccounts></mobileAccountlist><mobileScoreOutput><grade>GG</grade><mobileScore>389</mobileScore><probability>48.49</probability></mobileScoreOutput><personalProfile><crn>39718971</crn><fullName>Surname_39718971 OtherNames_39718971</fullName><nationalID>39718971</nationalID><otherNames>OtherNames_39718971</otherNames><surname>Surname_39718971</surname></personalProfile><phoneList><numberOfPhoneContacts>0</numberOfPhoneContacts></phoneList><responseCode>200</responseCode></return></ns2:getProduct144Response></S:Body></S:Envelope>";
        result = callHttp(input);
        log.info("Result: " + result);

        try {
            //convert xml response to json

            XmlMapper xmlMapper = new XmlMapper();
            JsonNode node = xmlMapper.readTree(result);

            ObjectMapper objectMapper = new ObjectMapper();
            String out = objectMapper.writeValueAsString(node);

            return new ResponseEntity(out, HttpStatus.OK);

        } catch (IOException ex) {
            log.info(ex.toString());
            return new ResponseEntity("Invalid response", HttpStatus.NOT_FOUND);
        }

    }

    @GetMapping("server-info")
    @Timed("crb.serverInfo")
    public @ResponseBody
    ResponseEntity<Object> getServerInfo() throws JsonProcessingException {
        String result = "-";
        utils.enableProxy();
        configInfo();
        ControllerKenyaImplService service = new ControllerKenyaImplService();
        ServerInfo response = service.getControllerKenyaImplPort().getServerInfo(msg_username, msg_password, msg_code, msg_infinityCode);
        ObjectMapper mapper = new ObjectMapper();

        log.info("Response: " + response.getCountry() + ":" + response.getVersion() + ":" + response.getResponseCode());

        result = mapper.writeValueAsString(response);
        return new ResponseEntity(result, HttpStatus.OK);
    }

    public void configInfo() {

        Authenticator.setDefault(
                new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(crb_username, crb_password.toCharArray());
            }
        });
    }

    @GetMapping("credit-bal")
    public @ResponseBody
    ResponseEntity<Object> getCreditBal() throws ProtocolException, IOException, NoSuchAlgorithmException, KeyManagementException {
        String result = null;
        String input = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
                + "    <Body>\n"
                + "        <getCreditBal xmlns=\"http://ws.crbws.transunion.ke.co/\">\n"
                + "            <username xmlns=\"\">" + msg_username + "</username>\n"
                + "            <password xmlns=\"\">" + msg_password + "</password>\n"
                + "            <code xmlns=\"\">" + msg_code + "</code>\n"
                + "            <infinityCode xmlns=\"\">" + msg_infinityCode + "</infinityCode>\n"
                + "        </getCreditBal>\n"
                + "    </Body>\n"
                + "</Envelope>";

        result = callHttp(input);

        return new ResponseEntity(result, HttpStatus.OK);
    }

    public void loadConfig() throws NoSuchAlgorithmException, KeyManagementException {
        TrustManager[] trustAllCerts = new TrustManager[]{
            new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                @Override
                public void checkClientTrusted(
                        java.security.cert.X509Certificate[] certificates, String authType) {
                }

                @Override
                public void checkServerTrusted(
                        java.security.cert.X509Certificate[] certificates, String authType) {
                }
            }
        };
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

    }

    private String callHttp(String input) throws ProtocolException, IOException, NoSuchAlgorithmException, KeyManagementException {
        String auth = crb_username + ":" + crb_password;
         
        String result = null;
        
        byte[] encodedAuth = Base64.encode(auth.getBytes(StandardCharsets.UTF_8));
        String authHeader = "Basic " + new String(encodedAuth);
        
        log.info("*auth: "+auth);
        log.info("auth: "+authHeader);
        
        loadConfig();

        URL obj = new URL(BASE_URL);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Authorization", authHeader);
        con.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
        con.setRequestProperty("Accept", "application/xml");
        con.setConnectTimeout(60000);
        con.setReadTimeout(60000);
        con.setDoOutput(true);
        try (OutputStream os = con.getOutputStream()) {
            os.write(input.getBytes());
            os.flush();
        }
        int responseCode = con.getResponseCode();
        log.info("Response Code :: " + responseCode);
        if (responseCode == HttpURLConnection.HTTP_OK) {
            StringBuilder response;
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                response = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
            }
            result = response.toString();
            log.info("Response from CRB: " + response.toString());

        } else {
            StringBuilder response;
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getErrorStream()))) {
                String inputLine;
                response = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
            }
            //$$$$$$$$$$REMOVE$$$$$$$$$$
                Object v = utilsResponseCodes.getResponse_codes().get(responseCode);
                log.info("k:"+responseCode+" v:"+v);
            //------------------------------
            log.info("Response from CRB: " + response.toString());

            result = response.toString();
            log.error("Error Response :: " + response.toString());

        }

        return result;
    }
    
   

    @PostMapping("invokeT24Datamart")
    public @ResponseBody
    ResponseEntity<Object> getT24Datamart(@RequestBody @Validated IBPSRequest request) {
        NcbaScorecardDets model = ncbaScorecardDetsRepository.findByNationalId(request.getNationalId());
        if (model == null) {
            return ResponseEntity.badRequest().body(request.getNationalId() + " Record not found");
        }
        return new ResponseEntity(model.toString(), HttpStatus.OK);
    }
}

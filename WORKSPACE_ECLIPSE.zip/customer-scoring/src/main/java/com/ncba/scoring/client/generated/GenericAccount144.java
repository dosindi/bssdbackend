
package com.ncba.scoring.client.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for genericAccount144 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="genericAccount144"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountDispute" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="accountType" type="{http://ws.crbws.transunion.ke.co/}accountType144" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="arrears0Days" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="arrears30Days" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="arrears60Days" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="arrears90Days" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="arrearsGt90Days" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="closedAccounts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="currency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currentBalance" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="currentInArrears" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="fraudCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="lastPaymentDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="maxArrears" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="nonPerformingAccounts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="numberOfAccounts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="openAccount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="pastDueAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="performingAccounts" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="principalAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="scheduledPaymentAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="subscriberBalanceAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="subscriberPrincipalAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "genericAccount144", propOrder = {
    "accountDispute",
    "accountType",
    "arrears0Days",
    "arrears30Days",
    "arrears60Days",
    "arrears90Days",
    "arrearsGt90Days",
    "closedAccounts",
    "currency",
    "currentBalance",
    "currentInArrears",
    "fraudCount",
    "lastPaymentDate",
    "maxArrears",
    "nonPerformingAccounts",
    "numberOfAccounts",
    "openAccount",
    "pastDueAmount",
    "performingAccounts",
    "principalAmount",
    "scheduledPaymentAmount",
    "subscriberBalanceAmount",
    "subscriberPrincipalAmount"
})
public class GenericAccount144 {

    protected int accountDispute;
    @XmlElement(nillable = true)
    protected List<AccountType144> accountType;
    protected int arrears0Days;
    protected int arrears30Days;
    protected int arrears60Days;
    protected int arrears90Days;
    protected int arrearsGt90Days;
    protected int closedAccounts;
    protected String currency;
    protected Double currentBalance;
    protected int currentInArrears;
    protected int fraudCount;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastPaymentDate;
    protected Double maxArrears;
    protected int nonPerformingAccounts;
    protected int numberOfAccounts;
    protected int openAccount;
    protected Double pastDueAmount;
    protected int performingAccounts;
    protected Double principalAmount;
    protected Double scheduledPaymentAmount;
    protected Double subscriberBalanceAmount;
    protected Double subscriberPrincipalAmount;

    /**
     * Gets the value of the accountDispute property.
     * 
     */
    public int getAccountDispute() {
        return accountDispute;
    }

    /**
     * Sets the value of the accountDispute property.
     * 
     */
    public void setAccountDispute(int value) {
        this.accountDispute = value;
    }

    /**
     * Gets the value of the accountType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accountType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccountType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AccountType144 }
     * 
     * 
     */
    public List<AccountType144> getAccountType() {
        if (accountType == null) {
            accountType = new ArrayList<AccountType144>();
        }
        return this.accountType;
    }

    /**
     * Gets the value of the arrears0Days property.
     * 
     */
    public int getArrears0Days() {
        return arrears0Days;
    }

    /**
     * Sets the value of the arrears0Days property.
     * 
     */
    public void setArrears0Days(int value) {
        this.arrears0Days = value;
    }

    /**
     * Gets the value of the arrears30Days property.
     * 
     */
    public int getArrears30Days() {
        return arrears30Days;
    }

    /**
     * Sets the value of the arrears30Days property.
     * 
     */
    public void setArrears30Days(int value) {
        this.arrears30Days = value;
    }

    /**
     * Gets the value of the arrears60Days property.
     * 
     */
    public int getArrears60Days() {
        return arrears60Days;
    }

    /**
     * Sets the value of the arrears60Days property.
     * 
     */
    public void setArrears60Days(int value) {
        this.arrears60Days = value;
    }

    /**
     * Gets the value of the arrears90Days property.
     * 
     */
    public int getArrears90Days() {
        return arrears90Days;
    }

    /**
     * Sets the value of the arrears90Days property.
     * 
     */
    public void setArrears90Days(int value) {
        this.arrears90Days = value;
    }

    /**
     * Gets the value of the arrearsGt90Days property.
     * 
     */
    public int getArrearsGt90Days() {
        return arrearsGt90Days;
    }

    /**
     * Sets the value of the arrearsGt90Days property.
     * 
     */
    public void setArrearsGt90Days(int value) {
        this.arrearsGt90Days = value;
    }

    /**
     * Gets the value of the closedAccounts property.
     * 
     */
    public int getClosedAccounts() {
        return closedAccounts;
    }

    /**
     * Sets the value of the closedAccounts property.
     * 
     */
    public void setClosedAccounts(int value) {
        this.closedAccounts = value;
    }

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
     * Gets the value of the currentBalance property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCurrentBalance() {
        return currentBalance;
    }

    /**
     * Sets the value of the currentBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCurrentBalance(Double value) {
        this.currentBalance = value;
    }

    /**
     * Gets the value of the currentInArrears property.
     * 
     */
    public int getCurrentInArrears() {
        return currentInArrears;
    }

    /**
     * Sets the value of the currentInArrears property.
     * 
     */
    public void setCurrentInArrears(int value) {
        this.currentInArrears = value;
    }

    /**
     * Gets the value of the fraudCount property.
     * 
     */
    public int getFraudCount() {
        return fraudCount;
    }

    /**
     * Sets the value of the fraudCount property.
     * 
     */
    public void setFraudCount(int value) {
        this.fraudCount = value;
    }

    /**
     * Gets the value of the lastPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * Sets the value of the lastPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastPaymentDate(XMLGregorianCalendar value) {
        this.lastPaymentDate = value;
    }

    /**
     * Gets the value of the maxArrears property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMaxArrears() {
        return maxArrears;
    }

    /**
     * Sets the value of the maxArrears property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMaxArrears(Double value) {
        this.maxArrears = value;
    }

    /**
     * Gets the value of the nonPerformingAccounts property.
     * 
     */
    public int getNonPerformingAccounts() {
        return nonPerformingAccounts;
    }

    /**
     * Sets the value of the nonPerformingAccounts property.
     * 
     */
    public void setNonPerformingAccounts(int value) {
        this.nonPerformingAccounts = value;
    }

    /**
     * Gets the value of the numberOfAccounts property.
     * 
     */
    public int getNumberOfAccounts() {
        return numberOfAccounts;
    }

    /**
     * Sets the value of the numberOfAccounts property.
     * 
     */
    public void setNumberOfAccounts(int value) {
        this.numberOfAccounts = value;
    }

    /**
     * Gets the value of the openAccount property.
     * 
     */
    public int getOpenAccount() {
        return openAccount;
    }

    /**
     * Sets the value of the openAccount property.
     * 
     */
    public void setOpenAccount(int value) {
        this.openAccount = value;
    }

    /**
     * Gets the value of the pastDueAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPastDueAmount() {
        return pastDueAmount;
    }

    /**
     * Sets the value of the pastDueAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPastDueAmount(Double value) {
        this.pastDueAmount = value;
    }

    /**
     * Gets the value of the performingAccounts property.
     * 
     */
    public int getPerformingAccounts() {
        return performingAccounts;
    }

    /**
     * Sets the value of the performingAccounts property.
     * 
     */
    public void setPerformingAccounts(int value) {
        this.performingAccounts = value;
    }

    /**
     * Gets the value of the principalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPrincipalAmount() {
        return principalAmount;
    }

    /**
     * Sets the value of the principalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPrincipalAmount(Double value) {
        this.principalAmount = value;
    }

    /**
     * Gets the value of the scheduledPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getScheduledPaymentAmount() {
        return scheduledPaymentAmount;
    }

    /**
     * Sets the value of the scheduledPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setScheduledPaymentAmount(Double value) {
        this.scheduledPaymentAmount = value;
    }

    /**
     * Gets the value of the subscriberBalanceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSubscriberBalanceAmount() {
        return subscriberBalanceAmount;
    }

    /**
     * Sets the value of the subscriberBalanceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSubscriberBalanceAmount(Double value) {
        this.subscriberBalanceAmount = value;
    }

    /**
     * Gets the value of the subscriberPrincipalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSubscriberPrincipalAmount() {
        return subscriberPrincipalAmount;
    }

    /**
     * Sets the value of the subscriberPrincipalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSubscriberPrincipalAmount(Double value) {
        this.subscriberPrincipalAmount = value;
    }

}

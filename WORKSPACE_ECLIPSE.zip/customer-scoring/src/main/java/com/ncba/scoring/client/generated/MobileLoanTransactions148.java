
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for mobileLoanTransactions148 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="mobileLoanTransactions148"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="lastMobileLoanPaymentAmount" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="maxMobileLoanPaymentsLast30Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="maxMobileLoanPaymentsLast60Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="maxMobileLoanPaymentsLast90Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="numberOfEnquiriesLast30Days" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="numberOfEnquiriesLast60Days" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="numberOfEnquiriesLast90Days" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="numberOfMobileLoanPaymentsLast30Days" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="numberOfMobileLoanPaymentsLast60Days" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="numberOfMobileLoanPaymentsLast90Days" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="totalMobileLoanPaymentsLast30Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="totalMobileLoanPaymentsLast60Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *         &lt;element name="totalMobileLoanPaymentsLast90Days" type="{http://ws.crbws.transunion.ke.co/}countSectorDouble" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mobileLoanTransactions148", propOrder = {
    "lastMobileLoanPaymentAmount",
    "maxMobileLoanPaymentsLast30Days",
    "maxMobileLoanPaymentsLast60Days",
    "maxMobileLoanPaymentsLast90Days",
    "numberOfEnquiriesLast30Days",
    "numberOfEnquiriesLast60Days",
    "numberOfEnquiriesLast90Days",
    "numberOfMobileLoanPaymentsLast30Days",
    "numberOfMobileLoanPaymentsLast60Days",
    "numberOfMobileLoanPaymentsLast90Days",
    "totalMobileLoanPaymentsLast30Days",
    "totalMobileLoanPaymentsLast60Days",
    "totalMobileLoanPaymentsLast90Days"
})
public class MobileLoanTransactions148 {

    protected CountSectorDouble lastMobileLoanPaymentAmount;
    protected CountSectorDouble maxMobileLoanPaymentsLast30Days;
    protected CountSectorDouble maxMobileLoanPaymentsLast60Days;
    protected CountSectorDouble maxMobileLoanPaymentsLast90Days;
    protected CountSector numberOfEnquiriesLast30Days;
    protected CountSector numberOfEnquiriesLast60Days;
    protected CountSector numberOfEnquiriesLast90Days;
    protected CountSector numberOfMobileLoanPaymentsLast30Days;
    protected CountSector numberOfMobileLoanPaymentsLast60Days;
    protected CountSector numberOfMobileLoanPaymentsLast90Days;
    protected CountSectorDouble totalMobileLoanPaymentsLast30Days;
    protected CountSectorDouble totalMobileLoanPaymentsLast60Days;
    protected CountSectorDouble totalMobileLoanPaymentsLast90Days;

    /**
     * Gets the value of the lastMobileLoanPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getLastMobileLoanPaymentAmount() {
        return lastMobileLoanPaymentAmount;
    }

    /**
     * Sets the value of the lastMobileLoanPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setLastMobileLoanPaymentAmount(CountSectorDouble value) {
        this.lastMobileLoanPaymentAmount = value;
    }

    /**
     * Gets the value of the maxMobileLoanPaymentsLast30Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getMaxMobileLoanPaymentsLast30Days() {
        return maxMobileLoanPaymentsLast30Days;
    }

    /**
     * Sets the value of the maxMobileLoanPaymentsLast30Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setMaxMobileLoanPaymentsLast30Days(CountSectorDouble value) {
        this.maxMobileLoanPaymentsLast30Days = value;
    }

    /**
     * Gets the value of the maxMobileLoanPaymentsLast60Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getMaxMobileLoanPaymentsLast60Days() {
        return maxMobileLoanPaymentsLast60Days;
    }

    /**
     * Sets the value of the maxMobileLoanPaymentsLast60Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setMaxMobileLoanPaymentsLast60Days(CountSectorDouble value) {
        this.maxMobileLoanPaymentsLast60Days = value;
    }

    /**
     * Gets the value of the maxMobileLoanPaymentsLast90Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getMaxMobileLoanPaymentsLast90Days() {
        return maxMobileLoanPaymentsLast90Days;
    }

    /**
     * Sets the value of the maxMobileLoanPaymentsLast90Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setMaxMobileLoanPaymentsLast90Days(CountSectorDouble value) {
        this.maxMobileLoanPaymentsLast90Days = value;
    }

    /**
     * Gets the value of the numberOfEnquiriesLast30Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNumberOfEnquiriesLast30Days() {
        return numberOfEnquiriesLast30Days;
    }

    /**
     * Sets the value of the numberOfEnquiriesLast30Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNumberOfEnquiriesLast30Days(CountSector value) {
        this.numberOfEnquiriesLast30Days = value;
    }

    /**
     * Gets the value of the numberOfEnquiriesLast60Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNumberOfEnquiriesLast60Days() {
        return numberOfEnquiriesLast60Days;
    }

    /**
     * Sets the value of the numberOfEnquiriesLast60Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNumberOfEnquiriesLast60Days(CountSector value) {
        this.numberOfEnquiriesLast60Days = value;
    }

    /**
     * Gets the value of the numberOfEnquiriesLast90Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNumberOfEnquiriesLast90Days() {
        return numberOfEnquiriesLast90Days;
    }

    /**
     * Sets the value of the numberOfEnquiriesLast90Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNumberOfEnquiriesLast90Days(CountSector value) {
        this.numberOfEnquiriesLast90Days = value;
    }

    /**
     * Gets the value of the numberOfMobileLoanPaymentsLast30Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNumberOfMobileLoanPaymentsLast30Days() {
        return numberOfMobileLoanPaymentsLast30Days;
    }

    /**
     * Sets the value of the numberOfMobileLoanPaymentsLast30Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNumberOfMobileLoanPaymentsLast30Days(CountSector value) {
        this.numberOfMobileLoanPaymentsLast30Days = value;
    }

    /**
     * Gets the value of the numberOfMobileLoanPaymentsLast60Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNumberOfMobileLoanPaymentsLast60Days() {
        return numberOfMobileLoanPaymentsLast60Days;
    }

    /**
     * Sets the value of the numberOfMobileLoanPaymentsLast60Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNumberOfMobileLoanPaymentsLast60Days(CountSector value) {
        this.numberOfMobileLoanPaymentsLast60Days = value;
    }

    /**
     * Gets the value of the numberOfMobileLoanPaymentsLast90Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNumberOfMobileLoanPaymentsLast90Days() {
        return numberOfMobileLoanPaymentsLast90Days;
    }

    /**
     * Sets the value of the numberOfMobileLoanPaymentsLast90Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNumberOfMobileLoanPaymentsLast90Days(CountSector value) {
        this.numberOfMobileLoanPaymentsLast90Days = value;
    }

    /**
     * Gets the value of the totalMobileLoanPaymentsLast30Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getTotalMobileLoanPaymentsLast30Days() {
        return totalMobileLoanPaymentsLast30Days;
    }

    /**
     * Sets the value of the totalMobileLoanPaymentsLast30Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setTotalMobileLoanPaymentsLast30Days(CountSectorDouble value) {
        this.totalMobileLoanPaymentsLast30Days = value;
    }

    /**
     * Gets the value of the totalMobileLoanPaymentsLast60Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getTotalMobileLoanPaymentsLast60Days() {
        return totalMobileLoanPaymentsLast60Days;
    }

    /**
     * Sets the value of the totalMobileLoanPaymentsLast60Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setTotalMobileLoanPaymentsLast60Days(CountSectorDouble value) {
        this.totalMobileLoanPaymentsLast60Days = value;
    }

    /**
     * Gets the value of the totalMobileLoanPaymentsLast90Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSectorDouble }
     *     
     */
    public CountSectorDouble getTotalMobileLoanPaymentsLast90Days() {
        return totalMobileLoanPaymentsLast90Days;
    }

    /**
     * Sets the value of the totalMobileLoanPaymentsLast90Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSectorDouble }
     *     
     */
    public void setTotalMobileLoanPaymentsLast90Days(CountSectorDouble value) {
        this.totalMobileLoanPaymentsLast90Days = value;
    }

}

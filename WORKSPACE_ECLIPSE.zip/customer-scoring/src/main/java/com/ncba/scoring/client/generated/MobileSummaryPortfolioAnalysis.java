
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for mobileSummaryPortfolioAnalysis complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="mobileSummaryPortfolioAnalysis"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="enquiriesLast30Days" type="{http://ws.crbws.transunion.ke.co/}countSector145" minOccurs="0"/&gt;
 *         &lt;element name="lastLendingScore" type="{http://ws.crbws.transunion.ke.co/}mobileCreditScoreGrade" minOccurs="0"/&gt;
 *         &lt;element name="mobileOpenNPA" type="{http://ws.crbws.transunion.ke.co/}countSector145" minOccurs="0"/&gt;
 *         &lt;element name="mobileOpenPAWithDefaultHistory" type="{http://ws.crbws.transunion.ke.co/}countSector145" minOccurs="0"/&gt;
 *         &lt;element name="mobileOpenPa" type="{http://ws.crbws.transunion.ke.co/}countSector145" minOccurs="0"/&gt;
 *         &lt;element name="shareOfWallet" type="{http://ws.crbws.transunion.ke.co/}walletRepresentation" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mobileSummaryPortfolioAnalysis", propOrder = {
    "enquiriesLast30Days",
    "lastLendingScore",
    "mobileOpenNPA",
    "mobileOpenPAWithDefaultHistory",
    "mobileOpenPa",
    "shareOfWallet"
})
public class MobileSummaryPortfolioAnalysis {

    protected CountSector145 enquiriesLast30Days;
    protected MobileCreditScoreGrade lastLendingScore;
    protected CountSector145 mobileOpenNPA;
    protected CountSector145 mobileOpenPAWithDefaultHistory;
    protected CountSector145 mobileOpenPa;
    protected WalletRepresentation shareOfWallet;

    /**
     * Gets the value of the enquiriesLast30Days property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector145 }
     *     
     */
    public CountSector145 getEnquiriesLast30Days() {
        return enquiriesLast30Days;
    }

    /**
     * Sets the value of the enquiriesLast30Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector145 }
     *     
     */
    public void setEnquiriesLast30Days(CountSector145 value) {
        this.enquiriesLast30Days = value;
    }

    /**
     * Gets the value of the lastLendingScore property.
     * 
     * @return
     *     possible object is
     *     {@link MobileCreditScoreGrade }
     *     
     */
    public MobileCreditScoreGrade getLastLendingScore() {
        return lastLendingScore;
    }

    /**
     * Sets the value of the lastLendingScore property.
     * 
     * @param value
     *     allowed object is
     *     {@link MobileCreditScoreGrade }
     *     
     */
    public void setLastLendingScore(MobileCreditScoreGrade value) {
        this.lastLendingScore = value;
    }

    /**
     * Gets the value of the mobileOpenNPA property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector145 }
     *     
     */
    public CountSector145 getMobileOpenNPA() {
        return mobileOpenNPA;
    }

    /**
     * Sets the value of the mobileOpenNPA property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector145 }
     *     
     */
    public void setMobileOpenNPA(CountSector145 value) {
        this.mobileOpenNPA = value;
    }

    /**
     * Gets the value of the mobileOpenPAWithDefaultHistory property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector145 }
     *     
     */
    public CountSector145 getMobileOpenPAWithDefaultHistory() {
        return mobileOpenPAWithDefaultHistory;
    }

    /**
     * Sets the value of the mobileOpenPAWithDefaultHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector145 }
     *     
     */
    public void setMobileOpenPAWithDefaultHistory(CountSector145 value) {
        this.mobileOpenPAWithDefaultHistory = value;
    }

    /**
     * Gets the value of the mobileOpenPa property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector145 }
     *     
     */
    public CountSector145 getMobileOpenPa() {
        return mobileOpenPa;
    }

    /**
     * Sets the value of the mobileOpenPa property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector145 }
     *     
     */
    public void setMobileOpenPa(CountSector145 value) {
        this.mobileOpenPa = value;
    }

    /**
     * Gets the value of the shareOfWallet property.
     * 
     * @return
     *     possible object is
     *     {@link WalletRepresentation }
     *     
     */
    public WalletRepresentation getShareOfWallet() {
        return shareOfWallet;
    }

    /**
     * Sets the value of the shareOfWallet property.
     * 
     * @param value
     *     allowed object is
     *     {@link WalletRepresentation }
     *     
     */
    public void setShareOfWallet(WalletRepresentation value) {
        this.shareOfWallet = value;
    }

}

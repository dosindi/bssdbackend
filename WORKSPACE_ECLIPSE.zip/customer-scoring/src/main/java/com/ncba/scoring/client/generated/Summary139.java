
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for summary139 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="summary139"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="creditActive" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="creditHistory" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="enquiriesLast24Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="enquiriesLast72Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="mobileAccountsLast24Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="mobileAccountsLast72Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="mobileContactsUsedLast24Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="mobileContactsUsedLast72Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="mobileLendersLast24Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="mobileLendersLast72Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="npaAccounts" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="openAccounts" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="openMobileAccountsLast24Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="openMobileAccountsLast72Hours" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="paAccounts" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *         &lt;element name="paOpenAccounts" type="{http://ws.crbws.transunion.ke.co/}countSector" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "summary139", propOrder = {
    "creditActive",
    "creditHistory",
    "enquiriesLast24Hours",
    "enquiriesLast72Hours",
    "mobileAccountsLast24Hours",
    "mobileAccountsLast72Hours",
    "mobileContactsUsedLast24Hours",
    "mobileContactsUsedLast72Hours",
    "mobileLendersLast24Hours",
    "mobileLendersLast72Hours",
    "npaAccounts",
    "openAccounts",
    "openMobileAccountsLast24Hours",
    "openMobileAccountsLast72Hours",
    "paAccounts",
    "paOpenAccounts"
})
public class Summary139 {

    protected boolean creditActive;
    protected CountSector creditHistory;
    protected CountSector enquiriesLast24Hours;
    protected CountSector enquiriesLast72Hours;
    protected CountSector mobileAccountsLast24Hours;
    protected CountSector mobileAccountsLast72Hours;
    protected CountSector mobileContactsUsedLast24Hours;
    protected CountSector mobileContactsUsedLast72Hours;
    protected CountSector mobileLendersLast24Hours;
    protected CountSector mobileLendersLast72Hours;
    protected CountSector npaAccounts;
    protected CountSector openAccounts;
    protected CountSector openMobileAccountsLast24Hours;
    protected CountSector openMobileAccountsLast72Hours;
    protected CountSector paAccounts;
    protected CountSector paOpenAccounts;

    /**
     * Gets the value of the creditActive property.
     * 
     */
    public boolean isCreditActive() {
        return creditActive;
    }

    /**
     * Sets the value of the creditActive property.
     * 
     */
    public void setCreditActive(boolean value) {
        this.creditActive = value;
    }

    /**
     * Gets the value of the creditHistory property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getCreditHistory() {
        return creditHistory;
    }

    /**
     * Sets the value of the creditHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setCreditHistory(CountSector value) {
        this.creditHistory = value;
    }

    /**
     * Gets the value of the enquiriesLast24Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getEnquiriesLast24Hours() {
        return enquiriesLast24Hours;
    }

    /**
     * Sets the value of the enquiriesLast24Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setEnquiriesLast24Hours(CountSector value) {
        this.enquiriesLast24Hours = value;
    }

    /**
     * Gets the value of the enquiriesLast72Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getEnquiriesLast72Hours() {
        return enquiriesLast72Hours;
    }

    /**
     * Sets the value of the enquiriesLast72Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setEnquiriesLast72Hours(CountSector value) {
        this.enquiriesLast72Hours = value;
    }

    /**
     * Gets the value of the mobileAccountsLast24Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getMobileAccountsLast24Hours() {
        return mobileAccountsLast24Hours;
    }

    /**
     * Sets the value of the mobileAccountsLast24Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setMobileAccountsLast24Hours(CountSector value) {
        this.mobileAccountsLast24Hours = value;
    }

    /**
     * Gets the value of the mobileAccountsLast72Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getMobileAccountsLast72Hours() {
        return mobileAccountsLast72Hours;
    }

    /**
     * Sets the value of the mobileAccountsLast72Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setMobileAccountsLast72Hours(CountSector value) {
        this.mobileAccountsLast72Hours = value;
    }

    /**
     * Gets the value of the mobileContactsUsedLast24Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getMobileContactsUsedLast24Hours() {
        return mobileContactsUsedLast24Hours;
    }

    /**
     * Sets the value of the mobileContactsUsedLast24Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setMobileContactsUsedLast24Hours(CountSector value) {
        this.mobileContactsUsedLast24Hours = value;
    }

    /**
     * Gets the value of the mobileContactsUsedLast72Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getMobileContactsUsedLast72Hours() {
        return mobileContactsUsedLast72Hours;
    }

    /**
     * Sets the value of the mobileContactsUsedLast72Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setMobileContactsUsedLast72Hours(CountSector value) {
        this.mobileContactsUsedLast72Hours = value;
    }

    /**
     * Gets the value of the mobileLendersLast24Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getMobileLendersLast24Hours() {
        return mobileLendersLast24Hours;
    }

    /**
     * Sets the value of the mobileLendersLast24Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setMobileLendersLast24Hours(CountSector value) {
        this.mobileLendersLast24Hours = value;
    }

    /**
     * Gets the value of the mobileLendersLast72Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getMobileLendersLast72Hours() {
        return mobileLendersLast72Hours;
    }

    /**
     * Sets the value of the mobileLendersLast72Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setMobileLendersLast72Hours(CountSector value) {
        this.mobileLendersLast72Hours = value;
    }

    /**
     * Gets the value of the npaAccounts property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getNpaAccounts() {
        return npaAccounts;
    }

    /**
     * Sets the value of the npaAccounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setNpaAccounts(CountSector value) {
        this.npaAccounts = value;
    }

    /**
     * Gets the value of the openAccounts property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getOpenAccounts() {
        return openAccounts;
    }

    /**
     * Sets the value of the openAccounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setOpenAccounts(CountSector value) {
        this.openAccounts = value;
    }

    /**
     * Gets the value of the openMobileAccountsLast24Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getOpenMobileAccountsLast24Hours() {
        return openMobileAccountsLast24Hours;
    }

    /**
     * Sets the value of the openMobileAccountsLast24Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setOpenMobileAccountsLast24Hours(CountSector value) {
        this.openMobileAccountsLast24Hours = value;
    }

    /**
     * Gets the value of the openMobileAccountsLast72Hours property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getOpenMobileAccountsLast72Hours() {
        return openMobileAccountsLast72Hours;
    }

    /**
     * Sets the value of the openMobileAccountsLast72Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setOpenMobileAccountsLast72Hours(CountSector value) {
        this.openMobileAccountsLast72Hours = value;
    }

    /**
     * Gets the value of the paAccounts property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getPaAccounts() {
        return paAccounts;
    }

    /**
     * Sets the value of the paAccounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setPaAccounts(CountSector value) {
        this.paAccounts = value;
    }

    /**
     * Gets the value of the paOpenAccounts property.
     * 
     * @return
     *     possible object is
     *     {@link CountSector }
     *     
     */
    public CountSector getPaOpenAccounts() {
        return paOpenAccounts;
    }

    /**
     * Sets the value of the paOpenAccounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountSector }
     *     
     */
    public void setPaOpenAccounts(CountSector value) {
        this.paOpenAccounts = value;
    }

}

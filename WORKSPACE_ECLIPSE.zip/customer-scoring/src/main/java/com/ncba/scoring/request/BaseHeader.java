/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.request;

import javax.persistence.MappedSuperclass;
import lombok.Data;

/**
 *
 * @author Duncan.Nyakundi
 */
@Data
@MappedSuperclass
public class BaseHeader {

    private String username;
    private String password;
    private String code;
    private String infinityCode;
}


package com.ncba.scoring.client.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for product146 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="product146"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="averageScore" type="{http://ws.crbws.transunion.ke.co/}mobileCreditScorePerformance" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="closedMobileAccounts" type="{http://ws.crbws.transunion.ke.co/}mobilePastCreditRepayments" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="creditActivityClassification" type="{http://ws.crbws.transunion.ke.co/}creditActivityClassification" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="creditScoreHistory" type="{http://ws.crbws.transunion.ke.co/}mobileCreditScoreTrend" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="header" type="{http://ws.crbws.transunion.ke.co/}header" minOccurs="0"/&gt;
 *         &lt;element name="openMobileLoanAccounts" type="{http://ws.crbws.transunion.ke.co/}currentOutstandingLoans" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="personalProfile" type="{http://ws.crbws.transunion.ke.co/}personalProfile145" minOccurs="0"/&gt;
 *         &lt;element name="phone" type="{http://ws.crbws.transunion.ke.co/}phone" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="responseCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="scoreOutput" type="{http://ws.crbws.transunion.ke.co/}mobileScoreOutput145" minOccurs="0"/&gt;
 *         &lt;element name="sixMonthsEnquiryHistory" type="{http://ws.crbws.transunion.ke.co/}sixMonthsEnquiryHistory" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="summaryOfPortfolioAnalysis" type="{http://ws.crbws.transunion.ke.co/}mobileSummaryPortfolioAnalysis" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "product146", propOrder = {
    "averageScore",
    "closedMobileAccounts",
    "creditActivityClassification",
    "creditScoreHistory",
    "header",
    "openMobileLoanAccounts",
    "personalProfile",
    "phone",
    "responseCode",
    "scoreOutput",
    "sixMonthsEnquiryHistory",
    "summaryOfPortfolioAnalysis"
})
public class Product146 {

    @XmlElement(nillable = true)
    protected List<MobileCreditScorePerformance> averageScore;
    @XmlElement(nillable = true)
    protected List<MobilePastCreditRepayments> closedMobileAccounts;
    @XmlElement(nillable = true)
    protected List<CreditActivityClassification> creditActivityClassification;
    @XmlElement(nillable = true)
    protected List<MobileCreditScoreTrend> creditScoreHistory;
    protected Header header;
    @XmlElement(nillable = true)
    protected List<CurrentOutstandingLoans> openMobileLoanAccounts;
    protected PersonalProfile145 personalProfile;
    @XmlElement(nillable = true)
    protected List<Phone> phone;
    protected Integer responseCode;
    protected MobileScoreOutput145 scoreOutput;
    @XmlElement(nillable = true)
    protected List<SixMonthsEnquiryHistory> sixMonthsEnquiryHistory;
    protected MobileSummaryPortfolioAnalysis summaryOfPortfolioAnalysis;

    /**
     * Gets the value of the averageScore property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the averageScore property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAverageScore().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MobileCreditScorePerformance }
     * 
     * 
     */
    public List<MobileCreditScorePerformance> getAverageScore() {
        if (averageScore == null) {
            averageScore = new ArrayList<MobileCreditScorePerformance>();
        }
        return this.averageScore;
    }

    /**
     * Gets the value of the closedMobileAccounts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the closedMobileAccounts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClosedMobileAccounts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MobilePastCreditRepayments }
     * 
     * 
     */
    public List<MobilePastCreditRepayments> getClosedMobileAccounts() {
        if (closedMobileAccounts == null) {
            closedMobileAccounts = new ArrayList<MobilePastCreditRepayments>();
        }
        return this.closedMobileAccounts;
    }

    /**
     * Gets the value of the creditActivityClassification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditActivityClassification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditActivityClassification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditActivityClassification }
     * 
     * 
     */
    public List<CreditActivityClassification> getCreditActivityClassification() {
        if (creditActivityClassification == null) {
            creditActivityClassification = new ArrayList<CreditActivityClassification>();
        }
        return this.creditActivityClassification;
    }

    /**
     * Gets the value of the creditScoreHistory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditScoreHistory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditScoreHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MobileCreditScoreTrend }
     * 
     * 
     */
    public List<MobileCreditScoreTrend> getCreditScoreHistory() {
        if (creditScoreHistory == null) {
            creditScoreHistory = new ArrayList<MobileCreditScoreTrend>();
        }
        return this.creditScoreHistory;
    }

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link Header }
     *     
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link Header }
     *     
     */
    public void setHeader(Header value) {
        this.header = value;
    }

    /**
     * Gets the value of the openMobileLoanAccounts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the openMobileLoanAccounts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOpenMobileLoanAccounts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrentOutstandingLoans }
     * 
     * 
     */
    public List<CurrentOutstandingLoans> getOpenMobileLoanAccounts() {
        if (openMobileLoanAccounts == null) {
            openMobileLoanAccounts = new ArrayList<CurrentOutstandingLoans>();
        }
        return this.openMobileLoanAccounts;
    }

    /**
     * Gets the value of the personalProfile property.
     * 
     * @return
     *     possible object is
     *     {@link PersonalProfile145 }
     *     
     */
    public PersonalProfile145 getPersonalProfile() {
        return personalProfile;
    }

    /**
     * Sets the value of the personalProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonalProfile145 }
     *     
     */
    public void setPersonalProfile(PersonalProfile145 value) {
        this.personalProfile = value;
    }

    /**
     * Gets the value of the phone property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the phone property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhone().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Phone }
     * 
     * 
     */
    public List<Phone> getPhone() {
        if (phone == null) {
            phone = new ArrayList<Phone>();
        }
        return this.phone;
    }

    /**
     * Gets the value of the responseCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getResponseCode() {
        return responseCode;
    }

    /**
     * Sets the value of the responseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setResponseCode(Integer value) {
        this.responseCode = value;
    }

    /**
     * Gets the value of the scoreOutput property.
     * 
     * @return
     *     possible object is
     *     {@link MobileScoreOutput145 }
     *     
     */
    public MobileScoreOutput145 getScoreOutput() {
        return scoreOutput;
    }

    /**
     * Sets the value of the scoreOutput property.
     * 
     * @param value
     *     allowed object is
     *     {@link MobileScoreOutput145 }
     *     
     */
    public void setScoreOutput(MobileScoreOutput145 value) {
        this.scoreOutput = value;
    }

    /**
     * Gets the value of the sixMonthsEnquiryHistory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sixMonthsEnquiryHistory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSixMonthsEnquiryHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SixMonthsEnquiryHistory }
     * 
     * 
     */
    public List<SixMonthsEnquiryHistory> getSixMonthsEnquiryHistory() {
        if (sixMonthsEnquiryHistory == null) {
            sixMonthsEnquiryHistory = new ArrayList<SixMonthsEnquiryHistory>();
        }
        return this.sixMonthsEnquiryHistory;
    }

    /**
     * Gets the value of the summaryOfPortfolioAnalysis property.
     * 
     * @return
     *     possible object is
     *     {@link MobileSummaryPortfolioAnalysis }
     *     
     */
    public MobileSummaryPortfolioAnalysis getSummaryOfPortfolioAnalysis() {
        return summaryOfPortfolioAnalysis;
    }

    /**
     * Sets the value of the summaryOfPortfolioAnalysis property.
     * 
     * @param value
     *     allowed object is
     *     {@link MobileSummaryPortfolioAnalysis }
     *     
     */
    public void setSummaryOfPortfolioAnalysis(MobileSummaryPortfolioAnalysis value) {
        this.summaryOfPortfolioAnalysis = value;
    }

}

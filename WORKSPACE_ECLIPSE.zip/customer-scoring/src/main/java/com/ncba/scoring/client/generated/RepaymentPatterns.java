
package com.ncba.scoring.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for repaymentPatterns complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="repaymentPatterns"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="worstDaysArrearsEver" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="worstDaysArrearsLast12Months" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="worstDaysArrearsLast3Months" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="worstDaysArrearsLast6Months" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "repaymentPatterns", propOrder = {
    "worstDaysArrearsEver",
    "worstDaysArrearsLast12Months",
    "worstDaysArrearsLast3Months",
    "worstDaysArrearsLast6Months"
})
public class RepaymentPatterns {

    protected Integer worstDaysArrearsEver;
    protected Integer worstDaysArrearsLast12Months;
    protected Integer worstDaysArrearsLast3Months;
    protected Integer worstDaysArrearsLast6Months;

    /**
     * Gets the value of the worstDaysArrearsEver property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWorstDaysArrearsEver() {
        return worstDaysArrearsEver;
    }

    /**
     * Sets the value of the worstDaysArrearsEver property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWorstDaysArrearsEver(Integer value) {
        this.worstDaysArrearsEver = value;
    }

    /**
     * Gets the value of the worstDaysArrearsLast12Months property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWorstDaysArrearsLast12Months() {
        return worstDaysArrearsLast12Months;
    }

    /**
     * Sets the value of the worstDaysArrearsLast12Months property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWorstDaysArrearsLast12Months(Integer value) {
        this.worstDaysArrearsLast12Months = value;
    }

    /**
     * Gets the value of the worstDaysArrearsLast3Months property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWorstDaysArrearsLast3Months() {
        return worstDaysArrearsLast3Months;
    }

    /**
     * Sets the value of the worstDaysArrearsLast3Months property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWorstDaysArrearsLast3Months(Integer value) {
        this.worstDaysArrearsLast3Months = value;
    }

    /**
     * Gets the value of the worstDaysArrearsLast6Months property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWorstDaysArrearsLast6Months() {
        return worstDaysArrearsLast6Months;
    }

    /**
     * Sets the value of the worstDaysArrearsLast6Months property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWorstDaysArrearsLast6Months(Integer value) {
        this.worstDaysArrearsLast6Months = value;
    }

}

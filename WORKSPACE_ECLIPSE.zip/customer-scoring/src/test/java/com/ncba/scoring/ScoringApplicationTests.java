package com.ncba.scoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScoringApplicationTests {

	@Test
	void contextLoads() {
	}

}

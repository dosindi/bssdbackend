package com.ncba.scoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScoringApplication.class, args);
	}

}

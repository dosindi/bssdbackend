/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.controller;

import com.ncba.scoring.response.CRBResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ncba.scoring.model.CustomerLimits;
import com.ncba.scoring.model.CustomerLimits;
import com.ncba.scoring.model.CustomerLimitsRepository;
import com.ncba.scoring.request.CRBRequest;
import com.ncba.scoring.request.ClientRequest;
import com.ncba.scoring.request.ClientScoreRequest;
import com.ncba.scoring.request.IBPSRequest;
import com.ncba.scoring.request.MockEngineRequest;
import com.ncba.scoring.response.MockResponse;
import com.ncba.scoring.response.T24DataMartResponse;
import io.swagger.annotations.Api;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.validation.Valid;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Duncan.Nyakundi
 */
@RestController
@RequestMapping("api/v1/")
@Api(value = "Customer Scoring - IBPS", description = "Operations pertaining customer scoring")
public class IBPSController {

    public static org.slf4j.Logger log = LoggerFactory.getLogger(IBPSController.class);

    @Autowired
    private Utilz utilz;

    @Value("${t24datamart.url}")
    private String t24datamartUrl;

    @Value("${t24datamart.endpoint}")
    private String t24datamartEndpoint;

    @Value("${crb.request.endpoint}")
    private String crb2Endpoint;

    @Value("${score_engine.endpoint}")
    private String scoreEngineEndpoint;

    @Autowired
    private CustomerLimitsRepository repo;

    /*
     @Description: Query by Customer No, ID Number, tenor and customer type
     */
    @PostMapping("ibps-request")
    public ResponseEntity<Object> ibpsrequest(@RequestBody @Valid ClientScoreRequest ibpsRequest) {

        String result = ibpsRequest.getIdentification_no();
        IBPSRequest request = new IBPSRequest();
        request.setNationalId(result);
        log.info(result);
        String t24martEndpoint = t24datamartUrl + t24datamartEndpoint;
        String crbEndpoint = t24datamartUrl + crb2Endpoint;
//        ObjectMapper om = new ObjectMapper();
//        try {
//            //convert ibpsrequest to json
//            result = om.writeValueAsString(request);
//            log.info("write: " + result);
//            result = utilz.callHttp(result, t24martEndpoint);
//
////Convert t24datamart to pojo
//            T24DataMartResponse martResponse = om.readValue(result, T24DataMartResponse.class);
//
//            CRBRequest request1 = new CRBRequest();
//            request1.setName1(martResponse.getCustomerName().split(" ")[0]);
//            request1.setName2(martResponse.getCustomerName().split(" ")[1]);
//            request1.setNationalID(martResponse.getNationalId());
//
//            //TODO invoke Transunion
//            result = om.writeValueAsString(request1);
//            log.info("json request for CRB:" + result);
//            result = utilz.callHttp(result, crbEndpoint);
//            log.info("response from CRB:" + result);
//        } catch (IOException ex) {
//            log.info(ex.toString());
//            return ResponseEntity.badRequest().body("Error occured: " + ex);
//        }
//        return new ResponseEntity(result, HttpStatus.OK); TODO  final
//mock
        MockResponse mock = new MockResponse();
        result = mock.toString();
        return new ResponseEntity(result, HttpStatus.OK);
    }

    /*
    @Description: Limit assignment: Query by CustomerNo from DB 
     */
    @PostMapping("limits-request")
    public ResponseEntity<Object> limitAssigment(@RequestBody ClientRequest customerNoRequest) {

        CustomerLimits entity = repo.findByCustomerNumber(customerNoRequest.getCustomerno());

        if (entity == null) {
            return new ResponseEntity(customerNoRequest.getCustomerno() + " Record not found", HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity(entity.toString(), HttpStatus.OK);

    }

    /*
        @Description: Query Scorecard Engine
     */
    @PostMapping("score-engine")
    public ResponseEntity<Object> postScoreEngine(@RequestBody MockEngineRequest request) {
        
        String result = "something...";
        String input = utilz.approved(request.getModelType());
        try {
            
            input =String.format(input,"FEMALE","Approved");
            log.info("format: "+input);
            result = utilz.callHttp(input, scoreEngineEndpoint);
        } catch (IOException ex) {
            log.error(ex.toString());
            return new ResponseEntity(result, HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity(result, HttpStatus.OK);
    }
}

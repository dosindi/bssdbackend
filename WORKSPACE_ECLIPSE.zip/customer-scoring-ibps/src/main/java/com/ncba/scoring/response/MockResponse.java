/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Duncan.Nyakundi
 */
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class MockResponse {

    private String CustomerNumber;
    private String CustomerDocumentType;
    private String CustomerDocumentNumber;
    private String CustomerName;
    private String Tenor;
    private String ProxyIncome;
    private String IntermediationCost;
    private String ReturnOnCapital;
    private String PeriodsPerYear;
    private String CURRENTBALANCEAMOUNT;
    private String DRTURNOVER;
    private String TOTALASSETS;
    private String MOBILE_TOTAL;
    private String PASTDUEAMOUNT;
    private String MAXARREARS;
    private String CURRENTINARREARS;
    private String NONPERFORMING;
    private String GENDER;
    private String BAND6MSAVACCTDEPCNT;
    private String AGE;
    private String TENURE_OF_RELATIONSHIP_WITH_BANK;
    private String EMPLOYER_STRENGTH;
    private String RiskGrade;
    private String MonthlyRepayment;
    private String TenorRate;
    private String LoanAmount;
    private String RiskPremium;
    private String IncomeBand;
    private String custExcludedBy;
    private String NEXTPMML;
    private String MonthlyRate;
    private String CustomerScore;
    private String CustomerInterestRate;

    @Override
    public String toString() {

        RiskGrade = "A2";
        MonthlyRepayment = "384000";
        TenorRate = "7.35";
        LoanAmount = "6000000";
        RiskPremium = "3.2";
        IncomeBand = "I7";
        custExcludedBy = "NOT_EXCLUDED";
        CustomerNumber = null;
        NEXTPMML = "NA";
        MonthlyRate = "0.014716667";
        CustomerScore = "82";
        CustomerInterestRate = "17.66";

        return "{\"CustomerNumber\" :\"" + CustomerNumber
//                + "\", \"CustomerDocumentType\" :\"" + CustomerDocumentType
//                + "\", \"CustomerDocumentNumber\":\"" + CustomerDocumentNumber
//                + "\", \"CustomerName\":\"" + CustomerName
//                + "\", \"Tenor\":\"" + Tenor
//                + "\", \"ProxyIncome\":\"" + ProxyIncome
//                + "\", \"IntermediationCost\":\"" + IntermediationCost
//                + "\", \"ReturnOnCapital\":\"" + ReturnOnCapital
//                + "\", \"PeriodsPerYear\":\"" + PeriodsPerYear
//                + "\", \"CURRENTBALANCEAMOUNT\":\"" + CURRENTBALANCEAMOUNT
//                + "\", \"DRTURNOVER\":\"" + DRTURNOVER
//                + "\", \"TOTALASSETS\":\"" + TOTALASSETS
//                + "\", \"MOBILE_TOTAL\":\"" + MOBILE_TOTAL
//                + "\", \"PASTDUEAMOUNT\":\"" + PASTDUEAMOUNT
//                + "\", \"MAXARREARS\":\"" + MAXARREARS
//                + "\", \"CURRENTINARREARS\":\"" + CURRENTINARREARS
//                + "\", \"NONPERFORMING\":\"" + NONPERFORMING
//                + "\", \"GENDER\":\"" + GENDER
//                + "\", \"BAND6MSAVACCTDEPCNT\":\"" + BAND6MSAVACCTDEPCNT
//                + "\", \"AGE\":\"" + AGE
//                + "\", \"TENURE_OF_RELATIONSHIP_WITH_BANK\":\"" + TENURE_OF_RELATIONSHIP_WITH_BANK
//                + "\", \"EMPLOYER_STRENGTH\":\"" + EMPLOYER_STRENGTH
                + "\", \"RiskGrade\":\"" + RiskGrade
                + "\", \"MonthlyRepayment\":\"" + MonthlyRepayment
                + "\", \"TenorRate\":\"" + TenorRate
                + "\", \"LoanAmount\":\"" + LoanAmount
                + "\", \"RiskPremium\":\"" + RiskPremium
                + "\", \"IncomeBand\":\"" + IncomeBand
                + "\", \"custExcludedBy\":\"" + custExcludedBy
                + "\", \"NEXTPMML\":\"" + NEXTPMML
                + "\", \"MonthlyRate\":\"" + MonthlyRate
                + "\", \"CustomerScore\":\"" + CustomerScore
                + "\", \"CustomerInterestRate\":\"" + CustomerInterestRate + "\"}";
    }

}

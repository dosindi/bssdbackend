/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.response;

/**
 *
 * @author Duncan.Nyakundi
 */

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"custDate",
"customerNumber",
"customerName",
"drturnover",
"savacctdepcnt",
"totalassets",
"age",
"gender",
"tenurerel",
"empstrength",
"nationalId",
"serviceNo",
"passportNo",
"alienId",
"companyReg",
"custLoanDate",
"reportDate",
"extractionDate",
"custLoanCount",
"custLoanProds1",
"custLoanProds2",
"custLoanProds3",
"custLoanProds4",
"custLoanProds5",
"custLoanProds6",
"custLoanProds7",
"custLoanProds8",
"recid"
})
@Data
public class T24DataMartResponse {
    


@JsonProperty("custDate")
private String custDate;
@JsonProperty("customerNumber")
private String customerNumber;
@JsonProperty("customerName")
private String customerName;
@JsonProperty("drturnover")
private String drturnover;
@JsonProperty("savacctdepcnt")
private String savacctdepcnt;
@JsonProperty("totalassets")
private String totalassets;
@JsonProperty("age")
private String age;
@JsonProperty("gender")
private String gender;
@JsonProperty("tenurerel")
private String tenurerel;
@JsonProperty("empstrength")
private String empstrength;
@JsonProperty("nationalId")
private String nationalId;
@JsonProperty("serviceNo")
private String serviceNo;
@JsonProperty("passportNo")
private String passportNo;
@JsonProperty("alienId")
private String alienId;
@JsonProperty("companyReg")
private String companyReg;
@JsonProperty("custLoanDate")
private String custLoanDate;
@JsonProperty("reportDate")
private String reportDate;
@JsonProperty("extractionDate")
private String extractionDate;
@JsonProperty("custLoanCount")
private String custLoanCount;
@JsonProperty("custLoanProds1")
private String custLoanProds1;
@JsonProperty("custLoanProds2")
private String custLoanProds2;
@JsonProperty("custLoanProds3")
private String custLoanProds3;
@JsonProperty("custLoanProds4")
private String custLoanProds4;
@JsonProperty("custLoanProds5")
private String custLoanProds5;
@JsonProperty("custLoanProds6")
private String custLoanProds6;
@JsonProperty("custLoanProds7")
private String custLoanProds7;
@JsonProperty("custLoanProds8")
private String custLoanProds8;
@JsonProperty("recid")
private String recid;

}



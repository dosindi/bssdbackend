/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring;

/**
 *
 * @author Duncan.Nyakundi
 */

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "entityManagerFactory",
        basePackages = {"com.ncba.scoring.model"})
public class DBConfig {

    @Value("${spring.datasource.jdbc-url}")
    private String url;
    @Value("${spring.datasource.driverClassName}")
    private String driver;
    @Value("${spring.datasource.username}")
    private String username;
    @Value("${spring.datasource.password}")
    private String password;
    
//    @Autowired
//    private Utilz utils;

    @Primary
    @Bean(name = "entityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(
            EntityManagerFactoryBuilder builder, @Qualifier("dataSource") DataSource dataSource) {
        return builder.dataSource(dataSource).packages("com.ncba.scoring.model").persistenceUnit("datamartPU1")
                .build();
    }

    @Primary
    @Bean(name = "transactionManager")
    public PlatformTransactionManager transactionManager(
            @Qualifier("entityManagerFactory") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    @Primary
    @Bean(name = "dataSource")
    public DataSource dataSource() {
        HikariConfig config = new HikariConfig();
        config.setMaximumPoolSize(100);

//        utils.enableProxy();
        
        try {
//            config.setDriverClassName(AESencrp.decrypt(driver));
//            config.setJdbcUrl(AESencrp.decrypt(url));
//            config.addDataSourceProperty("user", AESencrp.decrypt(username));
//            config.addDataSourceProperty("password", AESencrp.decrypt(password));
            config.setDriverClassName(driver);
            config.setJdbcUrl(url);
            config.addDataSourceProperty("user", username);
            config.addDataSourceProperty("password", password);
        } catch (Exception ex) {
            System.out.println("Exception HCP===>" + ex.toString());
        }
        //        config.setDriverClassName("com.mysql.jdbc.Driver");
//        config.setJdbcUrl("jdbc:mysql://10.4.115.181:3306/interfaces_schema?zeroDateTimeBehavior=convertToNull&verifyServerCertificate=false&useSSL=false&requireSSL=false");
//        config.addDataSourceProperty("user", "root");
//        config.addDataSourceProperty("password", "password");
        config.setConnectionTimeout(20000);
        config.setMinimumIdle(5);
        config.setMaximumPoolSize(12);
        config.setIdleTimeout(300000);
        config.setMaxLifetime(12000000);
        config.setAutoCommit(true);
        config.setLeakDetectionThreshold(60*100);
        
        return new HikariDataSource(config);

    }
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.controller;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Level;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Component;

/**
 *
 * @author Duncan.Nyakundi
 */
@Component
public class Utilz {

    public static Logger log = LoggerFactory.getLogger(Utilz.class);

    public String toXmlString(Class cl, Object ob) {

        JAXBContext context;
        StringWriter sw = new StringWriter();
        try {
            context = JAXBContext.newInstance(cl);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(ob, sw);
        } catch (JAXBException ex) {
            log.info(ex.getMessage());
        }

        return sw.toString();
    }

    /*
       POST reusable
     */
    public String callHttp(String input, String url) throws IOException {

        String result = null;

        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");

//        con.setRequestProperty("Content-Type", "application/json; charset=\"utf-8\"");
//        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
        con.setRequestProperty("Accept", "text/xml");
        con.setConnectTimeout(60000);
        con.setReadTimeout(60000);
        con.setDoOutput(true);
        try (OutputStream os = con.getOutputStream()) {
            os.write(input.getBytes());
            os.flush();
        }
        int responseCode = con.getResponseCode();
        log.info("Response Code :: " + responseCode);
        if (responseCode == HttpURLConnection.HTTP_OK) {
            StringBuilder response;
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                response = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
            }
            result = response.toString();
            log.info("Response from T24 Datamart url: " + response.toString());

        } else {
            StringBuilder response;
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getErrorStream()))) {
                String inputLine;
                response = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
            }

            log.info("Response from from T24 Datamart url: " + response.toString());

            result = response.toString();
            log.error("Error Response :: " + response.toString());

        }

        return result;
    }

    public String approved(String modelType) {
        String result = "something...";
        FileInputStream fis = null;
        try {
            fis = new FileInputStream("src\\main\\resources\\"+modelType+"_temp.txt");
            result = IOUtils.toString(fis, "UTF-8");
//            log.info("result : " + result);
        } catch (FileNotFoundException e) {
            result = e.toString();
            log.error("FileNotFoundException: " + result);
        } catch (IOException ex) {
            result = ex.toString();
            log.error("IOException: " + result);
        }

        return result;
    }

}

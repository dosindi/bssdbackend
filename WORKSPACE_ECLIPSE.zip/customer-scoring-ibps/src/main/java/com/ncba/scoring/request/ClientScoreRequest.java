/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.constraints.NotEmpty;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Duncan.Nyakundi
 */
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientScoreRequest {

    @NotEmpty(message = "{constraints.NotEmpty.message}")
    private String customerno;

    @NotEmpty(message = "{constraints.NotEmpty.message}")
    private String identification_no;

    @NotEmpty(message = "{constraints.NotEmpty.message}")
    private String tenor;

    @NotEmpty(message = "{constraints.NotEmpty.message}")
    public String type ;

    @Override
    public String toString() {
        return "{customerno:" + customerno + ","
                + "identification_no:" + identification_no + ","   
                + "type:" + type + ","
                + "tenor:" + tenor + "}";
    }
}

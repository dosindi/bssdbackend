/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.scoring.model;

/**
 *
 * @author Duncan.Nyakundi
 */

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "Customer_Limits")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustomerLimits.findAll", query = "SELECT c FROM CustomerLimits c")
    , @NamedQuery(name = "CustomerLimits.findByCustomerNumber", query = "SELECT c FROM CustomerLimits c WHERE c.customerNumber = :customerNumber")
    , @NamedQuery(name = "CustomerLimits.findByCustomerDocumentType", query = "SELECT c FROM CustomerLimits c WHERE c.customerDocumentType = :customerDocumentType")
    , @NamedQuery(name = "CustomerLimits.findByCustomerDocumentNumber", query = "SELECT c FROM CustomerLimits c WHERE c.customerDocumentNumber = :customerDocumentNumber")
    , @NamedQuery(name = "CustomerLimits.findByCustomerName", query = "SELECT c FROM CustomerLimits c WHERE c.customerName = :customerName")
    , @NamedQuery(name = "CustomerLimits.findByTenor", query = "SELECT c FROM CustomerLimits c WHERE c.tenor = :tenor")
    , @NamedQuery(name = "CustomerLimits.findByProxyIncome", query = "SELECT c FROM CustomerLimits c WHERE c.proxyIncome = :proxyIncome")
    , @NamedQuery(name = "CustomerLimits.findByIntermediationCost", query = "SELECT c FROM CustomerLimits c WHERE c.intermediationCost = :intermediationCost")
    , @NamedQuery(name = "CustomerLimits.findByReturnOnCapital", query = "SELECT c FROM CustomerLimits c WHERE c.returnOnCapital = :returnOnCapital")
    , @NamedQuery(name = "CustomerLimits.findByPeriodsPerYear", query = "SELECT c FROM CustomerLimits c WHERE c.periodsPerYear = :periodsPerYear")
    , @NamedQuery(name = "CustomerLimits.findByCurrentbalanceamount", query = "SELECT c FROM CustomerLimits c WHERE c.currentbalanceamount = :currentbalanceamount")
    , @NamedQuery(name = "CustomerLimits.findByDrturnover", query = "SELECT c FROM CustomerLimits c WHERE c.drturnover = :drturnover")
    , @NamedQuery(name = "CustomerLimits.findByTotalassets", query = "SELECT c FROM CustomerLimits c WHERE c.totalassets = :totalassets")
    , @NamedQuery(name = "CustomerLimits.findByMobileTotal", query = "SELECT c FROM CustomerLimits c WHERE c.mobileTotal = :mobileTotal")
    , @NamedQuery(name = "CustomerLimits.findByPastdueamount", query = "SELECT c FROM CustomerLimits c WHERE c.pastdueamount = :pastdueamount")
    , @NamedQuery(name = "CustomerLimits.findByMaxarrears", query = "SELECT c FROM CustomerLimits c WHERE c.maxarrears = :maxarrears")
    , @NamedQuery(name = "CustomerLimits.findByCurrentinarrears", query = "SELECT c FROM CustomerLimits c WHERE c.currentinarrears = :currentinarrears")
    , @NamedQuery(name = "CustomerLimits.findByNonperforming", query = "SELECT c FROM CustomerLimits c WHERE c.nonperforming = :nonperforming")
    , @NamedQuery(name = "CustomerLimits.findByGender", query = "SELECT c FROM CustomerLimits c WHERE c.gender = :gender")
    , @NamedQuery(name = "CustomerLimits.findByBand6msavacctdepcnt", query = "SELECT c FROM CustomerLimits c WHERE c.band6msavacctdepcnt = :band6msavacctdepcnt")
    , @NamedQuery(name = "CustomerLimits.findByAge", query = "SELECT c FROM CustomerLimits c WHERE c.age = :age")
    , @NamedQuery(name = "CustomerLimits.findByTenureOfRelationshipWithBank", query = "SELECT c FROM CustomerLimits c WHERE c.tenureOfRelationshipWithBank = :tenureOfRelationshipWithBank")
    , @NamedQuery(name = "CustomerLimits.findByEmployerStrength", query = "SELECT c FROM CustomerLimits c WHERE c.employerStrength = :employerStrength")
    , @NamedQuery(name = "CustomerLimits.findByRiskGrade", query = "SELECT c FROM CustomerLimits c WHERE c.riskGrade = :riskGrade")
    , @NamedQuery(name = "CustomerLimits.findByMonthlyRepayment", query = "SELECT c FROM CustomerLimits c WHERE c.monthlyRepayment = :monthlyRepayment")
    , @NamedQuery(name = "CustomerLimits.findByTenorRate", query = "SELECT c FROM CustomerLimits c WHERE c.tenorRate = :tenorRate")
    , @NamedQuery(name = "CustomerLimits.findByLoanAmount", query = "SELECT c FROM CustomerLimits c WHERE c.loanAmount = :loanAmount")
    , @NamedQuery(name = "CustomerLimits.findByRiskPremium", query = "SELECT c FROM CustomerLimits c WHERE c.riskPremium = :riskPremium")
    , @NamedQuery(name = "CustomerLimits.findByIncomeBand", query = "SELECT c FROM CustomerLimits c WHERE c.incomeBand = :incomeBand")
    , @NamedQuery(name = "CustomerLimits.findByCustExcludedBy", query = "SELECT c FROM CustomerLimits c WHERE c.custExcludedBy = :custExcludedBy")
    , @NamedQuery(name = "CustomerLimits.findByCustomerNumber2", query = "SELECT c FROM CustomerLimits c WHERE c.customerNumber2 = :customerNumber2")
    , @NamedQuery(name = "CustomerLimits.findByNextpmml", query = "SELECT c FROM CustomerLimits c WHERE c.nextpmml = :nextpmml")
    , @NamedQuery(name = "CustomerLimits.findByMonthlyRate", query = "SELECT c FROM CustomerLimits c WHERE c.monthlyRate = :monthlyRate")
    , @NamedQuery(name = "CustomerLimits.findByCustomerScore", query = "SELECT c FROM CustomerLimits c WHERE c.customerScore = :customerScore")
    , @NamedQuery(name = "CustomerLimits.findByCustomerInterestRate", query = "SELECT c FROM CustomerLimits c WHERE c.customerInterestRate = :customerInterestRate")
    , @NamedQuery(name = "CustomerLimits.findBySalarycheck", query = "SELECT c FROM CustomerLimits c WHERE c.salarycheck = :salarycheck")})
public class CustomerLimits implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CustomerNumber")
    private Integer customerNumber;
    @Column(name = "CustomerDocumentType")
    private String customerDocumentType;
    @Column(name = "CustomerDocumentNumber")
    private Integer customerDocumentNumber;
    @Basic(optional = false)
    @Column(name = "CustomerName")
    private String customerName;
    @Basic(optional = false)
    @Column(name = "Tenor")
    private int tenor;
    @Basic(optional = false)
    @Column(name = "ProxyIncome")
    private double proxyIncome;
    @Basic(optional = false)
    @Column(name = "IntermediationCost")
    private double intermediationCost;
    @Basic(optional = false)
    @Column(name = "ReturnOnCapital")
    private double returnOnCapital;
    @Basic(optional = false)
    @Column(name = "PeriodsPerYear")
    private int periodsPerYear;
    @Column(name = "CURRENTBALANCEAMOUNT")
    private String currentbalanceamount;
    @Basic(optional = false)
    @Column(name = "DRTURNOVER")
    private String drturnover;
    @Column(name = "TOTALASSETS")
    private String totalassets;
    @Column(name = "MOBILE_TOTAL")
    private String mobileTotal;
    @Column(name = "PASTDUEAMOUNT")
    private String pastdueamount;
    @Column(name = "MAXARREARS")
    private String maxarrears;
    @Column(name = "CURRENTINARREARS")
    private String currentinarrears;
    @Column(name = "NONPERFORMING")
    private String nonperforming;
    @Column(name = "GENDER")
    private String gender;
    @Basic(optional = false)
    @Column(name = "BAND6MSAVACCTDEPCNT")
    private String band6msavacctdepcnt;
    @Column(name = "AGE")
    private Integer age;
    @Basic(optional = false)
    @Column(name = "TENURE_OF_RELATIONSHIP_WITH_BANK")
    private int tenureOfRelationshipWithBank;
    @Basic(optional = false)
    @Column(name = "EMPLOYER_STRENGTH")
    private String employerStrength;
    @Basic(optional = false)
    @Column(name = "RiskGrade")
    private String riskGrade;
    @Basic(optional = false)
    @Column(name = "MonthlyRepayment")
    private double monthlyRepayment;
    @Basic(optional = false)
    @Column(name = "TenorRate")
    private double tenorRate;
    @Basic(optional = false)
    @Column(name = "LoanAmount")
    private double loanAmount;
    @Basic(optional = false)
    @Column(name = "RiskPremium")
    private double riskPremium;
    @Basic(optional = false)
    @Column(name = "IncomeBand")
    private String incomeBand;
    @Basic(optional = false)
    @Column(name = "custExcludedBy")
    private String custExcludedBy;
    @Basic(optional = false)
    @Column(name = "CustomerNumber2")
    private int customerNumber2;
    @Basic(optional = false)
    @Column(name = "NEXTPMML")
    private String nextpmml;
    @Basic(optional = false)
    @Column(name = "MonthlyRate")
    private double monthlyRate;
    @Basic(optional = false)
    @Column(name = "CustomerScore")
    private int customerScore;
    @Basic(optional = false)
    @Column(name = "CustomerInterestRate")
    private double customerInterestRate;
    @Basic(optional = false)
    @Column(name = "Salary_check")
    private String salarycheck;

    public CustomerLimits() {
    }

    public CustomerLimits(Integer customerNumber) {
        this.customerNumber = customerNumber;
    }

    public CustomerLimits(Integer customerNumber, String customerName, int tenor, double proxyIncome, double intermediationCost, double returnOnCapital, int periodsPerYear, String drturnover, String band6msavacctdepcnt, int tenureOfRelationshipWithBank, String employerStrength, String riskGrade, double monthlyRepayment, double tenorRate, double loanAmount, double riskPremium, String incomeBand, String custExcludedBy, int customerNumber2, String nextpmml, double monthlyRate, int customerScore, double customerInterestRate, String salarycheck) {
        this.customerNumber = customerNumber;
        this.customerName = customerName;
        this.tenor = tenor;
        this.proxyIncome = proxyIncome;
        this.intermediationCost = intermediationCost;
        this.returnOnCapital = returnOnCapital;
        this.periodsPerYear = periodsPerYear;
        this.drturnover = drturnover;
        this.band6msavacctdepcnt = band6msavacctdepcnt;
        this.tenureOfRelationshipWithBank = tenureOfRelationshipWithBank;
        this.employerStrength = employerStrength;
        this.riskGrade = riskGrade;
        this.monthlyRepayment = monthlyRepayment;
        this.tenorRate = tenorRate;
        this.loanAmount = loanAmount;
        this.riskPremium = riskPremium;
        this.incomeBand = incomeBand;
        this.custExcludedBy = custExcludedBy;
        this.customerNumber2 = customerNumber2;
        this.nextpmml = nextpmml;
        this.monthlyRate = monthlyRate;
        this.customerScore = customerScore;
        this.customerInterestRate = customerInterestRate;
        this.salarycheck = salarycheck;
    }

    public Integer getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(Integer customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getCustomerDocumentType() {
        return customerDocumentType;
    }

    public void setCustomerDocumentType(String customerDocumentType) {
        this.customerDocumentType = customerDocumentType;
    }

    public Integer getCustomerDocumentNumber() {
        return customerDocumentNumber;
    }

    public void setCustomerDocumentNumber(Integer customerDocumentNumber) {
        this.customerDocumentNumber = customerDocumentNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getTenor() {
        return tenor;
    }

    public void setTenor(int tenor) {
        this.tenor = tenor;
    }

    public double getProxyIncome() {
        return proxyIncome;
    }

    public void setProxyIncome(double proxyIncome) {
        this.proxyIncome = proxyIncome;
    }

    public double getIntermediationCost() {
        return intermediationCost;
    }

    public void setIntermediationCost(double intermediationCost) {
        this.intermediationCost = intermediationCost;
    }

    public double getReturnOnCapital() {
        return returnOnCapital;
    }

    public void setReturnOnCapital(double returnOnCapital) {
        this.returnOnCapital = returnOnCapital;
    }

    public int getPeriodsPerYear() {
        return periodsPerYear;
    }

    public void setPeriodsPerYear(int periodsPerYear) {
        this.periodsPerYear = periodsPerYear;
    }

    public String getCurrentbalanceamount() {
        return currentbalanceamount;
    }

    public void setCurrentbalanceamount(String currentbalanceamount) {
        this.currentbalanceamount = currentbalanceamount;
    }

    public String getDrturnover() {
        return drturnover;
    }

    public void setDrturnover(String drturnover) {
        this.drturnover = drturnover;
    }

    public String getTotalassets() {
        return totalassets;
    }

    public void setTotalassets(String totalassets) {
        this.totalassets = totalassets;
    }

    public String getMobileTotal() {
        return mobileTotal;
    }

    public void setMobileTotal(String mobileTotal) {
        this.mobileTotal = mobileTotal;
    }

    public String getPastdueamount() {
        return pastdueamount;
    }

    public void setPastdueamount(String pastdueamount) {
        this.pastdueamount = pastdueamount;
    }

    public String getMaxarrears() {
        return maxarrears;
    }

    public void setMaxarrears(String maxarrears) {
        this.maxarrears = maxarrears;
    }

    public String getCurrentinarrears() {
        return currentinarrears;
    }

    public void setCurrentinarrears(String currentinarrears) {
        this.currentinarrears = currentinarrears;
    }

    public String getNonperforming() {
        return nonperforming;
    }

    public void setNonperforming(String nonperforming) {
        this.nonperforming = nonperforming;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBand6msavacctdepcnt() {
        return band6msavacctdepcnt;
    }

    public void setBand6msavacctdepcnt(String band6msavacctdepcnt) {
        this.band6msavacctdepcnt = band6msavacctdepcnt;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public int getTenureOfRelationshipWithBank() {
        return tenureOfRelationshipWithBank;
    }

    public void setTenureOfRelationshipWithBank(int tenureOfRelationshipWithBank) {
        this.tenureOfRelationshipWithBank = tenureOfRelationshipWithBank;
    }

    public String getEmployerStrength() {
        return employerStrength;
    }

    public void setEmployerStrength(String employerStrength) {
        this.employerStrength = employerStrength;
    }

    public String getRiskGrade() {
        return riskGrade;
    }

    public void setRiskGrade(String riskGrade) {
        this.riskGrade = riskGrade;
    }

    public double getMonthlyRepayment() {
        return monthlyRepayment;
    }

    public void setMonthlyRepayment(double monthlyRepayment) {
        this.monthlyRepayment = monthlyRepayment;
    }

    public double getTenorRate() {
        return tenorRate;
    }

    public void setTenorRate(double tenorRate) {
        this.tenorRate = tenorRate;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public double getRiskPremium() {
        return riskPremium;
    }

    public void setRiskPremium(double riskPremium) {
        this.riskPremium = riskPremium;
    }

    public String getIncomeBand() {
        return incomeBand;
    }

    public void setIncomeBand(String incomeBand) {
        this.incomeBand = incomeBand;
    }

    public String getCustExcludedBy() {
        return custExcludedBy;
    }

    public void setCustExcludedBy(String custExcludedBy) {
        this.custExcludedBy = custExcludedBy;
    }

    public int getCustomerNumber2() {
        return customerNumber2;
    }

    public void setCustomerNumber2(int customerNumber2) {
        this.customerNumber2 = customerNumber2;
    }

    public String getNextpmml() {
        return nextpmml;
    }

    public void setNextpmml(String nextpmml) {
        this.nextpmml = nextpmml;
    }

    public double getMonthlyRate() {
        return monthlyRate;
    }

    public void setMonthlyRate(double monthlyRate) {
        this.monthlyRate = monthlyRate;
    }

    public int getCustomerScore() {
        return customerScore;
    }

    public void setCustomerScore(int customerScore) {
        this.customerScore = customerScore;
    }

    public double getCustomerInterestRate() {
        return customerInterestRate;
    }

    public void setCustomerInterestRate(double customerInterestRate) {
        this.customerInterestRate = customerInterestRate;
    }

    public String getSalarycheck() {
        return salarycheck;
    }

    public void setSalarycheck(String salarycheck) {
        this.salarycheck = salarycheck;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerNumber != null ? customerNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustomerLimits)) {
            return false;
        }
        CustomerLimits other = (CustomerLimits) object;
        if ((this.customerNumber == null && other.customerNumber != null) || (this.customerNumber != null && !this.customerNumber.equals(other.customerNumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
          return "{"
                + "\"customerNumber\":\"" + getCustomerNumber()+"\"," 
                + "\"customerDocumentType\":\"" + getCustomerDocumentType()+"\"," 
                + "\"customerDocumentNumber\":\"" + getCustomerDocumentNumber()+"\"," 
                + "\"customerName\":\"" + getCustomerName()+"\"," 
                + "\"tenor\":\"" + getTenor()+"\"," 
                + "\"proxyIncome\":\"" + getProxyIncome()+"\"," 
                + "\"intermediationCost\":\"" + getIntermediationCost()+"\"," 
                + "\"returnOnCapital\":\"" + getReturnOnCapital()+"\"," 
                + "\"periodsPerYear\":\"" + getPeriodsPerYear()+"\"," 
                + "\"currentbalanceamount\":\"" + getCurrentbalanceamount()+"\"," 
                + "\"drturnover\":\"" + getDrturnover()+"\"," 
                + "\"totalassets\":\"" + getTotalassets()+"\"," 
                + "\"mobileTotal\":\"" + getMobileTotal()+"\"," 
                + "\"pastdueamount\":\"" + getPastdueamount()+"\"," 
                + "\"maxarrears\":\"" + getMaxarrears()+"\"," 
                + "\"currentinarrears\":\"" + getCurrentinarrears()+"\"," 
                + "\"nonperforming\":\"" + getNonperforming()+"\"," 
                + "\"gender\":\"" + getGender()+"\"," 
                + "\"band6msavacctdepcnt\":\"" + getBand6msavacctdepcnt()+"\"," 
                + "\"age\":\"" + getAge()+"\"," 
                + "\"tenureOfRelationshipWithBank\":\"" + getTenureOfRelationshipWithBank()+"\"," 
                + "\"employerStrength\":\"" + getEmployerStrength()+"\"," 
                + "\"riskGrade\":\"" + getRiskGrade()+"\"," 
                + "\"monthlyRepayment\":\"" + getMonthlyRepayment()+"\"," 
                + "\"tenorRate\":\"" + getTenorRate()+"\"," 
                + "\"loanAmount\":\"" + getLoanAmount()+"\"," 
                + "\"riskPremium\":\"" + getRiskPremium()+"\"," 
                + "\"incomeBand\":\"" + getIncomeBand()+"\"," 
                + "\"custExcludedBy\":\"" + getCustExcludedBy()+"\"," 
                + "\"customerNumber2\":\"" + getCustomerNumber2()+"\"," 
                + "\"nextpmml\":\"" + getNextpmml()+"\"," 
                + "\"monthlyRate\":\"" + getMonthlyRate()+"\"," 
                + "\"customerScore\":\"" + getCustomerScore()+"\"," 
                + "\"customerInterestRate\":\"" + getCustomerInterestRate()+"\"," 
                + "\"salarycheck\":\"" + getSalarycheck()+"" 
            + "}";
    
    }
    
}


# Customer scoring client service

http://10.4.115.201:8081/scoring/swagger-ui.html




/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.leasing.controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.logging.Level;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.namespace.QName;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
  * @author Duncan.Nyakundi 
 * TODO
 */
@Service
public class MainService {

    public static Logger log = Logger.getLogger(MainService.class.getName());

    @Value("${T24.server.port}")
    public int port;

    @Value("${T24.server.ip}")
    public String host;

    Socket socket = null;
    String fields = "";
    String message = "";
    String function = "";
    String recordId = "";
    String application = "";

    byte[] bytes = null;

    @Value("${leasing.endpoint}")
    public String endpoint;

    @Value("${leasing.apikey}")
    public String apikey;

    @Value("${leasing.privatekey}")
    public String privatekey;

    public String mainPoll(String message) {

        bytes = LazyOFS(message); // executes ofs string

        long startTime = System.nanoTime();

        String resp = processOFS(bytes);

        long estimatedTime = System.nanoTime() - startTime;

        log.info("Lapse Time: " + (estimatedTime / 1000000) + " ms");

        return resp;
    }

    private byte[] LazyOFS(String message) {

        byte[] bytes = null;

//        message = "ENQUIRY.SELECT,,UPGRADE.1/Kenya123,CBA.COLLECTIONS.REQUEST";
//        message = "H.CBA.COLL.RESP,INPUT/I/PROCESS,ICON.COLL.USER/Kenya123/UG0010001,NSSF9228786605,RESULT::=INVALID,REMARKS::=307 Incorrect signature.,ICON.STATUS::=PROCESSED,COLL.TYPE::=NSSF";
//        System.out.println(host + ":" + port + " - " + message);
        message = "ENQUIRY.SELECT,,icon.inst.issue/Rwanda123!/RW0011001,CBA.PRIME.XML,ICON.STATUS:EQ=QUEUED";
        bytes = message.getBytes();

        return bytes;
    }

    private String processOFS(byte[] bytes) {
        socket = new Socket();
        DataInputStream dIn = null;
        DataOutputStream dOut = null;

        try {
            socket.connect(new InetSocketAddress(host, port), 1000000);

            dOut = new DataOutputStream(socket.getOutputStream());
            dIn = new DataInputStream(socket.getInputStream());

            dOut.writeInt(bytes.length); // write length of the message
            dOut.write(bytes); // write the message

            int length = dIn.readInt(); // read length of incoming message
            if (length > 0) {
                bytes = new byte[length];
                dIn.readFully(bytes, 0, bytes.length); // read the message

                message = new String(bytes);
                log.info(host + ":" + port + " - " + message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                dIn.close();
                dOut.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return message;
    }

    /*
        Util methods
     */
    public String getSignature(String num) {

        String res = DigestUtils.sha1Hex(apikey.concat(num).concat(privatekey));

        return res;

    }

    public String toXmlStringWithoutRoot(Class cl, Object ob, String qName) throws PropertyException, JAXBException {
        StringWriter sw = new StringWriter();

        JAXBContext context = JAXBContext.newInstance(cl);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        JAXBElement jx = new JAXBElement(new QName(qName), cl, ob);
        marshaller.marshal(jx, sw);

        return sw.toString();

    }

    public String toXmlString(Class cl, Object ob) {

        JAXBContext context;
        StringWriter sw = new StringWriter();
        try {
            context = JAXBContext.newInstance(cl);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(ob, sw);
        } catch (JAXBException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return sw.toString();
    }

}

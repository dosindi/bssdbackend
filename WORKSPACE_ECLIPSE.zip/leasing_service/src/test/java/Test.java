/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
  * @author Duncan.Nyakundi 
 * TODO
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        String msg = ",@id::@id/payment.ref.no::payment.ref.no/bank.code::bank.code/ac.number::ac.number/id.number::id.number/coll.type::coll.type/request.time::request.time/txn.reference::txn.reference/payment.method::payment.method/REGION::REGION,\"PRN211937SS96                      \"	\"NSSF5377661477                     \"	\"                                   \"	\"                                   \"	\"                                   \"	\"NSSF                               \"	\"2109220612                         \"	\"                   \"	\"          \"	\"KAMPALA                       \"";
//
//        String[] split = msg.split("\"");
//
//        for (int x = 0; x < split.length; x++) {
//            System.out.println("---"+split[x]);

        int[] A = {1,2,3,4}; //5
//        int[] A = {-1,-2,-3};//1
//       int[] A = {1,1,2,3,4,6}; //5
        int s = solution(A);
        System.out.println("sol: " + s);

    }

    public static int solution(int[] A) {
        int result = 0;
        int temp = 0;
        for(int x=1;x<100000&&temp!=0;x++){
            
        }
        for (int x : A) {
            if (x > 1 && x < 100000) {
                result = x;
            }
        }
        if (result == 0) {
            result = 1;
        }

        return result;
    }
}

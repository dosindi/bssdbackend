
package com.ncba.nssf.client.generated;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ncba.nssf.client.generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ncba.nssf.client.generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SoValidateRequest }
     * 
     */
    public SoValidateRequest createSoValidateRequest() {
        return new SoValidateRequest();
    }

    /**
     * Create an instance of {@link SoValidateResponse }
     * 
     */
    public SoValidateResponse createSoValidateResponse() {
        return new SoValidateResponse();
    }

    /**
     * Create an instance of {@link SoCreateTRN }
     * 
     */
    public SoCreateTRN createSoCreateTRN() {
        return new SoCreateTRN();
    }

    /**
     * Create an instance of {@link SoCreateTRNResponse }
     * 
     */
    public SoCreateTRNResponse createSoCreateTRNResponse() {
        return new SoCreateTRNResponse();
    }

    /**
     * Create an instance of {@link SoCancelSO }
     * 
     */
    public SoCancelSO createSoCancelSO() {
        return new SoCancelSO();
    }

    /**
     * Create an instance of {@link SoCancelSOResponse }
     * 
     */
    public SoCancelSOResponse createSoCancelSOResponse() {
        return new SoCancelSOResponse();
    }

    /**
     * Create an instance of {@link Ope1 }
     * 
     */
    public Ope1 createOpe1() {
        return new Ope1();
    }

    /**
     * Create an instance of {@link Ope1Response }
     * 
     */
    public Ope1Response createOpe1Response() {
        return new Ope1Response();
    }

}

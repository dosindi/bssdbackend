/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncba.nssf.controller;

import com.ncba.nssf.client.generated.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.logging.Level;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.namespace.QName;
import javax.xml.ws.Holder;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;

/**
 *
 * @author Duncan.Nyakundi
 */
@RestController
public class MainController {

    public static Logger log = Logger.getLogger(MainController.class.getName());

    @Value("${T24.server.port}")
    public int port;

    @Value("${T24.server.ip}")
    public String host;

    Socket socket = null;
    String fields = "";
    String message = "";
    String function = "";
    String recordId = "";

    @Value("${T24.credential}")
    public String credential;

    String application = "";

    byte[] bytes = null;

    @Value("${nssf.endpoint}")
    public String endpoint;

    @Value("${nssf.apikey}")
    public String apikey;

    @Value("${nssf.privatekey}")
    public String privatekey;

    /*
     *   Operation: setStatus
     */
    @GetMapping("/api/setStatus")
    public String setStatus() {

        String result = "";
        String comments = "comments";
        String num = "NSSF5377661477";

        String signature = getSignature(num);

        SetStatus request = new SetStatus();
        request.setApiKey(apikey);
        request.setComment(comments);
        request.setSignature(signature);
        request.setStatus(1);
        request.setTransactionNumber(num);

        RegBANK service = new RegBANK();
        service.getRegBANKPort();
        SetStatusResponse response = service.getRegBANKPort().setStatus(request);
        result = response.toString();

        String logRequest = toXmlString(SetStatus.class, request);
        log.info("logRequest: " + logRequest);
        String logResponse = toXmlString(SetStatusResponse.class, response);
        log.info("logResponse: " + logResponse);

        log.info("setStatus response:" + result);
        return result;
    }

    /*
     * Operation: checkStatus
     */
    @GetMapping("/api/checkStatus")
    public String checkStatus() {

        String result = "";
        String phrase = "availability";
        String num = "Server test";

        String signature = getSignature(num);

        CheckStatus request = new CheckStatus();
        request.setApiKey(apikey);
        request.setPhrase(phrase);
        request.setSignature(signature);
        RegBANK service = new RegBANK();
        service.getRegBANKPort();

        CheckStatusResponse response = service.getRegBANKPort().checkStatus(request);
        result = response.toString();

        String logRequest = toXmlString(CheckStatus.class, request);
        log.info("logRequest: " + logRequest);
        String logResponse = toXmlString(CheckStatusResponse.class, response);
        log.info("logResponse: " + logResponse);

        log.info("checkStatus response: " + result);
        return result;
    }

    /*
     * Operation: soValidate
     */
    @GetMapping("/api/soValidate")
    public String soValidate() {
        String result = "";

        String nssfNumber = "9303900106048";
        String bankcode = "HFB";
        String frequency = "MONTHLY";
        int amount = 25000;
        String startdate = "2019-04-01";
        String enddate = "2019-04-30";
        String comment1 = "a";
        String comment2 = "b";
        String comment3 = "c";

        String signature = getSignature(nssfNumber);

        SoValidateRequest request = new SoValidateRequest();
        request.setApiKey(apikey);
        request.setSignature(signature);
        request.setNssfNumber(nssfNumber);
        request.setBankcode(bankcode);
        request.setFrequency(frequency);
        request.setAmount(amount);
        request.setStartdate(startdate);
        request.setEnddate(enddate);
        request.setComment1(comment1);
        request.setComment2(comment2);
        request.setComment3(comment3);

        String logRequest = toXmlString(SoValidateRequest.class, request);
        log.info("logRequest: " + logRequest);

        RegBANKSO service = new RegBANKSO();
        service.getRegBANKSOPort();
        SoValidateResponse response = service.getRegBANKSOPort().soValidate(request);
        result = response.toString();

        String logResponse = toXmlString(SoValidateResponse.class, response);
        log.info("logResponse: " + logResponse);

        log.info("response sovalidate:" + result);

        return result;
    }

    /*
    *   Operation: soCreateTRN
     */
    @GetMapping("/api/soCreateTRN")
    public String soCreateTRN() {

        String result = "";

        String nssfNumber = "9303900106048";
        int amount = 25000;
        String transactiondate = "2019-04-06";
        String status = "1";

        Holder<Integer> code = new Holder<>();
        Holder<String> message = new Holder<>();
        Holder<String> nssfnumber = new Holder<>();
        Holder<String> reference = new Holder<>();
        Holder<String> uplDatetime = new Holder<>();
        Holder<String> employerNo = new Holder<>();
        Holder<String> email = new Holder<>();
        Holder<String> type = new Holder<>();
        Holder<String> paymentMethod = new Holder<>();
        Holder<String> period = new Holder<>();
        Holder<String> total = new Holder<>();
        Holder<String> allchqs = new Holder<>();
        Holder<Integer> timestamp = new Holder<>();

        String signature = getSignature(nssfNumber);
        Holder<String> sign = new Holder<>(signature);

        RegBANKSO service = new RegBANKSO();
        service.getRegBANKSOPort();

        SoCreateTRN request = new SoCreateTRN();
        request.setApiKey(apikey);
        request.setSignature(signature);
        request.setNssfNumber(nssfNumber);
        request.setAmount(amount);
        request.setTransactiondate(transactiondate);
        request.setStatus(status);
        log.info("signature :".concat(signature));

        String logRequest = toXmlString(SoCreateTRN.class, request);
        log.info("logRequest: " + logRequest);

        service.getRegBANKSOPort().soCreateTRN(apikey, sign, nssfNumber, amount, transactiondate, status, code, message, nssfnumber, reference, uplDatetime, employerNo, email, type, paymentMethod, period, total, allchqs, timestamp);
        result = "code:".concat(String.valueOf(code.value)).concat(message.value).concat(nssfnumber.value).concat(reference.value).concat(uplDatetime.value).concat(employerNo.value).concat(email.value).concat(type.value).concat(paymentMethod.value).concat(period.value).concat(total.value).concat(allchqs.value).concat(String.valueOf(timestamp.value));
        log.info("response: ".concat(result));

        return result;
    }

    /*
     * Operation: getTransactionRequest
     */
    @GetMapping("/api/getTransactionRequest")
    public String getTransactionRequest() {

        String num = "NSSF5377661477";

        String signature = getSignature(num);
        RegBANK service = new RegBANK();
        service.getRegBANKPort();
        GetTransactionRequest request = new GetTransactionRequest();
        request.setApiKey(apikey);
        log.info("signature :".concat(signature));
        request.setSignature(signature);
        request.setTransactionNumber(num);

        GetTransactionResponse response = service.getRegBANKPort().getTransaction(request);
        log.info("response: ".concat(response.toString()));

        String logRequest = toXmlString(GetTransactionRequest.class, request);
        log.info("logRequest: " + logRequest);
        String logResponse = toXmlString(GetTransactionResponse.class, response);
        log.info("logResponse: " + logResponse);

        return response.toString();
    }

    /*
* Operation: soCancelSO
     */
    @GetMapping("/api/soCancelSO")
    public String soCancelSO() {

        String result = "";
        String nssfNumber = "9303900106048";
        String comment = "a";

        Holder<Integer> code = new Holder<>();
        Holder<String> message = new Holder<>();
        Holder<String> nssfnumber = new Holder<>();
        Holder<Integer> status = new Holder<>();
        Holder<Integer> timestamp = new Holder<>();

        String signature = getSignature(nssfNumber);
        Holder<String> sign = new Holder<>(signature);
        RegBANKSO service = new RegBANKSO();
        service.getRegBANKSOPort();

        SoCancelSO request = new SoCancelSO();
        request.setApiKey(apikey);
        request.setSignature(signature);
        request.setNssfNumber(nssfNumber);
        request.setComment(comment);
        log.info("signature :".concat(signature));

        String logRequest = toXmlString(SoCancelSO.class, request);
        log.info("logRequest: " + logRequest);

        service.getRegBANKSOPort().soCancelSO(apikey, sign, nssfNumber, comment, code, message, nssfnumber, status, timestamp);
        result = "code: ".concat(String.valueOf(code.value)).concat("message:").concat(message.value).concat(nssfnumber.value).concat(String.valueOf(status.value)).concat(String.valueOf(timestamp.value));
        log.info("response: ".concat(result));
        return result;
    }

    public String getSignature(String num) {

        String res = DigestUtils.sha1Hex(apikey.concat(num).concat(privatekey));

        return res;

    }

    public String toXmlStringWithoutRoot(Class cl, Object ob, String qName) throws PropertyException, JAXBException {
        StringWriter sw = new StringWriter();

        JAXBContext context = JAXBContext.newInstance(cl);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        JAXBElement jx = new JAXBElement(new QName(qName), cl, ob);
        marshaller.marshal(jx, sw);

        return sw.toString();

    }

    public String toXmlString(Class cl, Object ob) {

        JAXBContext context;
        StringWriter sw = new StringWriter();
        try {
            context = JAXBContext.newInstance(cl);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(ob, sw);
        } catch (JAXBException ex) {
            java.util.logging.Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return sw.toString();
    }

    @GetMapping("/api/poolOFS")
    public String getOfs() {

        setJBoss();

//        getENQUIRY();
        // bytes = BuildOFS();
        bytes = LazyOFS(); // executes ofs string

        long startTime = System.nanoTime();

        String resp = processOFS(bytes);

        // printResponse(resp);
        long estimatedTime = System.nanoTime() - startTime;

        log.info("Lapse Time: " + (estimatedTime / 1000000) + " ms");

        return resp;
    }

    private void setJBoss() {

        // UG
//        port = 7201;
//        host = "172.31.67.54";
//        credential = "UPGRADE.1/Kenya123*/UG0010001";
    }

//    private void getENQUIRY() {
//
//    }

    private byte[] LazyOFS() {

        byte[] bytes = null;

        message = "ENQUIRY.SELECT,," + credential + ",CBA.COLLECTIONS.REQUEST";
//        message = "ENQUIRY.SELECT,,UPGRADE.1/Kenya123,CBA.COLLECTIONS.REQUEST";
//        message = "H.CBA.COLL.RESP,INPUT/I/PROCESS,ICON.COLL.USER/Kenya123/UG0010001,NSSF9228786605,RESULT::=INVALID,REMARKS::=307 Incorrect signature.,ICON.STATUS::=PROCESSED,COLL.TYPE::=NSSF";

        System.out.println(host + ":" + port + " - " + message);
        bytes = message.getBytes();

        return bytes;
    }

    private String processOFS(byte[] bytes) {
        socket = new Socket();
        DataInputStream dIn = null;
        DataOutputStream dOut = null;

        try {
            socket.connect(new InetSocketAddress(host, port), 1000000);

            dOut = new DataOutputStream(socket.getOutputStream());
            dIn = new DataInputStream(socket.getInputStream());

            dOut.writeInt(bytes.length); // write length of the message
            dOut.write(bytes); // write the message

            int length = dIn.readInt(); // read length of incoming message
            if (length > 0) {
                bytes = new byte[length];
                dIn.readFully(bytes, 0, bytes.length); // read the message

                message = new String(bytes);
                log.info(host + ":" + port + " - " + message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                dIn.close();
                dOut.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return message;
    }
}

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.talend.org/service/")
package com.ncba.nssf.client.generated;
